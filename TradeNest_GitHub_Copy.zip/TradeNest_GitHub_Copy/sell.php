<?php
session_start();
include "db_connect.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$adminRoles = ["Super Admin", "Product Moderator", "Support Staff"];

if (in_array($_SESSION["role_name"], $adminRoles)) {
    header("Location: admin-dashboard.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$firstName = $_SESSION["first_name"];
$lastName = $_SESSION["last_name"];
$roleName = $_SESSION["role_name"];

$message = "";
$error_message = "";

$categoriesSql = "SELECT category_id, category_name FROM categories ORDER BY category_name ASC";
$categoriesResult = mysqli_query($conn, $categoriesSql);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $product_name = trim($_POST["product_name"]);
    $category_id = intval($_POST["category_id"]);
    $price = floatval($_POST["price"]);
    $location = trim($_POST["location"]);
    $product_condition = trim($_POST["product_condition"]);
    $product_description = trim($_POST["product_description"]);

    $image_url = "";

    if (empty($product_name) || $category_id <= 0 || $price <= 0 || empty($location) || empty($product_condition) || empty($product_description)) {
        $error_message = "Please complete all required product listing fields.";
    } else {
        if (isset($_FILES["product_image"]) && $_FILES["product_image"]["error"] === UPLOAD_ERR_OK) {
            $uploadDir = "assets/uploads/";

            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $fileName = $_FILES["product_image"]["name"];
            $fileTmp = $_FILES["product_image"]["tmp_name"];
            $fileSize = $_FILES["product_image"]["size"];

            $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $allowedExtensions = ["jpg", "jpeg", "png", "webp"];

            if (!in_array($fileExtension, $allowedExtensions)) {
                $error_message = "Only JPG, JPEG, PNG or WEBP product images are allowed.";
            } elseif ($fileSize > 5 * 1024 * 1024) {
                $error_message = "The image is too large. Please upload an image smaller than 5MB.";
            } else {
                $newFileName = "product_" . $user_id . "_" . time() . "." . $fileExtension;
                $uploadPath = $uploadDir . $newFileName;

                if (move_uploaded_file($fileTmp, $uploadPath)) {
                    $image_url = $uploadPath;
                } else {
                    $error_message = "The product image could not be uploaded. Please try again.";
                }
            }
        }

        if (empty($error_message)) {
            $listing_status = "Pending review";

            $insertSql = "INSERT INTO products 
                            (seller_id, category_id, product_name, product_description, price, product_condition, location, image_url, listing_status)
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

            $stmt = mysqli_prepare($conn, $insertSql);
            mysqli_stmt_bind_param(
                $stmt,
                "iissdssss",
                $user_id,
                $category_id,
                $product_name,
                $product_description,
                $price,
                $product_condition,
                $location,
                $image_url,
                $listing_status
            );

            if (mysqli_stmt_execute($stmt)) {
                $message = "Your listing has been submitted for admin review. Once approved, it will appear on the marketplace.";
            } else {
                $error_message = "Could not submit your listing. Please try again.";
            }

            mysqli_stmt_close($stmt);
        }
    }
}

mysqli_data_seek($categoriesResult, 0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sell an Item | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .sell-message-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(66, 122, 77, 0.14);
            color: #2f6b3c;
            font-weight: 900;
            line-height: 1.5;
            margin-bottom: 22px;
        }

        .sell-error-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(198, 90, 44, 0.14);
            color: #a6532e;
            font-weight: 900;
            line-height: 1.5;
            margin-bottom: 22px;
        }

        .upload-box {
            position: relative;
            cursor: pointer;
        }

        .upload-box input[type="file"] {
            width: 100%;
            padding: 22px;
            border-radius: 24px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px dashed rgba(38, 24, 20, 0.22);
            cursor: pointer;
        }

        .upload-helper {
            margin-top: 10px;
            color: var(--muted);
            font-weight: 700;
            line-height: 1.6;
            font-size: 0.9rem;
        }

        .preview-image {
            background-size: cover;
            background-position: center;
        }

        .preview-placeholder {
    width: 100%;
    min-height: 260px;
    border-radius: 28px;
    background: rgba(38, 24, 20, 0.06);
    border: 1px dashed rgba(38, 24, 20, 0.22);
    background-size: cover;
    background-position: center;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--muted);
    font-weight: 900;
    text-align: center;
}

        .seller-note-list {
            margin-top: 14px;
            padding-left: 20px;
            color: var(--muted);
            line-height: 1.7;
            font-weight: 700;
        }

        .seller-note-list li {
            margin-bottom: 8px;
        }

        .secondary-form-btn,
        .primary-form-btn {
            text-decoration: none;
        }
    </style>
</head>
<body>

    <header class="site-header">
        <a href="index.php" class="brand">TradeNest</a>

        <nav class="desktop-nav">
            <a href="browse.php">Browse</a>
            <a href="sell.php">Sell</a>
            <a href="dashboard.php">Dashboard</a>
            <a href="faq.php">Help</a>
            <a href="admin-login.php">Admin</a>
        </nav>

        <div class="header-actions">
            <a href="logout.php" class="login-link">Logout</a>
            <a href="sell.php" class="join-btn">List item</a>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="browse.php">Browse</a>
        <a href="sell.php">Sell</a>
        <a href="dashboard.php">Dashboard</a>
        <a href="faq.php">Help</a>
        <a href="admin-login.php">Admin</a>
        <a href="logout.php">Logout</a>
    </nav>

    <main>

        <!-- SELL HERO -->
        <section class="sell-hero">
            <div class="sell-hero-text">
                <p class="section-label">Start selling</p>
                <h1>Turn your items into local income.</h1>
                <p>
                    TradeNest helps sellers create clean product listings with images, prices, locations and product details.
                    New listings are submitted for admin review before they appear publicly on Browse.
                </p>
            </div>

            <div class="seller-tip-card">
                <span>Seller tip</span>
                <h3>Good photos sell faster.</h3>
                <p>Use clear images, honest descriptions and a fair price to build trust with buyers.</p>
            </div>
        </section>

        <!-- SELL FORM -->
        <section class="sell-page-layout">

            <form class="sell-form" method="POST" action="sell.php" enctype="multipart/form-data">

                <div class="form-heading">
                    <p class="section-label">Product details</p>
                    <h2>List your item</h2>
                </div>

                <?php if (!empty($message)) { ?>
                    <div class="sell-message-box">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php } ?>

                <?php if (!empty($error_message)) { ?>
                    <div class="sell-error-box">
                        <?php echo htmlspecialchars($error_message); ?>
                    </div>
                <?php } ?>

                <div class="form-grid">
                    <div class="form-group">
                        <label for="product_name">Product name</label>
                        <input 
                            type="text" 
                            id="product_name" 
                            name="product_name" 
                            placeholder="e.g. Vintage denim jacket"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="category_id">Category</label>
                        <select id="category_id" name="category_id" required>
                            <option value="">Select a category</option>

                            <?php while ($category = mysqli_fetch_assoc($categoriesResult)) { ?>
                                <option value="<?php echo $category["category_id"]; ?>">
                                    <?php echo htmlspecialchars($category["category_name"]); ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="price">Price</label>
                        <input 
                            type="number" 
                            id="price" 
                            name="price" 
                            min="1"
                            step="0.01"
                            placeholder="e.g. 350"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="location">Location</label>
                        <select id="location" name="location" required>
                            <option value="">Select location</option>
                            <option value="Johannesburg">Johannesburg</option>
                            <option value="Soweto">Soweto</option>
                            <option value="Tembisa">Tembisa</option>
                            <option value="Midrand">Midrand</option>
                            <option value="Pretoria">Pretoria</option>
                            <option value="Alexandra">Alexandra</option>
                            <option value="Sandton">Sandton</option>
                            <option value="Centurion">Centurion</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="product_condition">Condition</label>
                        <select id="product_condition" name="product_condition" required>
                            <option value="">Select condition</option>
                            <option value="New">New</option>
                            <option value="Like new">Like new</option>
                            <option value="Good">Good</option>
                            <option value="Fair">Fair</option>
                            <option value="Used">Used</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="seller_name">Seller</label>
                        <input 
                            type="text" 
                            id="seller_name" 
                            value="<?php echo htmlspecialchars($firstName . " " . $lastName); ?>"
                            readonly
                        >
                    </div>

                    <div class="form-group full-width">
                        <label for="product_description">Description</label>
                        <textarea 
                            id="product_description" 
                            name="product_description" 
                            placeholder="Describe the item, condition, size, colour, or anything the buyer should know."
                            required
                        ></textarea>
                    </div>

                    <div class="form-group full-width">
                        <label for="product_image">Product image</label>

                        <div class="upload-box">
                            <input 
                                type="file" 
                                id="product_image" 
                                name="product_image"
                                accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                            >
                        </div>

                        <p class="upload-helper">
                            Upload a clear product photo from your computer. JPG, JPEG, PNG and WEBP files are supported.
                            If no image is uploaded, the marketplace will use a category fallback image.
                        </p>
                    </div>
                </div>

                <div class="form-actions">
                    <a href="dashboard.php" class="secondary-form-btn">Cancel</a>
                    <button type="submit" class="primary-form-btn">Publish listing</button>
                </div>

            </form>

            <aside class="listing-preview">
                <p class="section-label">Preview</p>

                <div class="preview-card">
                    <div class="preview-placeholder" id="previewImageBox">
    Image preview
</div>

                    <div class="preview-info">
                        <p>Your location · Selected category</p>
                        <h3>Your product name</h3>

                        <div>
                            <strong>R0.00</strong>
                            <span>Pending approval</span>
                        </div>
                    </div>
                </div>

                <div class="preview-note">
                    <h3>Before you publish</h3>
                    <p>
                        Make sure the listing has a real photo, a clear price, the correct category and an honest description.
                        This helps buyers trust the seller and reduces disputes.
                    </p>

                    <ul class="seller-note-list">
                        <li>Listings are saved as Pending review first.</li>
                        <li>Approved listings appear on Browse.</li>
                        <li>Suspicious or misleading products can be reported by users.</li>
                    </ul>
                </div>
            </aside>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest</p>
        <p>Sell page for customer-to-customer product listing and moderation.</p>
    </footer>

    <script src="assets/js/app.js"></script>
	<script>
    const productNameInput = document.getElementById("product_name");
    const categoryInput = document.getElementById("category_id");
    const priceInput = document.getElementById("price");
    const locationInput = document.getElementById("location");
    const imageInput = document.getElementById("product_image");

    const previewImage = document.querySelector(".preview-placeholder");
    const previewLocationCategory = document.querySelector(".preview-info p");
    const previewTitle = document.querySelector(".preview-info h3");
    const previewPrice = document.querySelector(".preview-info strong");

    function updatePreviewText() {
        const productName = productNameInput.value.trim() || "Your product name";
        const price = priceInput.value.trim() || "0.00";
        const location = locationInput.value.trim() || "Your location";

        let categoryText = "Selected category";

        if (categoryInput.selectedIndex > 0) {
            categoryText = categoryInput.options[categoryInput.selectedIndex].text;
        }

        previewTitle.textContent = productName;
        previewPrice.textContent = "R" + parseFloat(price || 0).toFixed(2);
        previewLocationCategory.textContent = location + " · " + categoryText;
    }

    productNameInput.addEventListener("input", updatePreviewText);
    priceInput.addEventListener("input", updatePreviewText);
    locationInput.addEventListener("change", updatePreviewText);
    categoryInput.addEventListener("change", updatePreviewText);

    imageInput.addEventListener("change", function () {
        const file = imageInput.files[0];

        if (file) {
            const reader = new FileReader();

            reader.onload = function (event) {
                previewImage.textContent = "";
previewImage.style.backgroundImage = "url('" + event.target.result + "')";
            };

            reader.readAsDataURL(file);
        }
    });
</script>
</body>
</html>

<?php
mysqli_close($conn);
?>