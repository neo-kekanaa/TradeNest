<?php
session_start();
include "db_connect.php";

$adminRoles = ["Super Admin", "Product Moderator", "Support Staff"];

if (!isset($_SESSION["user_id"])) {
    header("Location: admin-login.php");
    exit();
}

if (!in_array($_SESSION["role_name"], $adminRoles)) {
    header("Location: dashboard.php");
    exit();
}

if ($_SESSION["role_name"] !== "Super Admin") {
    die("Access denied. Only Super Admin users can manage user accounts and roles.");
}

$message = "";
$error_message = "";

include "db_connect.php";

$adminRoles = ["Super Admin", "Product Moderator", "Support Staff"];

if (!isset($_SESSION["user_id"])) {
    header("Location: admin-login.php");
    exit();
}

if (!in_array($_SESSION["role_name"], $adminRoles)) {
    header("Location: dashboard.php");
    exit();
}

if ($_SESSION["role_name"] !== "Super Admin") {
    die("Access denied. Only Super Admin users can manage user accounts and roles.");
}

$message = "";
$error_message = "";

/* CREATE NEW USER */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["create_user"])) {
    $first_name = trim($_POST["first_name"]);
    $last_name = trim($_POST["last_name"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
    $phone_number = trim($_POST["phone_number"]);
    $location = trim($_POST["location"]);
    $role_id = intval($_POST["role_id"]);
    $account_status = trim($_POST["account_status"]);

    if (empty($first_name) || empty($last_name) || empty($email) || empty($password) || $role_id <= 0) {
        $error_message = "Please complete all required fields.";
    } else {
        $insertSql = "INSERT INTO users 
                        (role_id, first_name, last_name, email, password, phone_number, location, account_status)
                      VALUES 
                        (?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = mysqli_prepare($conn, $insertSql);
        mysqli_stmt_bind_param(
            $stmt,
            "isssssss",
            $role_id,
            $first_name,
            $last_name,
            $email,
            $password,
            $phone_number,
            $location,
            $account_status
        );

        if (mysqli_stmt_execute($stmt)) {
            $message = "User created successfully.";
        } else {
            $error_message = "User could not be created. The email may already exist.";
        }

        mysqli_stmt_close($stmt);
    }
}

/* UPDATE USER STATUS OR ROLE */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["update_user"])) {
    $user_id = intval($_POST["user_id"]);
    $role_id = intval($_POST["role_id"]);
    $account_status = trim($_POST["account_status"]);

    $updateSql = "UPDATE users 
                  SET role_id = ?, account_status = ?
                  WHERE user_id = ?";

    $stmt = mysqli_prepare($conn, $updateSql);
    mysqli_stmt_bind_param($stmt, "isi", $role_id, $account_status, $user_id);

    if (mysqli_stmt_execute($stmt)) {
        $message = "User updated successfully.";
    } else {
        $error_message = "User could not be updated.";
    }

    mysqli_stmt_close($stmt);
}

/* DELETE USER */
if (isset($_GET["action"]) && $_GET["action"] === "delete" && isset($_GET["id"])) {
    $user_id = intval($_GET["id"]);

    $deleteSql = "DELETE FROM users WHERE user_id = ?";
    $stmt = mysqli_prepare($conn, $deleteSql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);

    if (mysqli_stmt_execute($stmt)) {
        header("Location: admin-users.php?message=User deleted successfully");
        exit();
    } else {
        header("Location: admin-users.php?error=User could not be deleted because they may be linked to products or orders");
        exit();
    }

    mysqli_stmt_close($stmt);
}

if (isset($_GET["message"])) {
    $message = $_GET["message"];
}

if (isset($_GET["error"])) {
    $error_message = $_GET["error"];
}

/* FETCH ROLES */
$rolesSql = "SELECT role_id, role_name FROM roles ORDER BY role_name ASC";
$rolesResult = mysqli_query($conn, $rolesSql);

/* FETCH USERS */
$usersSql = "SELECT 
                users.user_id,
                users.first_name,
                users.last_name,
                users.email,
                users.phone_number,
                users.location,
                users.account_status,
                users.created_at,
                roles.role_id,
                roles.role_name
            FROM users
            INNER JOIN roles ON users.role_id = roles.role_id
            ORDER BY users.created_at DESC";

$usersResult = mysqli_query($conn, $usersSql);

/* DASHBOARD COUNTS */
$totalUsersResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM users");
$totalUsers = mysqli_fetch_assoc($totalUsersResult)["total"];

$buyersResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM users INNER JOIN roles ON users.role_id = roles.role_id WHERE roles.role_name = 'Buyer'");
$buyersCount = mysqli_fetch_assoc($buyersResult)["total"];

$sellersResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM users INNER JOIN roles ON users.role_id = roles.role_id WHERE roles.role_name = 'Seller'");
$sellersCount = mysqli_fetch_assoc($sellersResult)["total"];

$adminResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM users INNER JOIN roles ON users.role_id = roles.role_id WHERE roles.role_name IN ('Super Admin', 'Product Moderator', 'Support Staff')");
$adminCount = mysqli_fetch_assoc($adminResult)["total"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users | TradeNest Admin</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .admin-page {
            width: calc(100% - 48px);
            max-width: 1440px;
            margin: 34px auto 120px;
        }

        .admin-hero {
            min-height: 420px;
            padding: 70px;
            border-radius: 46px;
            color: var(--paper);
            background:
                linear-gradient(90deg, rgba(9, 8, 7, 0.94), rgba(9, 8, 7, 0.32)),
                url("assets/images/hero-community.png");
            background-size: cover;
            background-position: center;
            box-shadow: var(--shadow);
            margin-bottom: 34px;
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
        }

        .admin-hero h1 {
            font-size: clamp(3.8rem, 7vw, 7.8rem);
            line-height: 0.88;
            letter-spacing: -6px;
            max-width: 900px;
        }

        .admin-hero p:not(.section-label) {
            max-width: 720px;
            margin-top: 24px;
            color: rgba(255, 248, 239, 0.74);
            line-height: 1.85;
        }

        .admin-stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 18px;
            margin-bottom: 28px;
        }

        .admin-stat-card {
            padding: 28px;
            border-radius: 32px;
            background: rgba(255, 248, 239, 0.68);
            border: 1px solid rgba(38, 24, 20, 0.08);
            box-shadow: var(--soft-shadow);
        }

        .admin-stat-card span {
            display: block;
            font-size: 0.72rem;
            font-weight: 900;
            letter-spacing: 1.3px;
            text-transform: uppercase;
            color: var(--clay);
            margin-bottom: 12px;
        }

        .admin-stat-card strong {
            font-size: 2.4rem;
            color: var(--espresso);
        }

        .admin-layout {
            display: grid;
            grid-template-columns: 0.8fr 1.2fr;
            gap: 28px;
            align-items: start;
        }

        .admin-panel {
            padding: 34px;
            border-radius: 42px;
            background: rgba(255, 248, 239, 0.68);
            border: 1px solid rgba(38, 24, 20, 0.08);
            box-shadow: var(--soft-shadow);
            overflow-x: auto;
        }

        .admin-panel h2 {
            font-size: clamp(2.8rem, 4vw, 5rem);
            line-height: 0.92;
            letter-spacing: -4px;
            margin-bottom: 24px;
        }

        .message-box,
        .error-box {
            margin-bottom: 24px;
            padding: 16px 18px;
            border-radius: 18px;
            font-weight: 900;
            line-height: 1.5;
        }

        .message-box {
            background: rgba(84, 211, 107, 0.14);
            color: #2f7c43;
        }

        .error-box {
            background: rgba(198, 90, 44, 0.14);
            color: var(--clay);
        }

        .admin-form {
            display: grid;
            gap: 16px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
        }

        .form-field label {
            display: block;
            font-size: 0.75rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: var(--clay);
            margin-bottom: 9px;
        }

        .form-field input,
        .form-field select {
            width: 100%;
            border: 1px solid rgba(38, 24, 20, 0.12);
            background: rgba(255, 248, 239, 0.82);
            border-radius: 20px;
            padding: 15px 16px;
            font: inherit;
            color: var(--espresso);
            outline: none;
        }

        .create-btn,
        .small-update-btn {
            border: none;
            border-radius: 999px;
            background: var(--espresso);
            color: var(--paper);
            font-weight: 900;
            cursor: pointer;
            transition: 0.3s ease;
        }

        .create-btn {
            min-height: 54px;
            padding: 16px 24px;
            margin-top: 8px;
        }

        .small-update-btn {
            padding: 10px 14px;
            font-size: 0.78rem;
        }

        .create-btn:hover,
        .small-update-btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--soft-shadow);
        }

        .admin-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1050px;
        }

        .admin-table th {
            text-align: left;
            padding: 16px;
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: var(--clay);
            border-bottom: 1px solid rgba(38, 24, 20, 0.12);
        }

        .admin-table td {
            padding: 18px 16px;
            border-bottom: 1px solid rgba(38, 24, 20, 0.08);
            vertical-align: top;
            color: var(--muted);
            line-height: 1.5;
        }

        .admin-table td strong {
            color: var(--espresso);
        }

        .role-pill,
        .status-pill {
            display: inline-flex;
            padding: 8px 12px;
            border-radius: 999px;
            font-size: 0.75rem;
            font-weight: 900;
            white-space: nowrap;
        }

        .role-pill {
            background: rgba(38, 24, 20, 0.08);
            color: var(--espresso);
        }

        .status-pill {
            background: rgba(84, 211, 107, 0.16);
            color: #2f7c43;
        }

        .status-suspended {
            background: rgba(198, 90, 44, 0.14);
            color: var(--clay);
        }

        .mini-form {
            display: grid;
            gap: 8px;
            min-width: 180px;
        }

        .mini-form select {
            border: 1px solid rgba(38, 24, 20, 0.12);
            background: rgba(255, 248, 239, 0.82);
            border-radius: 999px;
            padding: 9px 12px;
            font: inherit;
            color: var(--espresso);
            outline: none;
        }

        .delete-btn {
            display: inline-flex;
            margin-top: 8px;
            padding: 10px 14px;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 900;
            background: rgba(120, 30, 20, 0.14);
            color: #7a1d14;
        }

        .admin-links {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 28px;
        }

        .admin-link-btn {
            min-height: 50px;
            padding: 14px 20px;
            border-radius: 999px;
            background: var(--espresso);
            color: var(--paper);
            font-weight: 900;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .admin-link-btn.secondary {
            background: rgba(38, 24, 20, 0.08);
            color: var(--espresso);
        }

        @media (max-width: 1120px) {
            .admin-layout {
                grid-template-columns: 1fr;
            }

            .admin-stats {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 680px) {
            .admin-page {
                width: calc(100% - 28px);
                margin-top: 20px;
            }

            .admin-hero {
                padding: 34px;
                border-radius: 34px;
                min-height: 560px;
            }

            .admin-hero h1 {
                font-size: 3.6rem;
                letter-spacing: -3.5px;
            }

            .admin-stats {
                grid-template-columns: 1fr;
            }

            .admin-panel {
                padding: 22px;
                border-radius: 30px;
            }

            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

    <header class="site-header">
        <a href="index.php" class="brand">TradeNest</a>

        <nav class="desktop-nav">
            <a href="admin-dashboard.php">Dashboard</a>
            <a href="admin-products.php">Products</a>
            <a href="admin-users.php">Users</a>
            <a href="roles.php">Roles</a>
        </nav>

        <div class="header-actions">
            <a href="browse.php" class="login-link">View site</a>
            <a href="logout.php" class="join-btn">Logout</a>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="admin-dashboard.php">Dashboard</a>
        <a href="admin-products.php">Products</a>
        <a href="admin-users.php">Users</a>
        <a href="roles.php">Roles</a>
        <a href="browse.php">View site</a>
        <a href="logout.php">Logout</a>
    </nav>

    <main class="admin-page">

        <section class="admin-hero">
            <p class="section-label">Admin user management</p>
            <h1>Manage users and roles.</h1>
            <p>
                Administrators can create user accounts, assign roles, update account status and remove users where necessary.
            </p>
        </section>

        <section class="admin-stats">
            <div class="admin-stat-card">
                <span>Total users</span>
                <strong><?php echo $totalUsers; ?></strong>
            </div>

            <div class="admin-stat-card">
                <span>Buyers</span>
                <strong><?php echo $buyersCount; ?></strong>
            </div>

            <div class="admin-stat-card">
                <span>Sellers</span>
                <strong><?php echo $sellersCount; ?></strong>
            </div>

            <div class="admin-stat-card">
                <span>Admin roles</span>
                <strong><?php echo $adminCount; ?></strong>
            </div>
        </section>

        <?php if (!empty($message)) { ?>
            <div class="message-box">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php } ?>

        <?php if (!empty($error_message)) { ?>
            <div class="error-box">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php } ?>

        <section class="admin-layout">

            <aside class="admin-panel">
                <p class="section-label">Create account</p>
                <h2>New user</h2>

                <form method="POST" action="admin-users.php" class="admin-form">
                    <input type="hidden" name="create_user" value="1">

                    <div class="form-row">
                        <div class="form-field">
                            <label for="first_name">First name</label>
                            <input type="text" id="first_name" name="first_name" required>
                        </div>

                        <div class="form-field">
                            <label for="last_name">Last name</label>
                            <input type="text" id="last_name" name="last_name" required>
                        </div>
                    </div>

                    <div class="form-field">
                        <label for="email">Email address</label>
                        <input type="email" id="email" name="email" required>
                    </div>

                    <div class="form-field">
                        <label for="password">Password</label>
                        <input type="text" id="password" name="password" placeholder="Temporary password" required>
                    </div>

                    <div class="form-row">
                        <div class="form-field">
                            <label for="phone_number">Phone number</label>
                            <input type="text" id="phone_number" name="phone_number">
                        </div>

                        <div class="form-field">
                            <label for="location">Location</label>
                            <input type="text" id="location" name="location">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-field">
                            <label for="role_id">Role</label>
                            <select id="role_id" name="role_id" required>
                                <option value="">Select role</option>

                                <?php 
                                mysqli_data_seek($rolesResult, 0);
                                while ($role = mysqli_fetch_assoc($rolesResult)) { 
                                ?>
                                    <option value="<?php echo $role["role_id"]; ?>">
                                        <?php echo htmlspecialchars($role["role_name"]); ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>

                        <div class="form-field">
                            <label for="account_status">Account status</label>
                            <select id="account_status" name="account_status" required>
                                <option value="Active">Active</option>
                                <option value="Suspended">Suspended</option>
                                <option value="Pending">Pending</option>
                            </select>
                        </div>
                    </div>

                    <button type="submit" class="create-btn">
                        Create user
                    </button>
                </form>
            </aside>

            <section class="admin-panel">
                <p class="section-label">User records</p>
                <h2>Users table</h2>

                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Contact</th>
                            <th>Location</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Admin actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if (mysqli_num_rows($usersResult) > 0) { ?>
                            <?php while ($user = mysqli_fetch_assoc($usersResult)) { ?>
                                <tr>
                                    <td><strong>#<?php echo htmlspecialchars($user["user_id"]); ?></strong></td>

                                    <td>
                                        <strong><?php echo htmlspecialchars($user["first_name"] . " " . $user["last_name"]); ?></strong><br>
                                        <?php echo htmlspecialchars($user["email"]); ?>
                                    </td>

                                    <td><?php echo htmlspecialchars($user["phone_number"]); ?></td>

                                    <td><?php echo htmlspecialchars($user["location"]); ?></td>

                                    <td>
                                        <span class="role-pill">
                                            <?php echo htmlspecialchars($user["role_name"]); ?>
                                        </span>
                                    </td>

                                    <td>
                                        <span class="status-pill <?php echo $user["account_status"] === "Suspended" ? "status-suspended" : ""; ?>">
                                            <?php echo htmlspecialchars($user["account_status"]); ?>
                                        </span>
                                    </td>

                                    <td><?php echo htmlspecialchars($user["created_at"]); ?></td>

                                    <td>
                                        <form method="POST" action="admin-users.php" class="mini-form">
                                            <input type="hidden" name="update_user" value="1">
                                            <input type="hidden" name="user_id" value="<?php echo $user["user_id"]; ?>">

                                            <select name="role_id">
                                                <?php 
                                                mysqli_data_seek($rolesResult, 0);
                                                while ($role = mysqli_fetch_assoc($rolesResult)) { 
                                                ?>
                                                    <option 
                                                        value="<?php echo $role["role_id"]; ?>"
                                                        <?php echo $role["role_id"] == $user["role_id"] ? "selected" : ""; ?>
                                                    >
                                                        <?php echo htmlspecialchars($role["role_name"]); ?>
                                                    </option>
                                                <?php } ?>
                                            </select>

                                            <select name="account_status">
                                                <option value="Active" <?php echo $user["account_status"] === "Active" ? "selected" : ""; ?>>Active</option>
                                                <option value="Suspended" <?php echo $user["account_status"] === "Suspended" ? "selected" : ""; ?>>Suspended</option>
                                                <option value="Pending" <?php echo $user["account_status"] === "Pending" ? "selected" : ""; ?>>Pending</option>
                                            </select>

                                            <button type="submit" class="small-update-btn">
                                                Update
                                            </button>
                                        </form>

                                        <a 
                                            href="admin-users.php?action=delete&id=<?php echo $user["user_id"]; ?>" 
                                            class="delete-btn"
                                            onclick="return confirm('Are you sure you want to delete this user?');"
                                        >
                                            Delete
                                        </a>
                                    </td>
                                </tr>
                            <?php } ?>
                        <?php } else { ?>
                            <tr>
                                <td colspan="8">No users found.</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>

                <div class="admin-links">
                    <a href="admin-dashboard.php" class="admin-link-btn secondary">Back to dashboard</a>
                    <a href="admin-products.php" class="admin-link-btn">Manage products</a>
                </div>
            </section>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest Admin</p>
        <p>User management connected to MySQL roles and users.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>

<?php
mysqli_close($conn);
?>