<?php
session_start();
include "db_connect.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

if ($_SESSION["role_name"] !== "Buyer" && $_SESSION["role_name"] !== "Seller") {
    header("Location: dashboard.php");
    exit();
}

$buyer_id = $_SESSION["user_id"];
$buyer_name = $_SESSION["first_name"] . " " . $_SESSION["last_name"];
$firstName = $_SESSION["first_name"];

$product_id = isset($_GET["id"]) ? intval($_GET["id"]) : 0;

if ($product_id <= 0) {
    header("Location: browse.php");
    exit();
}

$error_message = "";

$sql = "SELECT 
            products.product_id,
            products.product_name,
            products.product_description,
            products.price,
            products.product_condition,
            products.location,
            products.image_url,
            products.listing_status,
            products.seller_id,
            categories.category_name,
            users.first_name,
            users.last_name,
            users.email,
            users.phone_number
        FROM products
        INNER JOIN categories ON products.category_id = categories.category_id
        INNER JOIN users ON products.seller_id = users.user_id
        WHERE products.product_id = ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $product_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) === 0) {
    header("Location: browse.php");
    exit();
}

$product = mysqli_fetch_assoc($result);

$seller_id = intval($product["seller_id"]);
$total_amount = floatval($product["price"]);

if ($buyer_id === $seller_id) {
    header("Location: product.php?id=" . $product_id);
    exit();
}

if ($product["listing_status"] !== "Approved") {
    $error_message = "This product is not currently available for checkout because it has not been approved.";
}

function getProductImage($imageUrl, $categoryName) {
    if (!empty($imageUrl)) {
        return $imageUrl;
    }

    $images = [
        "Fashion" => "https://images.unsplash.com/photo-1523398002811-999ca8dec234?auto=format&fit=crop&w=900&q=80",
        "Electronics" => "https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=900&q=80",
        "Furniture" => "https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?auto=format&fit=crop&w=900&q=80",
        "Books" => "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&w=900&q=80",
        "Beauty" => "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=900&q=80",
        "Handmade" => "assets/images/handmade-community.png"
    ];

    return $images[$categoryName] ?? "assets/images/hero-community.png";
}

$productImage = getProductImage($product["image_url"], $product["category_name"]);

if ($_SERVER["REQUEST_METHOD"] === "POST" && empty($error_message)) {
    $orderSql = "INSERT INTO orders (buyer_id, seller_id, product_id, order_status, total_amount)
                 VALUES (?, ?, ?, 'Pending Payment', ?)";

    $orderStmt = mysqli_prepare($conn, $orderSql);
    mysqli_stmt_bind_param($orderStmt, "iiid", $buyer_id, $seller_id, $product_id, $total_amount);

    if (mysqli_stmt_execute($orderStmt)) {
        $order_id = mysqli_insert_id($conn);
        mysqli_stmt_close($orderStmt);

        header("Location: payment.php?order_id=" . $order_id);
        exit();
    } else {
        $error_message = "Order could not be created. Please try again.";
    }

    mysqli_stmt_close($orderStmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .checkout-page-layout {
            width: calc(100% - 48px);
            max-width: 1340px;
            margin: 0 auto 120px;
            display: grid;
            grid-template-columns: 0.66fr 0.34fr;
            gap: 28px;
            align-items: flex-start;
        }

        .checkout-main {
            display: grid;
            gap: 28px;
        }

        .checkout-product-card {
            display: grid;
            grid-template-columns: 220px 1fr;
            gap: 24px;
            align-items: center;
            padding: 24px;
            border-radius: 32px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
        }

        .checkout-product-image {
            height: 220px;
            border-radius: 28px;
            background-size: cover;
            background-position: center;
            box-shadow: var(--soft-shadow);
        }

        .checkout-product-card h3 {
            color: var(--espresso);
            font-size: 1.7rem;
            letter-spacing: -1px;
            margin-bottom: 12px;
        }

        .checkout-product-card p {
            color: var(--muted);
            line-height: 1.75;
            font-weight: 700;
        }

        .checkout-product-price {
            display: inline-flex;
            margin-top: 16px;
            padding: 10px 14px;
            border-radius: 999px;
            background: var(--soft-black);
            color: var(--paper);
            font-weight: 900;
        }

        .checkout-info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 14px;
            margin-top: 24px;
        }

        .checkout-info-card {
            padding: 18px;
            border-radius: 24px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
        }

        .checkout-info-card span {
            display: block;
            color: var(--clay);
            font-size: 0.72rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            margin-bottom: 8px;
        }

        .checkout-info-card strong {
            color: var(--espresso);
            line-height: 1.5;
        }

        .checkout-summary-card {
            position: sticky;
            top: 110px;
        }

        .checkout-summary-row {
            display: flex;
            justify-content: space-between;
            gap: 18px;
            padding: 18px 0;
            border-bottom: 1px solid rgba(38, 24, 20, 0.10);
            color: var(--muted);
            font-weight: 800;
        }

        .checkout-summary-row strong {
            color: var(--espresso);
            text-align: right;
        }

        .checkout-total {
            font-size: 1.8rem;
            font-weight: 900;
        }

        .checkout-notice {
            margin-top: 24px;
            padding: 24px;
            border-radius: 28px;
            background: var(--soft-black);
            color: var(--paper);
        }

        .checkout-notice h3 {
            margin-bottom: 10px;
            font-size: 1.25rem;
            letter-spacing: -0.5px;
        }

        .checkout-notice p {
            color: rgba(255, 248, 239, 0.74);
            line-height: 1.7;
            font-weight: 700;
        }

        .checkout-actions {
            display: grid;
            gap: 14px;
            margin-top: 28px;
        }

        .checkout-actions button {
            border: none;
            cursor: pointer;
        }

        .checkout-error-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(198, 90, 44, 0.14);
            color: #a6532e;
            font-weight: 900;
            line-height: 1.5;
            margin-bottom: 22px;
        }

        .checkout-steps-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 18px;
        }

        .checkout-step-card {
            padding: 24px;
            border-radius: 28px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
        }

        .checkout-step-card span {
            display: block;
            color: var(--clay);
            font-size: 0.72rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            margin-bottom: 10px;
        }

        .checkout-step-card h3 {
            color: var(--espresso);
            font-size: 1.15rem;
            margin-bottom: 10px;
        }

        .checkout-step-card p {
            color: var(--muted);
            line-height: 1.7;
            font-weight: 700;
            font-size: 0.95rem;
        }

        @media (max-width: 1050px) {
            .checkout-page-layout {
                grid-template-columns: 1fr;
            }

            .checkout-summary-card {
                position: static;
            }

            .checkout-steps-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 720px) {
            .checkout-page-layout {
                width: calc(100% - 28px);
            }

            .checkout-product-card {
                grid-template-columns: 1fr;
            }

            .checkout-product-image {
                height: 280px;
            }

            .checkout-info-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

    <header class="site-header">
        <a href="index.php" class="brand">TradeNest</a>

        <nav class="desktop-nav">
            <a href="browse.php">Browse</a>
            <a href="sell.php">Sell</a>
            <a href="dashboard.php">Dashboard</a>
            <a href="faq.php">Help</a>
            <a href="admin-login.php">Admin</a>
        </nav>

        <div class="header-actions">
            <a href="dashboard.php" class="login-link">
                Hi, <?php echo htmlspecialchars($firstName); ?>
            </a>
            <a href="logout.php" class="join-btn">Logout</a>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="browse.php">Browse</a>
        <a href="sell.php">Sell</a>
        <a href="dashboard.php">Dashboard</a>
        <a href="faq.php">Help</a>
        <a href="admin-login.php">Admin</a>
        <a href="logout.php">Logout</a>
    </nav>

    <main>

        <section class="admin-page-hero">
            <div>
                <p class="section-label">Checkout</p>
                <h1>Confirm your local order.</h1>
                <p>
                    Review the product, seller, location and order total before continuing to the payment step.
                    This creates a pending order record linked to your buyer account.
                </p>
            </div>

            <div class="admin-hero-card">
                <span>Secure checkout</span>
                <h3>Order first, payment next.</h3>
                <p>
                    The checkout page creates the order record, then redirects you to the payment page to complete the transaction.
                </p>
            </div>
        </section>

        <section class="checkout-page-layout">

            <div class="checkout-main">

                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Selected item</p>
                            <h2>Order details</h2>
                        </div>

                        <a href="product.php?id=<?php echo $product_id; ?>">Back to product</a>
                    </div>

                    <?php if (!empty($error_message)) { ?>
                        <div class="checkout-error-box">
                            <?php echo htmlspecialchars($error_message); ?>
                        </div>
                    <?php } ?>

                    <div class="checkout-product-card">
                        <div 
                            class="checkout-product-image" 
                            style="background-image: url('<?php echo htmlspecialchars($productImage); ?>');"
                        ></div>

                        <div>
                            <h3><?php echo htmlspecialchars($product["product_name"]); ?></h3>

                            <p>
                                <?php echo htmlspecialchars($product["product_description"]); ?>
                            </p>

                            <span class="checkout-product-price">
                                R<?php echo htmlspecialchars(number_format($product["price"], 2)); ?>
                            </span>
                        </div>
                    </div>

                    <div class="checkout-info-grid">
                        <div class="checkout-info-card">
                            <span>Buyer</span>
                            <strong><?php echo htmlspecialchars($buyer_name); ?></strong>
                        </div>

                        <div class="checkout-info-card">
                            <span>Seller</span>
                            <strong><?php echo htmlspecialchars($product["first_name"] . " " . $product["last_name"]); ?></strong>
                        </div>

                        <div class="checkout-info-card">
                            <span>Category</span>
                            <strong><?php echo htmlspecialchars($product["category_name"]); ?></strong>
                        </div>

                        <div class="checkout-info-card">
                            <span>Condition</span>
                            <strong><?php echo htmlspecialchars($product["product_condition"]); ?></strong>
                        </div>

                        <div class="checkout-info-card">
                            <span>Location</span>
                            <strong><?php echo htmlspecialchars($product["location"]); ?></strong>
                        </div>

                        <div class="checkout-info-card">
                            <span>Listing status</span>
                            <strong><?php echo htmlspecialchars($product["listing_status"]); ?></strong>
                        </div>
                    </div>
                </section>

                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Checkout flow</p>
                            <h2>What happens next?</h2>
                        </div>
                    </div>

                    <div class="checkout-steps-grid">
                        <article class="checkout-step-card">
                            <span>01</span>
                            <h3>Order is created</h3>
                            <p>
                                The system creates an order record using the buyer, seller, product and total amount.
                            </p>
                        </article>

                        <article class="checkout-step-card">
                            <span>02</span>
                            <h3>Payment is completed</h3>
                            <p>
                                You continue to the payment page where a payment record and transaction reference are created.
                            </p>
                        </article>

                        <article class="checkout-step-card">
                            <span>03</span>
                            <h3>Admin can track it</h3>
                            <p>
                                The order appears in the admin orders page for support, tracking and status updates.
                            </p>
                        </article>
                    </div>
                </section>

            </div>

            <aside class="admin-section checkout-summary-card">
                <div class="admin-section-heading">
                    <div>
                        <p class="section-label">Order summary</p>
                        <h2>Payment step</h2>
                    </div>
                </div>

                <div class="checkout-summary-row">
                    <span>Product price</span>
                    <strong>R<?php echo htmlspecialchars(number_format($product["price"], 2)); ?></strong>
                </div>

                <div class="checkout-summary-row">
                    <span>Platform fee</span>
                    <strong>R0.00</strong>
                </div>

                <div class="checkout-summary-row">
                    <span>Total</span>
                    <strong class="checkout-total">R<?php echo htmlspecialchars(number_format($product["price"], 2)); ?></strong>
                </div>

                <div class="checkout-notice">
                    <h3>Before continuing</h3>
                    <p>
                        Make sure the product details, seller and price are correct. Once you continue,
                        a pending order will be created.
                    </p>
                </div>

                <form method="POST" action="checkout.php?id=<?php echo $product_id; ?>" class="checkout-actions">
                    <?php if (empty($error_message)) { ?>
                        <button type="submit" class="primary-form-btn">
                            Place order and continue
                        </button>
                    <?php } ?>

                    <a href="product.php?id=<?php echo $product_id; ?>" class="secondary-form-btn">
                        Back to product
                    </a>

                    <a href="browse.php" class="secondary-form-btn">
                        Continue browsing
                    </a>
                </form>
            </aside>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest</p>
        <p>Checkout page connected to orders, products, users and payment flow.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>

<?php
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>