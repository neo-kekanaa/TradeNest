<?php
session_start();
include "db_connect.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$adminRoles = ["Super Admin", "Product Moderator", "Support Staff"];

if (in_array($_SESSION["role_name"], $adminRoles)) {
    header("Location: admin-dashboard.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$firstName = $_SESSION["first_name"];
$lastName = $_SESSION["last_name"];
$roleName = $_SESSION["role_name"];
$userInitial = strtoupper(substr($firstName, 0, 1));

function getProductImage($imageUrl, $categoryName) {
    if (!empty($imageUrl)) {
        return $imageUrl;
    }

    $images = [
        "Fashion" => "https://images.unsplash.com/photo-1523398002811-999ca8dec234?auto=format&fit=crop&w=900&q=80",
        "Electronics" => "https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=900&q=80",
        "Furniture" => "https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?auto=format&fit=crop&w=900&q=80",
        "Books" => "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&w=900&q=80",
        "Beauty" => "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=900&q=80",
        "Handmade" => "assets/images/handmade-community.png"
    ];

    return $images[$categoryName] ?? "assets/images/hero-community.png";
}

function getStatusClass($status) {
    $status = strtolower($status);

    if ($status === "approved" || $status === "active" || $status === "paid" || $status === "completed" || $status === "resolved") {
        return "completed";
    }

    return "";
}

$activeListingsSql = "SELECT COUNT(*) AS total FROM products WHERE seller_id = ? AND listing_status = 'Approved'";
$activeListingsStmt = mysqli_prepare($conn, $activeListingsSql);
mysqli_stmt_bind_param($activeListingsStmt, "i", $user_id);
mysqli_stmt_execute($activeListingsStmt);
$activeListingsResult = mysqli_stmt_get_result($activeListingsStmt);
$activeListings = mysqli_fetch_assoc($activeListingsResult)["total"];

$pendingListingsSql = "SELECT COUNT(*) AS total FROM products WHERE seller_id = ? AND listing_status = 'Pending review'";
$pendingListingsStmt = mysqli_prepare($conn, $pendingListingsSql);
mysqli_stmt_bind_param($pendingListingsStmt, "i", $user_id);
mysqli_stmt_execute($pendingListingsStmt);
$pendingListingsResult = mysqli_stmt_get_result($pendingListingsStmt);
$pendingListings = mysqli_fetch_assoc($pendingListingsResult)["total"];

$ordersPlacedSql = "SELECT COUNT(*) AS total FROM orders WHERE buyer_id = ?";
$ordersPlacedStmt = mysqli_prepare($conn, $ordersPlacedSql);
mysqli_stmt_bind_param($ordersPlacedStmt, "i", $user_id);
mysqli_stmt_execute($ordersPlacedStmt);
$ordersPlacedResult = mysqli_stmt_get_result($ordersPlacedStmt);
$ordersPlaced = mysqli_fetch_assoc($ordersPlacedResult)["total"];

$ordersReceivedSql = "SELECT COUNT(*) AS total FROM orders WHERE seller_id = ?";
$ordersReceivedStmt = mysqli_prepare($conn, $ordersReceivedSql);
mysqli_stmt_bind_param($ordersReceivedStmt, "i", $user_id);
mysqli_stmt_execute($ordersReceivedStmt);
$ordersReceivedResult = mysqli_stmt_get_result($ordersReceivedStmt);
$ordersReceived = mysqli_fetch_assoc($ordersReceivedResult)["total"];

$reportsSubmittedSql = "SELECT COUNT(*) AS total FROM reports WHERE reporter_id = ?";
$reportsSubmittedStmt = mysqli_prepare($conn, $reportsSubmittedSql);
mysqli_stmt_bind_param($reportsSubmittedStmt, "i", $user_id);
mysqli_stmt_execute($reportsSubmittedStmt);
$reportsSubmittedResult = mysqli_stmt_get_result($reportsSubmittedStmt);
$reportsSubmitted = mysqli_fetch_assoc($reportsSubmittedResult)["total"];

$recentListingsSql = "SELECT 
                        products.product_id,
                        products.product_name,
                        products.price,
                        products.location,
                        products.image_url,
                        products.listing_status,
                        products.created_at,
                        categories.category_name
                      FROM products
                      INNER JOIN categories ON products.category_id = categories.category_id
                      WHERE products.seller_id = ?
                      ORDER BY products.created_at DESC
                      LIMIT 3";

$recentListingsStmt = mysqli_prepare($conn, $recentListingsSql);
mysqli_stmt_bind_param($recentListingsStmt, "i", $user_id);
mysqli_stmt_execute($recentListingsStmt);
$recentListingsResult = mysqli_stmt_get_result($recentListingsStmt);

$recentOrdersSql = "SELECT 
                        orders.order_id,
                        orders.order_status,
                        orders.total_amount,
                        orders.order_date,
                        products.product_id,
                        products.product_name,
                        products.image_url,
                        categories.category_name,
                        seller.first_name AS seller_first_name,
                        seller.last_name AS seller_last_name
                    FROM orders
                    INNER JOIN products ON orders.product_id = products.product_id
                    INNER JOIN categories ON products.category_id = categories.category_id
                    INNER JOIN users AS seller ON orders.seller_id = seller.user_id
                    WHERE orders.buyer_id = ?
                    ORDER BY orders.order_date DESC
                    LIMIT 3";

$recentOrdersStmt = mysqli_prepare($conn, $recentOrdersSql);
mysqli_stmt_bind_param($recentOrdersStmt, "i", $user_id);
mysqli_stmt_execute($recentOrdersStmt);
$recentOrdersResult = mysqli_stmt_get_result($recentOrdersStmt);

$recentSalesSql = "SELECT 
                        orders.order_id,
                        orders.order_status,
                        orders.total_amount,
                        orders.order_date,
                        products.product_id,
                        products.product_name,
                        products.image_url,
                        categories.category_name,
                        buyer.first_name AS buyer_first_name,
                        buyer.last_name AS buyer_last_name
                    FROM orders
                    INNER JOIN products ON orders.product_id = products.product_id
                    INNER JOIN categories ON products.category_id = categories.category_id
                    INNER JOIN users AS buyer ON orders.buyer_id = buyer.user_id
                    WHERE orders.seller_id = ?
                    ORDER BY orders.order_date DESC
                    LIMIT 3";

$recentSalesStmt = mysqli_prepare($conn, $recentSalesSql);
mysqli_stmt_bind_param($recentSalesStmt, "i", $user_id);
mysqli_stmt_execute($recentSalesStmt);
$recentSalesResult = mysqli_stmt_get_result($recentSalesStmt);

$recentReportsSql = "SELECT 
                        reports.report_id,
                        reports.report_reason,
                        reports.report_status,
                        reports.report_date,
                        products.product_id,
                        products.product_name
                    FROM reports
                    INNER JOIN products ON reports.product_id = products.product_id
                    WHERE reports.reporter_id = ?
                    ORDER BY reports.report_date DESC
                    LIMIT 2";

$recentReportsStmt = mysqli_prepare($conn, $recentReportsSql);
mysqli_stmt_bind_param($recentReportsStmt, "i", $user_id);
mysqli_stmt_execute($recentReportsStmt);
$recentReportsResult = mysqli_stmt_get_result($recentReportsStmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .dashboard-actions-row {
            display: flex;
            gap: 14px;
            flex-wrap: wrap;
            margin-top: 22px;
        }

        .dashboard-actions-row a {
            text-decoration: none;
        }

        .mini-img {
            background-size: cover;
            background-position: center;
            flex-shrink: 0;
        }

        .dashboard-empty-state {
            padding: 24px;
            border-radius: 28px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
            color: var(--muted);
            font-weight: 800;
            line-height: 1.7;
        }

        .dashboard-support-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 18px;
        }

        .dashboard-support-card {
            padding: 24px;
            border-radius: 28px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
        }

        .dashboard-support-card span {
            display: block;
            color: var(--clay);
            font-size: 0.72rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            margin-bottom: 10px;
        }

        .dashboard-support-card h3 {
            color: var(--espresso);
            font-size: 1.15rem;
            margin-bottom: 10px;
        }

        .dashboard-support-card p {
            color: var(--muted);
            line-height: 1.7;
            font-weight: 700;
            font-size: 0.95rem;
        }

        .report-mini-card {
            padding: 20px;
            border-radius: 26px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
            margin-bottom: 14px;
        }

        .report-mini-card p {
            color: var(--muted);
            line-height: 1.7;
            font-weight: 700;
            margin-top: 6px;
        }

        .report-mini-card h3 {
            color: var(--espresso);
            margin-top: 8px;
            letter-spacing: -0.5px;
        }

        .report-mini-card span {
            display: inline-flex;
            margin-top: 12px;
            padding: 7px 12px;
            border-radius: 999px;
            background: rgba(198, 90, 44, 0.14);
            color: #a6532e;
            font-weight: 900;
            font-size: 0.78rem;
        }

        @media (max-width: 900px) {
            .dashboard-support-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

    <header class="site-header">
        <a href="index.php" class="brand">TradeNest</a>

        <nav class="desktop-nav">
            <a href="browse.php">Browse</a>
            <a href="sell.php">Sell</a>
            <a href="dashboard.php">Dashboard</a>
            <a href="faq.php">Help</a>
            <a href="admin-login.php">Admin</a>
        </nav>

        <div class="header-actions">
            <a href="logout.php" class="login-link">Logout</a>
            <a href="sell.php" class="join-btn">List item</a>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="browse.php">Browse</a>
        <a href="sell.php">Sell</a>
        <a href="dashboard.php">Dashboard</a>
        <a href="faq.php">Help</a>
        <a href="admin-login.php">Admin</a>
        <a href="logout.php">Logout</a>
    </nav>

    <main>

        <!-- DASHBOARD HERO -->
        <section class="dashboard-hero">
            <div>
                <p class="section-label">User dashboard</p>
                <h1>Welcome back, <?php echo htmlspecialchars($firstName); ?>.</h1>
                <p>
                    Manage your listings, track orders, review reports and keep your TradeNest profile activity organised.
                </p>

                <div class="dashboard-actions-row">
                    <a href="sell.php" class="join-btn">List a new item</a>
                    <a href="browse.php" class="login-link">Browse products</a>
                    <a href="contact.php" class="login-link">Contact support</a>
                </div>
            </div>

            <a href="sell.php" class="dashboard-cta">List a new item</a>
        </section>

        <!-- DASHBOARD LAYOUT -->
        <section class="dashboard-layout">

            <aside class="dashboard-sidebar">
                <div class="profile-card">
                    <div class="profile-avatar"><?php echo htmlspecialchars($userInitial); ?></div>
                    <h3><?php echo htmlspecialchars($firstName . " " . $lastName); ?></h3>
                    <p><?php echo htmlspecialchars($roleName); ?></p>
                    <span>Active profile</span>
                </div>

                <nav class="dashboard-menu">
                    <a href="dashboard.php" class="active">Overview</a>
                    <a href="sell.php">My listings</a>
                    <a href="browse.php">Browse items</a>
                    <a href="faq.php">Help Centre</a>
                    <a href="contact.php">Support</a>
                    <a href="logout.php">Logout</a>
                </nav>
            </aside>

            <div class="dashboard-main">

                <!-- METRICS -->
                <div class="dashboard-metrics">
                    <article class="metric-card">
                        <p>Active listings</p>
                        <h3><?php echo $activeListings; ?></h3>
                        <span><?php echo $pendingListings; ?> pending approval</span>
                    </article>

                    <article class="metric-card">
                        <p>Orders placed</p>
                        <h3><?php echo $ordersPlaced; ?></h3>
                        <span><?php echo $ordersReceived; ?> order(s) received</span>
                    </article>

                    <article class="metric-card">
                        <p>Reports submitted</p>
                        <h3><?php echo $reportsSubmitted; ?></h3>
                        <span>Safety and product concerns</span>
                    </article>
                </div>

                <!-- RECENT LISTINGS -->
                <div class="dashboard-section">
                    <div class="dashboard-section-heading">
                        <div>
                            <p class="section-label">Selling activity</p>
                            <h2>My recent listings</h2>
                        </div>

                        <a href="sell.php">Add listing</a>
                    </div>

                    <div class="dashboard-listings">

                        <?php if (mysqli_num_rows($recentListingsResult) > 0) { ?>
                            <?php while ($listing = mysqli_fetch_assoc($recentListingsResult)) { ?>
                                <?php
                                    $listingImage = getProductImage($listing["image_url"], $listing["category_name"]);
                                ?>

                                <article class="mini-listing">
                                    <div 
                                        class="mini-img" 
                                        style="background-image: url('<?php echo htmlspecialchars($listingImage); ?>');"
                                    ></div>

                                    <div>
                                        <p>
                                            <?php echo htmlspecialchars($listing["location"]); ?> · 
                                            <?php echo htmlspecialchars($listing["category_name"]); ?>
                                        </p>

                                        <h3><?php echo htmlspecialchars($listing["product_name"]); ?></h3>

                                        <span>
                                            R<?php echo htmlspecialchars(number_format($listing["price"], 2)); ?> · 
                                            <?php echo htmlspecialchars($listing["listing_status"]); ?>
                                        </span>
                                    </div>
                                </article>
                            <?php } ?>
                        <?php } else { ?>
                            <div class="dashboard-empty-state">
                                You have not listed any products yet. Once you create a listing, it will appear here with its approval status.
                            </div>
                        <?php } ?>

                    </div>
                </div>

                <!-- ORDERS -->
                <div class="dashboard-section">
                    <div class="dashboard-section-heading">
                        <div>
                            <p class="section-label">Buying activity</p>
                            <h2>Recent orders</h2>
                        </div>

                        <a href="browse.php">Continue shopping</a>
                    </div>

                    <div class="orders-table">
                        <div class="order-row table-heading">
                            <span>Item</span>
                            <span>Seller</span>
                            <span>Status</span>
                            <span>Total</span>
                        </div>

                        <?php if (mysqli_num_rows($recentOrdersResult) > 0) { ?>
                            <?php while ($order = mysqli_fetch_assoc($recentOrdersResult)) { ?>
                                <div class="order-row">
                                    <span><?php echo htmlspecialchars($order["product_name"]); ?></span>
                                    <span><?php echo htmlspecialchars($order["seller_first_name"] . " " . $order["seller_last_name"]); ?></span>

                                    <span class="status-pill <?php echo getStatusClass($order["order_status"]); ?>">
                                        <?php echo htmlspecialchars($order["order_status"]); ?>
                                    </span>

                                    <span>R<?php echo htmlspecialchars(number_format($order["total_amount"], 2)); ?></span>
                                </div>
                            <?php } ?>
                        <?php } else { ?>
                            <div class="order-row">
                                <span>No orders yet</span>
                                <span>-</span>
                                <span class="status-pill">Empty</span>
                                <span>R0.00</span>
                            </div>
                        <?php } ?>
                    </div>
                </div>

                <!-- SALES -->
                <div class="dashboard-section">
                    <div class="dashboard-section-heading">
                        <div>
                            <p class="section-label">Seller activity</p>
                            <h2>Orders received</h2>
                        </div>

                        <a href="sell.php">Manage selling</a>
                    </div>

                    <div class="orders-table">
                        <div class="order-row table-heading">
                            <span>Item</span>
                            <span>Buyer</span>
                            <span>Status</span>
                            <span>Total</span>
                        </div>

                        <?php if (mysqli_num_rows($recentSalesResult) > 0) { ?>
                            <?php while ($sale = mysqli_fetch_assoc($recentSalesResult)) { ?>
                                <div class="order-row">
                                    <span><?php echo htmlspecialchars($sale["product_name"]); ?></span>
                                    <span><?php echo htmlspecialchars($sale["buyer_first_name"] . " " . $sale["buyer_last_name"]); ?></span>

                                    <span class="status-pill <?php echo getStatusClass($sale["order_status"]); ?>">
                                        <?php echo htmlspecialchars($sale["order_status"]); ?>
                                    </span>

                                    <span>R<?php echo htmlspecialchars(number_format($sale["total_amount"], 2)); ?></span>
                                </div>
                            <?php } ?>
                        <?php } else { ?>
                            <div class="order-row">
                                <span>No sales yet</span>
                                <span>-</span>
                                <span class="status-pill">Empty</span>
                                <span>R0.00</span>
                            </div>
                        <?php } ?>
                    </div>
                </div>

                <!-- REPORTS AND SUPPORT -->
                <div class="dashboard-section">
                    <div class="dashboard-section-heading">
                        <div>
                            <p class="section-label">Safety activity</p>
                            <h2>My recent reports</h2>
                        </div>

                        <a href="faq.php">Safety help</a>
                    </div>

                    <?php if (mysqli_num_rows($recentReportsResult) > 0) { ?>
                        <?php while ($report = mysqli_fetch_assoc($recentReportsResult)) { ?>
                            <article class="report-mini-card">
                                <p>
                                    Report #<?php echo htmlspecialchars($report["report_id"]); ?> · 
                                    <?php echo htmlspecialchars($report["report_date"]); ?>
                                </p>

                                <h3><?php echo htmlspecialchars($report["product_name"]); ?></h3>

                                <p><?php echo htmlspecialchars($report["report_reason"]); ?></p>

                                <span><?php echo htmlspecialchars($report["report_status"]); ?></span>
                            </article>
                        <?php } ?>
                    <?php } else { ?>
                        <div class="dashboard-empty-state">
                            You have not submitted any product reports yet. If a listing looks suspicious, open the product page and use the report option.
                        </div>
                    <?php } ?>
                </div>

                <div class="dashboard-section">
                    <div class="dashboard-section-heading">
                        <div>
                            <p class="section-label">Support options</p>
                            <h2>Quick actions</h2>
                        </div>
                    </div>

                    <div class="dashboard-support-grid">
                        <article class="dashboard-support-card">
                            <span>01</span>
                            <h3>Need help buying?</h3>
                            <p>
                                Visit the Help Centre or contact support for checkout, order or payment assistance.
                            </p>
                        </article>

                        <article class="dashboard-support-card">
                            <span>02</span>
                            <h3>Need help selling?</h3>
                            <p>
                                Sellers can request help with listings, pending approvals or product moderation.
                            </p>
                        </article>

                        <article class="dashboard-support-card">
                            <span>03</span>
                            <h3>Safety concern?</h3>
                            <p>
                                Suspicious products can be reported from product pages and reviewed by authorised admin users.
                            </p>
                        </article>
                    </div>
                </div>

            </div>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest</p>
        <p>User dashboard for buyer activity, seller listings, orders, reports and support access.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>

<?php
mysqli_stmt_close($activeListingsStmt);
mysqli_stmt_close($pendingListingsStmt);
mysqli_stmt_close($ordersPlacedStmt);
mysqli_stmt_close($ordersReceivedStmt);
mysqli_stmt_close($reportsSubmittedStmt);
mysqli_stmt_close($recentListingsStmt);
mysqli_stmt_close($recentOrdersStmt);
mysqli_stmt_close($recentSalesStmt);
mysqli_stmt_close($recentReportsStmt);
mysqli_close($conn);
?>