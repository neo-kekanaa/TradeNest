<?php
include "db_connect.php";

$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;

if ($order_id <= 0) {
    die("Invalid order reference.");
}

$sql = "SELECT 
            orders.order_id,
            orders.order_status,
            orders.total_amount,
            orders.order_date,
            products.product_name,
            products.location,
            categories.category_name,
            buyer.first_name AS buyer_first_name,
            buyer.last_name AS buyer_last_name,
            seller.first_name AS seller_first_name,
            seller.last_name AS seller_last_name,
            payments.payment_method,
            payments.payment_status,
            payments.payment_amount,
            payments.payment_date,
            payments.transaction_reference
        FROM orders
        INNER JOIN products ON orders.product_id = products.product_id
        INNER JOIN categories ON products.category_id = categories.category_id
        INNER JOIN users AS buyer ON orders.buyer_id = buyer.user_id
        INNER JOIN users AS seller ON orders.seller_id = seller.user_id
        LEFT JOIN payments ON orders.order_id = payments.order_id
        WHERE orders.order_id = ?
        ORDER BY payments.payment_id DESC
        LIMIT 1";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $order_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) === 0) {
    die("Order not found.");
}

$order = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .success-page {
            width: calc(100% - 48px);
            max-width: 1340px;
            margin: 34px auto 120px;
        }

        .success-hero {
            min-height: 520px;
            padding: 70px;
            border-radius: 46px;
            color: var(--paper);
            background:
                linear-gradient(90deg, rgba(9, 8, 7, 0.92), rgba(9, 8, 7, 0.28)),
                url("assets/images/hero-community.png");
            background-size: cover;
            background-position: center;
            box-shadow: var(--shadow);
            margin-bottom: 34px;
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
        }

        .success-badge {
            width: 78px;
            height: 78px;
            border-radius: 50%;
            display: grid;
            place-items: center;
            background: rgba(84, 211, 107, 0.22);
            border: 1px solid rgba(84, 211, 107, 0.55);
            color: #ffffff;
            font-size: 2.2rem;
            font-weight: 900;
            margin-bottom: 26px;
        }

        .success-hero h1 {
            font-size: clamp(3.8rem, 7vw, 7.8rem);
            line-height: 0.88;
            letter-spacing: -6px;
            max-width: 900px;
        }

        .success-hero p:not(.section-label) {
            max-width: 650px;
            margin-top: 24px;
            color: rgba(255, 248, 239, 0.74);
            line-height: 1.85;
        }

        .success-layout {
            display: grid;
            grid-template-columns: 1fr 0.9fr;
            gap: 28px;
            align-items: start;
        }

        .success-card,
        .receipt-card {
            padding: 38px;
            border-radius: 42px;
            background: rgba(255, 248, 239, 0.66);
            border: 1px solid rgba(38, 24, 20, 0.08);
            box-shadow: var(--soft-shadow);
        }

        .success-card h2,
        .receipt-card h2 {
            font-size: clamp(2.6rem, 4vw, 4.8rem);
            line-height: 0.92;
            letter-spacing: -4px;
            margin-bottom: 24px;
        }

        .success-card p:not(.section-label) {
            color: var(--muted);
            line-height: 1.85;
            margin-bottom: 24px;
        }

        .next-steps {
            display: grid;
            gap: 14px;
            margin-top: 26px;
        }

        .next-step {
            padding: 18px;
            border-radius: 24px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
        }

        .next-step strong {
            display: block;
            color: var(--espresso);
            margin-bottom: 6px;
        }

        .next-step span {
            color: var(--muted);
            line-height: 1.6;
        }

        .receipt-row {
            display: flex;
            justify-content: space-between;
            gap: 18px;
            padding: 18px 0;
            border-bottom: 1px solid rgba(38, 24, 20, 0.10);
            color: var(--muted);
        }

        .receipt-row strong {
            color: var(--espresso);
            text-align: right;
        }

        .receipt-total {
            font-size: 1.8rem;
            font-weight: 900;
            color: var(--espresso);
        }

        .status-success {
            width: fit-content;
            padding: 8px 12px;
            border-radius: 999px;
            background: rgba(84, 211, 107, 0.16);
            color: #2f7c43;
            font-weight: 900;
        }

        .success-actions {
            margin-top: 30px;
            display: flex;
            flex-wrap: wrap;
            gap: 14px;
        }

        .success-btn,
        .secondary-success-btn {
            min-height: 54px;
            padding: 16px 24px;
            border-radius: 999px;
            font-weight: 900;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: 0.3s ease;
        }

        .success-btn {
            background: var(--espresso);
            color: var(--paper);
        }

        .secondary-success-btn {
            background: rgba(38, 24, 20, 0.08);
            color: var(--espresso);
        }

        .success-btn:hover,
        .secondary-success-btn:hover {
            transform: translateY(-4px);
            box-shadow: var(--soft-shadow);
        }

        @media (max-width: 1050px) {
            .success-layout {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 680px) {
            .success-page {
                width: calc(100% - 28px);
                margin-top: 20px;
            }

            .success-hero {
                padding: 34px;
                border-radius: 34px;
                min-height: 560px;
            }

            .success-hero h1 {
                font-size: 3.6rem;
                letter-spacing: -3.5px;
            }

            .success-card,
            .receipt-card {
                padding: 24px;
                border-radius: 32px;
            }

            .receipt-row {
                flex-direction: column;
                gap: 6px;
            }

            .receipt-row strong {
                text-align: left;
            }

            .success-actions {
                flex-direction: column;
            }

            .success-btn,
            .secondary-success-btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>

    <header class="site-header">
        <a href="index.php" class="brand">TradeNest</a>

        <nav class="desktop-nav">
            <a href="browse.php">Browse</a>
            <a href="sell.php">Sell</a>
            <a href="#">Community</a>
            <a href="logout.php">Admin</a>
        </nav>

        <div class="header-actions">
            <a href="login.php" class="login-link">Login</a>
            <a href="register.php" class="join-btn">Join now</a>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="browse.php">Browse</a>
        <a href="sell.php">Sell</a>
        <a href="#">Community</a>
        <a href="logout.php">Admin</a>
        <a href="login.php">Login</a>
        <a href="register.php">Join now</a>
    </nav>

    <main class="success-page">

        <section class="success-hero">
            <div class="success-badge">✓</div>

            <p class="section-label">Payment successful</p>

            <h1>Your local order is confirmed.</h1>

            <p>
                The payment has been recorded and the order status has been updated in the TradeNest database.
                The seller can now prepare the item for collection or delivery.
            </p>
        </section>

        <section class="success-layout">

            <div class="success-card">
                <p class="section-label">What happens next?</p>
                <h2>Order complete</h2>

                <p>
                    This page confirms that the order and payment process has been completed successfully. The buyer can continue shopping or view the completed order from their dashboard.
                </p>

                <div class="next-steps">
                    <div class="next-step">
                        <strong>1. Order created</strong>
                        <span>The buyer’s order was saved in the orders table.</span>
                    </div>

                    <div class="next-step">
                        <strong>2. Payment recorded</strong>
                        <span>The payment details were saved in the payments table.</span>
                    </div>

                    <div class="next-step">
                        <strong>3. Seller notified</strong>
                        <span>In a full production version, the seller would receive an order notification.</span>
                    </div>
                </div>

                <div class="success-actions">
                    <a href="browse.php" class="success-btn">
                        Continue shopping
                    </a>

                    <a href="dashboard.php" class="secondary-success-btn">
                        View dashboard
                    </a>
                </div>
            </div>

            <aside class="receipt-card">
                <p class="section-label">Receipt</p>
                <h2>Order #<?php echo htmlspecialchars($order['order_id']); ?></h2>

                <div class="receipt-row">
                    <span>Product</span>
                    <strong><?php echo htmlspecialchars($order['product_name']); ?></strong>
                </div>

                <div class="receipt-row">
                    <span>Category</span>
                    <strong><?php echo htmlspecialchars($order['category_name']); ?></strong>
                </div>

                <div class="receipt-row">
                    <span>Buyer</span>
                    <strong><?php echo htmlspecialchars($order['buyer_first_name'] . " " . $order['buyer_last_name']); ?></strong>
                </div>

                <div class="receipt-row">
                    <span>Seller</span>
                    <strong><?php echo htmlspecialchars($order['seller_first_name'] . " " . $order['seller_last_name']); ?></strong>
                </div>

                <div class="receipt-row">
                    <span>Payment method</span>
                    <strong><?php echo htmlspecialchars($order['payment_method'] ?? 'Demo payment'); ?></strong>
                </div>

                <div class="receipt-row">
                    <span>Payment status</span>
                    <strong class="status-success"><?php echo htmlspecialchars($order['payment_status'] ?? 'Successful'); ?></strong>
                </div>

                <div class="receipt-row">
                    <span>Transaction reference</span>
                    <strong><?php echo htmlspecialchars($order['transaction_reference'] ?? 'N/A'); ?></strong>
                </div>

                <div class="receipt-row">
                    <span>Order status</span>
                    <strong><?php echo htmlspecialchars($order['order_status']); ?></strong>
                </div>

                <div class="receipt-row">
                    <span>Total paid</span>
                    <strong class="receipt-total">R<?php echo htmlspecialchars(number_format($order['total_amount'], 2)); ?></strong>
                </div>
            </aside>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest</p>
        <p>Payment success page connected to MySQL orders and payments.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>

<?php
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>