<?php
session_start();

$isLoggedIn = isset($_SESSION["user_id"]);
$firstName = $isLoggedIn ? $_SESSION["first_name"] : "";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help Centre | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .faq-page-layout {
            width: calc(100% - 48px);
            max-width: 1340px;
            margin: 0 auto 120px;
            display: grid;
            grid-template-columns: 0.34fr 0.66fr;
            gap: 28px;
            align-items: flex-start;
        }

        .faq-main {
            display: grid;
            gap: 28px;
        }

        .faq-grid {
            display: grid;
            gap: 18px;
        }

        .faq-card {
            padding: 26px;
            border-radius: 28px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
        }

        .faq-card span {
            display: block;
            color: var(--clay);
            font-size: 0.72rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            margin-bottom: 10px;
        }

        .faq-card h3 {
            color: var(--espresso);
            font-size: 1.25rem;
            margin-bottom: 10px;
            letter-spacing: -0.5px;
        }

        .faq-card p {
            color: var(--muted);
            line-height: 1.75;
            font-weight: 700;
            font-size: 0.96rem;
        }

        .support-info-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 18px;
        }

        .support-info-card {
            padding: 24px;
            border-radius: 28px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
        }

        .support-info-card span {
            display: block;
            color: var(--clay);
            font-size: 0.72rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            margin-bottom: 10px;
        }

        .support-info-card h3 {
            color: var(--espresso);
            font-size: 1.2rem;
            margin-bottom: 10px;
        }

        .support-info-card p {
            color: var(--muted);
            line-height: 1.7;
            font-weight: 700;
            font-size: 0.95rem;
        }

        .faq-highlight-card {
            padding: 30px;
            border-radius: 32px;
            background: var(--soft-black);
            color: var(--paper);
            box-shadow: var(--shadow);
        }

        .faq-highlight-card span {
            display: block;
            color: var(--sand);
            font-size: 0.72rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            margin-bottom: 10px;
        }

        .faq-highlight-card h3 {
            font-size: 1.7rem;
            margin-bottom: 10px;
            letter-spacing: -1px;
        }

        .faq-highlight-card p {
            color: rgba(255, 248, 239, 0.72);
            line-height: 1.7;
            font-weight: 700;
        }

        .faq-action-row {
            display: flex;
            gap: 14px;
            flex-wrap: wrap;
            margin-top: 24px;
        }

        .faq-action-row a {
            text-decoration: none;
        }

        @media (max-width: 1050px) {
            .faq-page-layout {
                grid-template-columns: 1fr;
            }

            .support-info-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 680px) {
            .faq-page-layout {
                width: calc(100% - 28px);
            }
        }
    </style>
</head>
<body>

    <header class="site-header">
        <a href="index.php" class="brand">TradeNest</a>

        <nav class="desktop-nav">
            <a href="browse.php">Browse</a>
            <a href="sell.php">Sell</a>
            <a href="faq.php">Help</a>
            <a href="admin-login.php">Admin</a>
        </nav>

        <div class="header-actions">
            <?php if ($isLoggedIn) { ?>
                <a href="dashboard.php" class="login-link">
                    Hi, <?php echo htmlspecialchars($firstName); ?>
                </a>
                <a href="logout.php" class="join-btn">Logout</a>
            <?php } else { ?>
                <a href="login.php" class="login-link">Login</a>
                <a href="register.php" class="join-btn">Join now</a>
            <?php } ?>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="browse.php">Browse</a>
        <a href="sell.php">Sell</a>
        <a href="faq.php">Help</a>
        <a href="admin-login.php">Admin</a>

        <?php if ($isLoggedIn) { ?>
            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        <?php } else { ?>
            <a href="login.php">Login</a>
            <a href="register.php">Join now</a>
        <?php } ?>
    </nav>

    <main>

        <section class="admin-page-hero">
            <div>
                <p class="section-label">Help Centre</p>
                <h1>Answers before you need to ask.</h1>
                <p>
                    Find quick guidance on buying, selling, payments, product moderation, reporting suspicious listings
                    and getting support from TradeNest.
                </p>
            </div>

            <div class="admin-hero-card">
                <span>Support access</span>
                <h3>Need more than an FAQ?</h3>
                <p>
                    Users can submit a support request if they need help with accounts, orders, product concerns or safety issues.
                </p>
            </div>
        </section>

        <section class="faq-page-layout">

            <aside class="admin-sidebar-panel">
                <div class="admin-profile-card">
                    <div class="admin-avatar">?</div>
                    <h3>Help Centre</h3>
                    <p>Marketplace support</p>
                    <span>User guidance</span>
                </div>

                <nav class="admin-side-menu">
                    <a href="faq.php" class="active">Help Centre</a>
                    <a href="contact.php">Contact support</a>
                    <a href="terms.php">Terms and conditions</a>
                    <a href="browse.php">Browse products</a>
                    <a href="sell.php">Start selling</a>
                    <a href="login.php">User login</a>
                    <a href="admin-login.php">Admin login</a>
                </nav>
            </aside>

            <div class="faq-main">

                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Common questions</p>
                            <h2>Using TradeNest</h2>
                        </div>

                        <a href="contact.php">Contact support</a>
                    </div>

                    <div class="faq-grid">

                        <article class="faq-card">
                            <span>Buying</span>
                            <h3>How do I buy a product?</h3>
                            <p>
                                Browse approved listings, open a product page, review the seller and product details, then continue to checkout.
                                The order is linked to your user account so the system can track buyer, seller and product records.
                            </p>
                        </article>

                        <article class="faq-card">
                            <span>Selling</span>
                            <h3>How do I list a product for sale?</h3>
                            <p>
                                Register or log in as a seller, go to the Sell page, and submit the product details.
                                New listings are submitted for review before they appear as approved marketplace products.
                            </p>
                        </article>

                        <article class="faq-card">
                            <span>Moderation</span>
                            <h3>Why does my product need approval?</h3>
                            <p>
                                Product approval helps keep listings safe, organised and useful. Admin users can review pending products,
                                approve suitable items, flag suspicious listings or remove products that do not meet platform rules.
                            </p>
                        </article>

                        <article class="faq-card">
                            <span>Payments</span>
                            <h3>How are payments handled?</h3>
                            <p>
                                The checkout and payment pages simulate an e-commerce payment flow. Payment records are stored against orders
                                so the system can show transaction references, payment status and order status.
                            </p>
                        </article>

                        <article class="faq-card">
                            <span>Orders</span>
                            <h3>Where can order activity be managed?</h3>
                            <p>
                                Orders are visible from the admin side. Authorised admin users can view buyer, seller and product details,
                                then update order statuses where required.
                            </p>
                        </article>

                        <article class="faq-card">
                            <span>Accounts</span>
                            <h3>What is role-based access control?</h3>
                            <p>
                                TradeNest separates user access through roles such as Buyer, Seller, Support Staff, Product Moderator
                                and Super Admin. This prevents ordinary users from accessing admin-only tools.
                            </p>
                        </article>

                    </div>
                </section>

                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Trust and safety</p>
                            <h2>Reporting suspicious activity</h2>
                        </div>

                        <a href="browse.php">Browse listings</a>
                    </div>

                    <div class="support-info-grid">
                        <article class="support-info-card">
                            <span>01</span>
                            <h3>Report a product</h3>
                            <p>
                                Logged-in users can report a suspicious, misleading, duplicated or unsafe product from the product details page.
                            </p>
                        </article>

                        <article class="support-info-card">
                            <span>02</span>
                            <h3>Admin review</h3>
                            <p>
                                Submitted reports are saved in the reports table and can be reviewed from the admin reports dashboard.
                            </p>
                        </article>

                        <article class="support-info-card">
                            <span>03</span>
                            <h3>Moderation action</h3>
                            <p>
                                Admin users can investigate reports and use product moderation tools to flag, approve or remove listings.
                            </p>
                        </article>
                    </div>
                </section>

                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Support areas</p>
                            <h2>What support can help with</h2>
                        </div>
                    </div>

                    <div class="support-info-grid">
                        <article class="support-info-card">
                            <span>Buyer</span>
                            <h3>Order and checkout help</h3>
                            <p>
                                Buyers can ask for help with checkout, order status, payment confirmation or product concerns.
                            </p>
                        </article>

                        <article class="support-info-card">
                            <span>Seller</span>
                            <h3>Listing and approval help</h3>
                            <p>
                                Sellers can ask about product listings, pending approval, moderation decisions or dashboard issues.
                            </p>
                        </article>

                        <article class="support-info-card">
                            <span>Safety</span>
                            <h3>Marketplace concerns</h3>
                            <p>
                                Users can raise concerns about suspicious sellers, scam listings, duplicate products or unsafe behaviour.
                            </p>
                        </article>
                    </div>
                </section>

                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Still need help?</p>
                            <h2>Contact TradeNest support</h2>
                        </div>

                        <a href="contact.php">Contact support</a>
                    </div>

                    <div class="faq-highlight-card">
                        <span>Support request</span>
                        <h3>Submit a support query when the Help Centre does not answer your question.</h3>
                        <p>
                            The Contact Support page allows users to describe account, order, payment, product or safety-related issues.
                            In a full deployment, these requests would be handled by Support Staff through an internal support workflow.
                        </p>

                        <div class="faq-action-row">
                            <a href="contact.php" class="join-btn">Contact support</a>
                            <a href="browse.php" class="login-link">Continue browsing</a>
                        </div>
                    </div>
                </section>

            </div>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest</p>
        <p>Help Centre for buying, selling, reporting and support access.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>