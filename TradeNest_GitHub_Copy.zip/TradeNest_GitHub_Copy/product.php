<?php
session_start();
include "db_connect.php";

$isLoggedIn = isset($_SESSION["user_id"]);
$firstName = $isLoggedIn ? $_SESSION["first_name"] : "";
$roleName = $isLoggedIn ? $_SESSION["role_name"] : "";

$product_id = isset($_GET["id"]) ? intval($_GET["id"]) : 0;

if ($product_id <= 0) {
    header("Location: browse.php");
    exit();
}

$sql = "SELECT 
            products.product_id,
            products.product_name,
            products.product_description,
            products.price,
            products.product_condition,
            products.location,
            products.image_url,
            products.listing_status,
            products.created_at,
            categories.category_name,
            users.user_id AS seller_id,
            users.first_name,
            users.last_name,
            users.email,
            users.phone_number,
            users.account_status
        FROM products
        INNER JOIN categories ON products.category_id = categories.category_id
        INNER JOIN users ON products.seller_id = users.user_id
        WHERE products.product_id = ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $product_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) === 0) {
    header("Location: browse.php");
    exit();
}

$product = mysqli_fetch_assoc($result);

function getProductImage($categoryName) {
    $images = [
        "Fashion" => "https://images.unsplash.com/photo-1523398002811-999ca8dec234?auto=format&fit=crop&w=900&q=80",
        "Electronics" => "https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=1000&q=80",
        "Furniture" => "https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?auto=format&fit=crop&w=1000&q=80",
        "Books" => "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&w=1000&q=80",
        "Beauty" => "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=1000&q=80",
        "Handmade" => "assets/images/handmade-community.png"
    ];

    return $images[$categoryName] ?? "assets/images/hero-community.png";
}

if (!empty($product["image_url"])) {
    $productImage = $product["image_url"];
} else {
    $productImage = getProductImage($product["category_name"]);
}

$isOwnProduct = $isLoggedIn && intval($_SESSION["user_id"]) === intval($product["seller_id"]);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product["product_name"]); ?> | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .product-page {
            width: calc(100% - 48px);
            max-width: 1340px;
            margin: 34px auto 120px;
        }

        .product-detail-layout {
            display: grid;
            grid-template-columns: 1.05fr 0.95fr;
            gap: 28px;
            align-items: stretch;
        }

        .product-detail-image {
            min-height: 760px;
            border-radius: 46px;
            background-size: cover;
            background-position: center;
            box-shadow: var(--shadow);
            position: relative;
            overflow: hidden;
        }

        .product-detail-image::after {
            content: "";
            position: absolute;
            inset: 0;
            background:
                linear-gradient(to top, rgba(9, 8, 7, 0.40), transparent 45%),
                radial-gradient(circle at 80% 20%, rgba(198, 90, 44, 0.28), transparent 30%);
        }

        .product-image-badge {
            position: absolute;
            left: 34px;
            bottom: 34px;
            z-index: 2;
            padding: 16px 20px;
            border-radius: 999px;
            background: rgba(255, 248, 239, 0.16);
            border: 1px solid rgba(255, 248, 239, 0.30);
            color: var(--paper);
            backdrop-filter: blur(18px);
            font-weight: 900;
        }

        .product-detail-panel {
            padding: 48px;
            border-radius: 46px;
            background: rgba(255, 248, 239, 0.66);
            border: 1px solid rgba(38, 24, 20, 0.08);
            box-shadow: var(--soft-shadow);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            gap: 34px;
        }

        .product-detail-panel h1 {
            font-size: clamp(3.4rem, 5.5vw, 6.8rem);
            line-height: 0.9;
            letter-spacing: -5px;
            margin-bottom: 24px;
        }

        .product-price {
            font-size: 3.2rem;
            font-weight: 900;
            letter-spacing: -2px;
            margin-bottom: 18px;
        }

        .product-description {
            color: var(--muted);
            line-height: 1.85;
            font-size: 1rem;
            max-width: 620px;
        }

        .product-meta-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
            margin-top: 28px;
        }

        .product-meta-card {
            padding: 18px;
            border-radius: 24px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
        }

        .product-meta-card span {
            display: block;
            color: var(--clay);
            font-size: 0.72rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            margin-bottom: 8px;
        }

        .product-meta-card strong {
            color: var(--espresso);
            font-size: 0.98rem;
        }

        .seller-card {
            padding: 26px;
            border-radius: 30px;
            background: var(--soft-black);
            color: var(--paper);
            box-shadow: var(--shadow);
        }

        .seller-card span {
            color: var(--sand);
            font-size: 0.72rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 1.4px;
        }

        .seller-card h3 {
            margin-top: 12px;
            font-size: 1.8rem;
            letter-spacing: -1px;
        }

        .seller-card p {
            margin-top: 10px;
            color: rgba(255, 248, 239, 0.70);
            line-height: 1.6;
        }

        .product-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 14px;
        }

        .buy-now-btn,
        .back-browse-btn,
        .report-product-btn {
            min-height: 54px;
            padding: 16px 24px;
            border-radius: 999px;
            font-weight: 900;
            display: inline-flex;
            justify-content: center;
            align-items: center;
            transition: 0.3s ease;
            text-decoration: none;
        }

        .buy-now-btn {
            background: var(--espresso);
            color: var(--paper);
        }

        .back-browse-btn {
            background: rgba(38, 24, 20, 0.08);
            color: var(--espresso);
        }

        .report-product-btn {
            background: rgba(198, 90, 44, 0.14);
            color: #a6532e;
            border: 1px solid rgba(198, 90, 44, 0.22);
        }

        .buy-now-btn:hover,
        .back-browse-btn:hover,
        .report-product-btn:hover {
            transform: translateY(-4px);
            box-shadow: var(--soft-shadow);
        }

        .safety-note {
            padding: 18px;
            border-radius: 24px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
            color: rgba(38, 24, 20, 0.64);
            font-weight: 700;
            line-height: 1.7;
        }

        .safety-note strong {
            color: var(--espresso);
        }

        @media (max-width: 1050px) {
            .product-detail-layout {
                grid-template-columns: 1fr;
            }

            .product-detail-image {
                min-height: 520px;
            }
        }

        @media (max-width: 680px) {
            .product-page {
                width: calc(100% - 28px);
                margin-top: 20px;
            }

            .product-detail-image,
            .product-detail-panel {
                border-radius: 34px;
            }

            .product-detail-image {
                min-height: 420px;
            }

            .product-detail-panel {
                padding: 28px;
            }

            .product-detail-panel h1 {
                font-size: 3.6rem;
                letter-spacing: -3px;
            }

            .product-meta-grid {
                grid-template-columns: 1fr;
            }

            .product-actions {
                flex-direction: column;
            }

            .buy-now-btn,
            .back-browse-btn,
            .report-product-btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>

    <header class="site-header">
        <a href="index.php" class="brand">TradeNest</a>

        <nav class="desktop-nav">
            <a href="browse.php">Browse</a>
            <a href="sell.php">Sell</a>
            <a href="faq.php">Help</a>
            <a href="admin-login.php">Admin</a>
        </nav>

        <div class="header-actions">
            <?php if ($isLoggedIn) { ?>
                <a href="dashboard.php" class="login-link">
                    Hi, <?php echo htmlspecialchars($firstName); ?>
                </a>
                <a href="logout.php" class="join-btn">Logout</a>
            <?php } else { ?>
                <a href="login.php" class="login-link">Login</a>
                <a href="register.php" class="join-btn">Join now</a>
            <?php } ?>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="browse.php">Browse</a>
        <a href="sell.php">Sell</a>
        <a href="faq.php">Help</a>
        <a href="admin-login.php">Admin</a>

        <?php if ($isLoggedIn) { ?>
            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        <?php } else { ?>
            <a href="login.php">Login</a>
            <a href="register.php">Join now</a>
        <?php } ?>
    </nav>

    <main class="product-page">

        <section class="product-detail-layout">

            <div 
                class="product-detail-image" 
                style="background-image: url('<?php echo htmlspecialchars($productImage); ?>');"
            >
                <div class="product-image-badge">
                    <?php echo htmlspecialchars($product["category_name"]); ?>
                </div>
            </div>

            <div class="product-detail-panel">

                <div>
                    <p class="section-label">Product details</p>

                    <h1><?php echo htmlspecialchars($product["product_name"]); ?></h1>

                    <div class="product-price">
                        R<?php echo htmlspecialchars(number_format($product["price"], 2)); ?>
                    </div>

                    <p class="product-description">
                        <?php echo htmlspecialchars($product["product_description"]); ?>
                    </p>

                    <div class="product-meta-grid">
                        <div class="product-meta-card">
                            <span>Location</span>
                            <strong><?php echo htmlspecialchars($product["location"]); ?></strong>
                        </div>

                        <div class="product-meta-card">
                            <span>Condition</span>
                            <strong><?php echo htmlspecialchars($product["product_condition"]); ?></strong>
                        </div>

                        <div class="product-meta-card">
                            <span>Status</span>
                            <strong><?php echo htmlspecialchars($product["listing_status"]); ?></strong>
                        </div>

                        <div class="product-meta-card">
                            <span>Category</span>
                            <strong><?php echo htmlspecialchars($product["category_name"]); ?></strong>
                        </div>
                    </div>
                </div>

                <div class="seller-card">
                    <span>Seller information</span>
                    <h3><?php echo htmlspecialchars($product["first_name"] . " " . $product["last_name"]); ?></h3>
                    <p>
                        Account status: <?php echo htmlspecialchars($product["account_status"]); ?><br>
                        Contact: <?php echo htmlspecialchars($product["phone_number"]); ?><br>
                        Email: <?php echo htmlspecialchars($product["email"]); ?>
                    </p>
                </div>

                <div class="product-actions">

                    <?php if ($isOwnProduct) { ?>
                        <a href="dashboard.php" class="back-browse-btn">
                            This is your listing
                        </a>
                    <?php } else { ?>
                        <a 
                            href="checkout.php?id=<?php echo $product["product_id"]; ?>" 
                            class="buy-now-btn"
                        >
                            Buy now
                        </a>
                    <?php } ?>

                    <a href="browse.php" class="back-browse-btn">
                        Back to browse
                    </a>

                    <?php if ($isLoggedIn && !$isOwnProduct) { ?>
                        <a 
                            href="report-product.php?id=<?php echo $product["product_id"]; ?>" 
                            class="report-product-btn"
                        >
                            Report this product
                        </a>
                    <?php } elseif (!$isLoggedIn) { ?>
                        <a 
                            href="login.php" 
                            class="report-product-btn"
                        >
                            Login to report
                        </a>
                    <?php } ?>

                </div>

                <div class="safety-note">
                    <strong>Trust & safety:</strong>
                    If this listing looks suspicious, misleading, duplicated or unsafe, logged-in users can report it for admin review.
                </div>

            </div>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest</p>
        <p>Product details, seller information and reporting tools for safer local trading.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>

<?php
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>