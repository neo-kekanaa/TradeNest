<?php
session_start();
include "db_connect.php";

$adminRoles = ["Super Admin", "Product Moderator", "Support Staff"];
$actionRoles = ["Super Admin", "Product Moderator"];

if (!isset($_SESSION["user_id"])) {
    header("Location: admin-login.php");
    exit();
}

if (!in_array($_SESSION["role_name"], $adminRoles)) {
    header("Location: dashboard.php");
    exit();
}

$admin_name = $_SESSION["first_name"] . " " . $_SESSION["last_name"];
$admin_role = $_SESSION["role_name"];
$admin_initial = strtoupper(substr($_SESSION["first_name"], 0, 1));

$message = "";
$error_message = "";

function getProductImage($imageUrl, $categoryName) {
    if (!empty($imageUrl)) {
        return $imageUrl;
    }

    $images = [
        "Fashion" => "https://images.unsplash.com/photo-1523398002811-999ca8dec234?auto=format&fit=crop&w=900&q=80",
        "Electronics" => "https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=900&q=80",
        "Furniture" => "https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?auto=format&fit=crop&w=900&q=80",
        "Books" => "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&w=900&q=80",
        "Beauty" => "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=900&q=80",
        "Handmade" => "assets/images/handmade-community.png"
    ];

    return $images[$categoryName] ?? "assets/images/hero-community.png";
}

function getStatusClass($status) {
    if ($status === "Approved") {
        return "approved";
    }

    if ($status === "Sold") {
        return "approved";
    }

    if ($status === "Flagged" || $status === "Removed") {
        return "flagged";
    }

    return "";
}

if (isset($_GET["action"]) && isset($_GET["id"])) {

    if (!in_array($_SESSION["role_name"], $actionRoles)) {
        header("Location: admin-products.php?error=" . urlencode("Access denied. Your role can view products but cannot change product status."));
        exit();
    }

    $product_id = intval($_GET["id"]);
    $action = $_GET["action"];

    if ($action === "approve") {
        $newStatus = "Approved";
        $message = "Product approved successfully.";
    } elseif ($action === "flag") {
        $newStatus = "Flagged";
        $message = "Product flagged successfully.";
    } elseif ($action === "pending") {
        $newStatus = "Pending review";
        $message = "Product moved back to pending review.";
    } elseif ($action === "remove") {
        $newStatus = "Removed";
        $message = "Product removed from public marketplace view.";
    }

    if (isset($newStatus)) {
        $updateSql = "UPDATE products SET listing_status = ? WHERE product_id = ?";
        $updateStmt = mysqli_prepare($conn, $updateSql);
        mysqli_stmt_bind_param($updateStmt, "si", $newStatus, $product_id);
        mysqli_stmt_execute($updateStmt);
        mysqli_stmt_close($updateStmt);

        header("Location: admin-products.php?message=" . urlencode($message));
        exit();
    }
}

if (isset($_GET["message"])) {
    $message = $_GET["message"];
}

if (isset($_GET["error"])) {
    $error_message = $_GET["error"];
}

$sql = "SELECT 
            products.product_id,
            products.product_name,
            products.product_description,
            products.price,
            products.product_condition,
            products.location,
            products.image_url,
            products.listing_status,
            products.created_at,
            categories.category_name,
            users.first_name,
            users.last_name,
            users.email
        FROM products
        INNER JOIN categories ON products.category_id = categories.category_id
        INNER JOIN users ON products.seller_id = users.user_id
        ORDER BY products.created_at DESC";

$result = mysqli_query($conn, $sql);

$totalProductsResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM products");
$totalProducts = mysqli_fetch_assoc($totalProductsResult)["total"];

$pendingResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM products WHERE listing_status = 'Pending review'");
$pendingCount = mysqli_fetch_assoc($pendingResult)["total"];

$approvedResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM products WHERE listing_status = 'Approved'");
$approvedCount = mysqli_fetch_assoc($approvedResult)["total"];

$flaggedResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM products WHERE listing_status = 'Flagged'");
$flaggedCount = mysqli_fetch_assoc($flaggedResult)["total"];

$moderationSql = "SELECT 
                    products.product_id,
                    products.product_name,
                    products.product_description,
                    products.price,
                    products.location,
                    products.image_url,
                    products.listing_status,
                    categories.category_name,
                    users.first_name,
                    users.last_name
                  FROM products
                  INNER JOIN categories ON products.category_id = categories.category_id
                  INNER JOIN users ON products.seller_id = users.user_id
                  WHERE products.listing_status IN ('Pending review', 'Flagged')
                  ORDER BY products.created_at DESC
                  LIMIT 2";

$moderationResult = mysqli_query($conn, $moderationSql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products | TradeNest Admin</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .admin-message-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(66, 122, 77, 0.14);
            color: #2f6b3c;
            font-weight: 900;
            line-height: 1.5;
            margin-bottom: 22px;
        }

        .admin-error-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(198, 90, 44, 0.14);
            color: #a6532e;
            font-weight: 900;
            line-height: 1.5;
            margin-bottom: 22px;
        }

        .product-thumb,
        .moderation-image {
            background-size: cover;
            background-position: center;
        }

        .products-row {
    grid-template-columns: 2.4fr 1.4fr 1fr 1fr 1.2fr;
    gap: 22px;
    align-items: center;
}

.products-table {
    display: grid;
    gap: 0;
    overflow: hidden;
    border-radius: 34px;
    border: 1px solid rgba(38, 24, 20, 0.08);
}

.products-table-head {
    background: var(--soft-black);
    color: var(--paper);
    border-radius: 0;
}

.products-table-head span {
    color: var(--paper);
    font-weight: 900;
}

.product-cell {
    display: flex;
    align-items: center;
    gap: 18px;
}

.product-thumb {
    width: 86px;
    height: 86px;
    border-radius: 24px;
    background-size: cover;
    background-position: center;
    flex-shrink: 0;
}

.product-cell strong {
    display: block;
    font-size: 1.05rem;
    line-height: 1.2;
    color: var(--espresso);
    margin-bottom: 6px;
}

.product-cell small {
    display: block;
    color: var(--muted);
    font-weight: 700;
    line-height: 1.45;
    max-width: 340px;
}

.seller-cell strong {
    display: block;
    color: var(--espresso);
    margin-bottom: 4px;
}

.seller-cell small {
    display: block;
    color: var(--muted);
    font-weight: 700;
    line-height: 1.4;
    word-break: break-word;
}

.action-buttons {
    display: grid;
    grid-template-columns: 1fr;
    gap: 8px;
    max-width: 150px;
}

.action-buttons a {
    min-height: 38px;
    padding: 9px 14px;
    border-radius: 999px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    font-weight: 900;
    font-size: 0.82rem;
    text-align: center;
}

.admin-pill {
    width: fit-content;
    white-space: nowrap;
}

.products-row.product-record {
    background: rgba(255, 248, 239, 0.55);
    border-bottom: 1px solid rgba(38, 24, 20, 0.08);
}

.products-row.product-record:last-child {
    border-bottom: none;
}

.product-description-preview {
    margin-top: 4px;
    max-width: 340px;
}

@media (max-width: 1100px) {
    .products-row {
        grid-template-columns: 1fr;
        gap: 14px;
    }

    .products-row.products-table-head {
        display: none;
    }

    .action-buttons {
        grid-template-columns: repeat(2, 1fr);
        max-width: none;
    }
}

        .action-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .action-buttons a {
            text-decoration: none;
        }

        .removed-btn {
            background: rgba(120, 30, 20, 0.14);
            color: #7a1d14;
        }

        .admin-pill.flagged {
            background: rgba(198, 90, 44, 0.14);
            color: #a6532e;
        }

        .admin-pill.removed {
            background: rgba(120, 30, 20, 0.14);
            color: #7a1d14;
        }

        .admin-note-card {
            padding: 24px;
            border-radius: 28px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
            color: var(--muted);
            font-weight: 700;
            line-height: 1.7;
        }

        .admin-note-card strong {
            color: var(--espresso);
        }

        .product-admin-empty {
            padding: 24px;
            border-radius: 28px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
            color: var(--muted);
            font-weight: 800;
            line-height: 1.7;
        }

        @media (max-width: 1100px) {
            .products-row {
                grid-template-columns: 1fr;
            }

            .products-row.products-table-head {
                display: none;
            }
        }
    </style>
</head>
<body>

    <header class="site-header admin-site-header">
        <a href="admin-dashboard.php" class="brand">TradeNest Admin</a>

        <nav class="desktop-nav">
            <a href="admin-dashboard.php">Dashboard</a>
            <a href="admin-users.php">Users</a>
            <a href="roles.php">Roles</a>
            <a href="admin-products.php">Products</a>
            <a href="admin-orders.php">Orders</a>
            <a href="admin-reports.php">Reports</a>
        </nav>

        <div class="header-actions">
            <a href="index.php" class="login-link">View site</a>
            <a href="logout.php" class="join-btn">Logout</a>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="admin-dashboard.php">Dashboard</a>
        <a href="admin-users.php">Users</a>
        <a href="roles.php">Roles</a>
        <a href="admin-products.php">Products</a>
        <a href="admin-orders.php">Orders</a>
        <a href="admin-reports.php">Reports</a>
        <a href="index.php">View site</a>
        <a href="logout.php">Logout</a>
    </nav>

    <main>

        <!-- PRODUCTS HERO -->
        <section class="admin-page-hero products-hero">
            <div>
                <p class="section-label">Manage products</p>
                <h1>Keep listings clean, useful and safe.</h1>
                <p>
                    Admin users can review product listings, approve new items, flag suspicious products,
                    and remove listings that do not meet marketplace rules.
                </p>
            </div>

            <div class="admin-hero-card">
                <span>Product control</span>
                <h3>Approve, flag or remove listings.</h3>
                <p>
                    Logged in as <?php echo htmlspecialchars($admin_name); ?> · Role: <?php echo htmlspecialchars($admin_role); ?>
                </p>
            </div>
        </section>

        <!-- PRODUCTS LAYOUT -->
        <section class="products-admin-layout">

            <aside class="admin-sidebar-panel">
                <div class="admin-profile-card">
                    <div class="admin-avatar"><?php echo htmlspecialchars($admin_initial); ?></div>
                    <h3><?php echo htmlspecialchars($admin_name); ?></h3>
                    <p><?php echo htmlspecialchars($admin_role); ?></p>
                    <span>RBAC Active</span>
                </div>

                <nav class="admin-side-menu">
                    <a href="admin-dashboard.php">Overview</a>
                    <a href="admin-users.php">Manage users</a>
                    <a href="roles.php">Manage roles</a>
                    <a href="admin-products.php" class="active">Manage products</a>
                    <a href="admin-orders.php">Orders</a>
                    <a href="admin-reports.php">Reports</a>
                </nav>
            </aside>

            <div class="products-admin-main">

                <!-- PRODUCT METRICS -->
                <div class="product-admin-metrics">
                    <article class="admin-stat">
                        <p>Total products</p>
                        <h3><?php echo $totalProducts; ?></h3>
                        <span>All active and pending listings</span>
                    </article>

                    <article class="admin-stat">
                        <p>Pending review</p>
                        <h3><?php echo $pendingCount; ?></h3>
                        <span>Listings awaiting approval</span>
                    </article>

                    <article class="admin-stat">
                        <p>Approved</p>
                        <h3><?php echo $approvedCount; ?></h3>
                        <span>Visible on public Browse page</span>
                    </article>

                    <article class="admin-stat">
                        <p>Flagged items</p>
                        <h3><?php echo $flaggedCount; ?></h3>
                        <span>Reported or needing attention</span>
                    </article>
                </div>

                <?php if (!empty($message)) { ?>
                    <div class="admin-message-box">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php } ?>

                <?php if (!empty($error_message)) { ?>
                    <div class="admin-error-box">
                        <?php echo htmlspecialchars($error_message); ?>
                    </div>
                <?php } ?>

                <!-- MODERATION NOTE -->
                <section class="admin-section product-edit-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Moderation workflow</p>
                            <h2>Review before public listing</h2>
                        </div>

                        <a href="admin-reports.php">View reports</a>
                    </div>

                    <div class="admin-note-card">
                        <strong>How this works:</strong>
                        Sellers submit products as <strong>Pending review</strong>. Product Moderators or Super Admins can approve suitable products, flag suspicious listings, move items back to pending review, or remove products from public visibility.
                    </div>
                </section>

                <!-- PRODUCT TABLE -->
                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Product records</p>
                            <h2>Marketplace listings</h2>
                        </div>

                        <div class="admin-search-mini">
                            <input type="text" id="productSearch" placeholder="Search products...">
                            <button type="button" onclick="filterProducts()">Search</button>
                        </div>
                    </div>

                    <div class="products-table" id="productsTable">

                        <div class="products-row products-table-head">
                            <span>Product</span>
                            <span>Seller</span>
                            <span>Category</span>
                            <span>Status</span>
                            <span>Actions</span>
                        </div>

                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                                <?php
                                    $productImage = getProductImage($row["image_url"], $row["category_name"]);
                                    $statusClass = getStatusClass($row["listing_status"]);
                                ?>

                                <div class="products-row product-record">
                                    <div class="product-cell">
                                        <div 
                                            class="product-thumb" 
                                            style="background-image: url('<?php echo htmlspecialchars($productImage); ?>');"
                                        ></div>

                                        <div>
                                            <strong><?php echo htmlspecialchars($row["product_name"]); ?></strong>
                                            <small>
                                                R<?php echo htmlspecialchars(number_format($row["price"], 2)); ?> · 
                                                <?php echo htmlspecialchars($row["location"]); ?>
                                            </small>
                                            <small class="product-description-preview">
											<?php echo htmlspecialchars(substr($row["product_description"], 0, 65)); ?>...
										</small>
                                        </div>
                                    </div>

                                    <div class="seller-cell">
    <strong><?php echo htmlspecialchars($row["first_name"] . " " . $row["last_name"]); ?></strong>
    <small><?php echo htmlspecialchars($row["email"]); ?></small>
</div>

                                    <span><?php echo htmlspecialchars($row["category_name"]); ?></span>

                                    <span class="admin-pill <?php echo htmlspecialchars($statusClass); ?>">
                                        <?php echo htmlspecialchars($row["listing_status"]); ?>
                                    </span>

<div class="action-buttons">
    <?php if ($row["listing_status"] !== "Approved") { ?>
        <a 
            class="approve-btn" 
            href="admin-products.php?action=approve&id=<?php echo $row["product_id"]; ?>"
        >
            Approve
        </a>
    <?php } ?>

    <?php if ($row["listing_status"] !== "Pending review") { ?>
        <a 
            class="edit-btn" 
            href="admin-products.php?action=pending&id=<?php echo $row["product_id"]; ?>"
        >
            Pending
        </a>
    <?php } ?>

    <?php if ($row["listing_status"] !== "Flagged") { ?>
        <a 
            class="delete-btn" 
            href="admin-products.php?action=flag&id=<?php echo $row["product_id"]; ?>"
        >
            Flag
        </a>
    <?php } ?>

    <a 
        class="removed-btn delete-btn" 
        href="admin-products.php?action=remove&id=<?php echo $row["product_id"]; ?>"
        onclick="return confirm('Remove this product from public marketplace visibility?');"
    >
        Remove
    </a>
</div>
                                </div>
                            <?php } ?>
                        <?php } else { ?>
                            <div class="product-admin-empty">
                                No products found. Seller listings will appear here once users publish products.
                            </div>
                        <?php } ?>

                    </div>
                </section>

                <!-- MODERATION QUEUE -->
                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Moderation queue</p>
                            <h2>Listings needing attention</h2>
                        </div>
                    </div>

                    <div class="moderation-grid">

                        <?php if (mysqli_num_rows($moderationResult) > 0) { ?>
                            <?php while ($item = mysqli_fetch_assoc($moderationResult)) { ?>
                                <?php
                                    $moderationImage = getProductImage($item["image_url"], $item["category_name"]);
                                ?>

                                <article class="moderation-card">
                                    <div 
                                        class="moderation-image" 
                                        style="background-image: url('<?php echo htmlspecialchars($moderationImage); ?>');"
                                    ></div>

                                    <div class="moderation-copy">
                                        <p><?php echo htmlspecialchars($item["listing_status"]); ?></p>

                                        <h3><?php echo htmlspecialchars($item["product_name"]); ?></h3>

                                        <span>
                                            <?php echo htmlspecialchars($item["category_name"]); ?> ·
                                            <?php echo htmlspecialchars($item["location"]); ?> ·
                                            Seller: <?php echo htmlspecialchars($item["first_name"] . " " . $item["last_name"]); ?>
                                        </span>

                                        <div class="moderation-actions">
                                            <a 
                                                class="approve-btn" 
                                                href="admin-products.php?action=approve&id=<?php echo $item["product_id"]; ?>"
                                            >
                                                Approve
                                            </a>

                                            <a 
                                                class="edit-btn" 
                                                href="admin-products.php?action=pending&id=<?php echo $item["product_id"]; ?>"
                                            >
                                                Request review
                                            </a>

                                            <a 
                                                class="delete-btn" 
                                                href="admin-products.php?action=flag&id=<?php echo $item["product_id"]; ?>"
                                            >
                                                Flag
                                            </a>
                                        </div>
                                    </div>
                                </article>
                            <?php } ?>
                        <?php } else { ?>
                            <div class="product-admin-empty">
                                No pending or flagged listings right now. The moderation queue is clear.
                            </div>
                        <?php } ?>

                    </div>
                </section>

            </div>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest Admin</p>
        <p>Manage products with approval, flagging, reporting and marketplace moderation.</p>
    </footer>

    <script src="assets/js/app.js"></script>

    <script>
        function filterProducts() {
            const input = document.getElementById("productSearch").value.toLowerCase();
            const rows = document.querySelectorAll(".product-record");

            rows.forEach(function(row) {
                const text = row.textContent.toLowerCase();

                if (text.includes(input)) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        }

        document.getElementById("productSearch").addEventListener("input", filterProducts);
    </script>
</body>
</html>

<?php
mysqli_close($conn);
?>