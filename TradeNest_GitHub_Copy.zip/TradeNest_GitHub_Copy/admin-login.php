<?php
session_start();
include "db_connect.php";

$error_message = "";

$adminRoles = ["Super Admin", "Product Moderator", "Support Staff"];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["adminEmail"]);
    $password = trim($_POST["adminPassword"]);
    $selected_role = trim($_POST["adminRole"]);
    $confirmed = isset($_POST["confirmAccess"]);

    if (empty($email) || empty($password) || empty($selected_role)) {
        $error_message = "Please complete all admin login fields.";
    } elseif (!$confirmed) {
        $error_message = "Please confirm that you understand this area is restricted.";
    } else {
        $sql = "SELECT 
                    users.user_id,
                    users.first_name,
                    users.last_name,
                    users.email,
                    users.password,
                    users.account_status,
                    roles.role_name
                FROM users
                INNER JOIN roles ON users.role_id = roles.role_id
                WHERE users.email = ?";

        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) === 1) {
            $admin = mysqli_fetch_assoc($result);

            if (!in_array($admin["role_name"], $adminRoles)) {
                $error_message = "This account does not have admin access.";
            } elseif ($admin["role_name"] !== $selected_role) {
                $error_message = "The selected role does not match this admin account.";
            } elseif ($admin["account_status"] !== "Active") {
                $error_message = "This admin account is not active.";
            } elseif (password_verify($password, $admin["password"]) || $password === $admin["password"]) {
                $_SESSION["user_id"] = $admin["user_id"];
                $_SESSION["first_name"] = $admin["first_name"];
                $_SESSION["last_name"] = $admin["last_name"];
                $_SESSION["email"] = $admin["email"];
                $_SESSION["role_name"] = $admin["role_name"];

                header("Location: admin-dashboard.php");
                exit();
            } else {
                $error_message = "Incorrect admin password.";
            }
        } else {
            $error_message = "No admin account found with that email address.";
        }

        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .admin-error-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(198, 90, 44, 0.14);
            color: #a6532e;
            font-weight: 900;
            line-height: 1.5;
            margin-bottom: 18px;
        }

        .auth-submit {
            border: none;
            cursor: pointer;
            font: inherit;
        }

        .admin-submit-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .admin-login-panel .auth-form select,
        .admin-login-panel .auth-form input {
            width: 100%;
        }
    </style>
</head>
<body>

    <header class="site-header">
        <a href="index.php" class="brand">TradeNest</a>

        <nav class="desktop-nav">
            <a href="browse.php">Browse</a>
            <a href="sell.php">Sell</a>
            <a href="dashboard.php">Dashboard</a>
            <a href="admin-login.php">Admin</a>
        </nav>

        <div class="header-actions">
            <a href="login.php" class="login-link">User login</a>
            <a href="register.php" class="join-btn">Join now</a>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="browse.php">Browse</a>
        <a href="sell.php">Sell</a>
        <a href="dashboard.php">Dashboard</a>
        <a href="admin-login.php">Admin</a>
        <a href="login.php">User login</a>
    </nav>

    <main>

        <section class="admin-login-page">

            <div class="admin-login-visual">
                <div>
                    <p class="section-label">Admin access</p>
                    <h1>Manage the marketplace with control and care.</h1>
                    <p>
                        The admin website gives authorised users access to platform management tools, including users,
                        roles, product listings, orders and moderation.
                    </p>
                </div>

                <div class="admin-access-card">
                    <span>RBAC enabled</span>
                    <h3>Different roles. Different permissions.</h3>
                    <p>Admin, support staff, product moderator and super admin accounts are controlled through assigned access levels.</p>
                </div>
            </div>

            <div class="admin-login-panel">
                <div class="auth-heading">
                    <p class="section-label">Admin login</p>
                    <h2>Sign in securely</h2>
                    <p>
                        This page is for authorised TradeNest staff only.
                    </p>
                </div>

                <?php if (!empty($error_message)) { ?>
                    <div class="admin-error-box">
                        <?php echo htmlspecialchars($error_message); ?>
                    </div>
                <?php } ?>

                <form class="auth-form" method="POST" action="admin-login.php">

                    <div class="form-group full-width">
                        <label for="adminEmail">Admin email</label>
                        <input 
                            type="email" 
                            id="adminEmail" 
                            name="adminEmail"
                            placeholder="e.g. admin@TradeNest.co.za"
                            required
                        >
                    </div>

                    <div class="form-group full-width">
                        <label for="adminPassword">Password</label>
                        <input 
                            type="password" 
                            id="adminPassword" 
                            name="adminPassword"
                            placeholder="Enter admin password"
                            required
                        >
                    </div>

                    <div class="form-group full-width">
                        <label for="adminRole">Access role</label>
                        <select id="adminRole" name="adminRole" required>
                            <option value="">Select admin role</option>
                            <option value="Super Admin">Super Admin</option>
                            <option value="Product Moderator">Product Moderator</option>
                            <option value="Support Staff">Support Staff</option>
                        </select>
                    </div>

                    <label class="terms-row">
                        <input type="checkbox" name="confirmAccess" value="1">
                        <span>I understand that this area is restricted to authorised admin users only.</span>
                    </label>

                    <button type="submit" class="auth-submit admin-submit-link">
                        Login to admin dashboard
                    </button>

                   <p class="auth-switch">
    <a href="forgot-password.php">Forgot password?</a>
</p>

<p class="auth-switch">
    Looking for your normal account?
    <a href="login.php">User login</a>
</p>

                </form>
            </div>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest Admin</p>
        <p>Restricted access for authorised marketplace management.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>

<?php
mysqli_close($conn);
?>