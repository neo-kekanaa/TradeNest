<?php
session_start();

$isLoggedIn = isset($_SESSION["user_id"]);
$firstName = $isLoggedIn ? $_SESSION["first_name"] : "";
$userEmail = $isLoggedIn ? $_SESSION["email"] : "";

$message = "";
$error_message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $issue_type = trim($_POST["issue_type"]);
    $support_message = trim($_POST["support_message"]);

    if (empty($name) || empty($email) || empty($issue_type) || empty($support_message)) {
        $error_message = "Please complete all support request fields.";
    } else {
        $message = "Your support request has been submitted. A TradeNest support staff member would review this and respond through the email provided.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Support | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .support-page-layout {
            width: calc(100% - 48px);
            max-width: 1340px;
            margin: 0 auto 120px;
            display: grid;
            grid-template-columns: 0.34fr 0.66fr;
            gap: 28px;
            align-items: flex-start;
        }

        .support-main {
            display: grid;
            gap: 28px;
        }

        .support-message-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(66, 122, 77, 0.14);
            color: #2f6b3c;
            font-weight: 900;
            line-height: 1.5;
            margin-bottom: 18px;
        }

        .support-error-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(198, 90, 44, 0.14);
            color: #a6532e;
            font-weight: 900;
            line-height: 1.5;
            margin-bottom: 18px;
        }

        .support-info-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 18px;
        }

        .support-info-card {
            padding: 24px;
            border-radius: 28px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
        }

        .support-info-card span {
            display: block;
            color: var(--clay);
            font-size: 0.72rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            margin-bottom: 10px;
        }

        .support-info-card h3 {
            color: var(--espresso);
            font-size: 1.2rem;
            margin-bottom: 10px;
        }

        .support-info-card p {
            color: var(--muted);
            line-height: 1.7;
            font-weight: 700;
            font-size: 0.95rem;
        }

        .contact-submit-btn {
            border: none;
            cursor: pointer;
        }

        @media (max-width: 1050px) {
            .support-page-layout {
                grid-template-columns: 1fr;
            }

            .support-info-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 680px) {
            .support-page-layout {
                width: calc(100% - 28px);
            }
        }
    </style>
</head>
<body>

    <header class="site-header">
        <a href="index.php" class="brand">TradeNest</a>

        <nav class="desktop-nav">
            <a href="browse.php">Browse</a>
            <a href="sell.php">Sell</a>
            <a href="faq.php">Help</a>
            <a href="admin-login.php">Admin</a>
        </nav>

        <div class="header-actions">
            <?php if ($isLoggedIn) { ?>
                <a href="dashboard.php" class="login-link">
                    Hi, <?php echo htmlspecialchars($firstName); ?>
                </a>
                <a href="logout.php" class="join-btn">Logout</a>
            <?php } else { ?>
                <a href="login.php" class="login-link">Login</a>
                <a href="register.php" class="join-btn">Join now</a>
            <?php } ?>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="browse.php">Browse</a>
        <a href="sell.php">Sell</a>
        <a href="faq.php">Help</a>
        <a href="admin-login.php">Admin</a>

        <?php if ($isLoggedIn) { ?>
            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        <?php } else { ?>
            <a href="login.php">Login</a>
            <a href="register.php">Join now</a>
        <?php } ?>
    </nav>

    <main>

        <section class="admin-page-hero">
            <div>
                <p class="section-label">Contact support</p>
                <h1>Get help when something needs attention.</h1>
                <p>
                    TradeNest gives buyers and sellers a clear way to request assistance with accounts, orders,
                    payments, product concerns or suspicious marketplace activity.
                </p>
            </div>

            <div class="admin-hero-card">
                <span>Support pathway</span>
                <h3>Help is handled through support staff.</h3>
                <p>
                    Support Staff is part of the role-based access control model, helping users while keeping admin access controlled.
                </p>
            </div>
        </section>

        <section class="support-page-layout">

            <aside class="admin-sidebar-panel">
                <div class="admin-profile-card">
                    <div class="admin-avatar">?</div>
                    <h3>Need help?</h3>
                    <p>Support Centre</p>
                    <span>Assistance available</span>
                </div>

                <nav class="admin-side-menu">
                    <a href="faq.php">Help Centre</a>
                    <a href="contact.php" class="active">Contact support</a>
                    <a href="terms.php">Terms and conditions</a>
                    <a href="browse.php">Browse products</a>
                    <a href="login.php">User login</a>
                    <a href="admin-login.php">Admin login</a>
                </nav>
            </aside>

            <div class="support-main">

                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Support request</p>
                            <h2>Tell us what you need help with</h2>
                        </div>
                    </div>

                    <?php if (!empty($message)) { ?>
                        <div class="support-message-box">
                            <?php echo htmlspecialchars($message); ?>
                        </div>
                    <?php } ?>

                    <?php if (!empty($error_message)) { ?>
                        <div class="support-error-box">
                            <?php echo htmlspecialchars($error_message); ?>
                        </div>
                    <?php } ?>

                    <form class="admin-product-form" method="POST" action="contact.php">
                        <div class="form-grid">

                            <div class="form-group">
                                <label for="name">Full name</label>
                                <input 
                                    type="text" 
                                    id="name" 
                                    name="name" 
                                    placeholder="Enter Full Name"
                                    value="<?php echo $isLoggedIn ? htmlspecialchars($_SESSION["first_name"] . " " . $_SESSION["last_name"]) : ""; ?>"
                                    required
                                >
                            </div>

                            <div class="form-group">
                                <label for="email">Email address</label>
                                <input 
                                    type="email" 
                                    id="email" 
                                    name="email" 
                                    placeholder="Enter email adress"
                                    value="<?php echo htmlspecialchars($userEmail); ?>"
                                    required
                                >
                            </div>

                            <div class="form-group full-width">
                                <label for="issue_type">Issue type</label>
                                <select id="issue_type" name="issue_type" required>
                                    <option value="">Select issue type</option>
                                    <option value="Account support">Account support</option>
                                    <option value="Order or payment issue">Order or payment issue</option>
                                    <option value="Seller or product concern">Seller or product concern</option>
                                    <option value="Report suspicious activity">Report suspicious activity</option>
                                    <option value="Technical problem">Technical problem</option>
                                    <option value="Other support request">Other support request</option>
                                </select>
                            </div>

                            <div class="form-group full-width">
                                <label for="support_message">Message</label>
                                <textarea 
                                    id="support_message" 
                                    name="support_message" 
                                    placeholder="Briefly explain what happened or what you need assistance with..."
                                    required
                                ></textarea>
                            </div>

                        </div>

                        <div class="form-actions">
                            <a href="faq.php" class="secondary-form-btn">Back to help</a>
                            <button type="submit" class="primary-form-btn contact-submit-btn">Submit request</button>
                        </div>
                    </form>
                </section>

                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Support areas</p>
                            <h2>What users can ask about</h2>
                        </div>
                    </div>

                    <div class="support-info-grid">
                        <article class="support-info-card">
                            <span>01</span>
                            <h3>Buyer help</h3>
                            <p>
                                Buyers can ask about checkout, order status, payment records or product concerns.
                            </p>
                        </article>

                        <article class="support-info-card">
                            <span>02</span>
                            <h3>Seller help</h3>
                            <p>
                                Sellers can ask about product listings, pending approvals, moderation or dashboard issues.
                            </p>
                        </article>

                        <article class="support-info-card">
                            <span>03</span>
                            <h3>Safety concerns</h3>
                            <p>
                                Users can raise concerns about suspicious sellers, scam listings, duplicate products or unsafe behaviour.
                            </p>
                        </article>
                    </div>
                </section>

            </div>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest</p>
        <p>Support access for buyers, sellers and marketplace users.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>