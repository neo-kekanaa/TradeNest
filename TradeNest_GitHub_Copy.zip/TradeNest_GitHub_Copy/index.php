<?php
session_start();

$isLoggedIn = isset($_SESSION["user_id"]);
$firstName = $isLoggedIn ? $_SESSION["first_name"] : "";
$roleName = $isLoggedIn ? $_SESSION["role_name"] : "";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TradeNest | Buy Local. Sell Safely.</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <header class="site-header">
    <a href="index.php" class="brand">TradeNest</a>

    <nav class="desktop-nav">
        <a href="browse.php">Browse</a>
        <a href="sell.php">Sell</a>
        <a href="faq.php">Help</a>
        <a href="admin-login.php">Admin</a>
    </nav>

    <div class="header-actions">
        <?php if ($isLoggedIn) { ?>
            <a href="dashboard.php" class="login-link">Hi, <?php echo htmlspecialchars($firstName); ?></a>
            <a href="logout.php" class="join-btn">Logout</a>
        <?php } else { ?>
            <a href="login.php" class="login-link">Login</a>
            <a href="register.php" class="join-btn">Join now</a>
        <?php } ?>
    </div>

    <button class="menu-btn" id="menuBtn">Menu</button>
</header>

<nav class="mobile-nav" id="mobileNav">
    <a href="browse.php">Browse</a>
    <a href="sell.php">Sell</a>
    <a href="faq.php">Help</a>
    <a href="admin-login.php">Admin</a>

    <?php if ($isLoggedIn) { ?>
        <a href="dashboard.php">Dashboard</a>
        <a href="logout.php">Logout</a>
    <?php } else { ?>
        <a href="login.php">Login</a>
        <a href="register.php">Join now</a>
    <?php } ?>
</nav>

    <main>

        <!-- HERO -->
        <section class="hero">
            <div class="hero-background"></div>
            <div class="hero-shade"></div>

            <div class="hero-content">
                <p class="eyebrow"><span></span> Built for local C2C trade</p>

                <h1>Local trade, beautifully organised.</h1>

                <p class="hero-copy">
                    TradeNest gives everyday South Africans a cleaner and safer place to buy, sell and grow,
                    from students and side-hustlers to township traders and community sellers.
                </p>

                <div class="hero-buttons">
                    <a href="browse.php" class="primary-btn">Start shopping</a>
					<a href="sell.php" class="secondary-btn">Sell your first item</a>
                </div>
            </div>

            <div class="hero-search-card">
                <p>Search the market</p>
                <div class="search-box">
                    <span>Try “denim jacket”, “speaker”, “desk”...</span>
                    <button>Search</button>
                </div>
            </div>

            <div class="hero-stat-card">
                <span>Verified local selling</span>
                <h3>Buy local. Sell safely.</h3>
                <p>Profiles, listings, orders and admin controls in one place.</p>
            </div>
        </section>

        <!-- CATEGORY MARQUEE -->
        <section class="marquee-section">
            <div class="marquee-track">
                <span>Fashion</span>
                <span>Electronics</span>
                <span>Books</span>
                <span>Furniture</span>
                <span>Beauty</span>
                <span>Handmade</span>
                <span>Fresh goods</span>
                <span>Campus finds</span>

                <span>Fashion</span>
                <span>Electronics</span>
                <span>Books</span>
                <span>Furniture</span>
                <span>Beauty</span>
                <span>Handmade</span>
                <span>Fresh goods</span>
                <span>Campus finds</span>
            </div>
        </section>

        <!-- EDITORIAL INTRO -->
        <section class="editorial">
            <div class="editorial-text">
                <p class="section-label">The idea</p>
                <h2>From WhatsApp statuses to proper digital storefronts.</h2>
            </div>

            <div class="editorial-copy">
                <p>
                    A lot of local selling already happens through DMs, statuses, campus groups and word of mouth.
                    TradeNest keeps that same community feeling, but adds structure: product listings, seller profiles,
                    categories, order records and an admin side that can manage the platform properly.
                </p>
            </div>
        </section>

        <!-- FEATURE CARDS -->
        <section class="feature-grid">
            <article class="feature-card feature-fashion">
                <div>
                    <span>01</span>
                    <h3>Local fashion</h3>
                </div>
                <p>Pre-loved clothing, shoes, bags and everyday style finds.</p>
            </article>

            <article class="feature-card feature-handmade">
                <div>
                    <span>02</span>
                    <h3>Handmade goods</h3>
                </div>
                <p>Beaded pieces, craft items and locally made products.</p>
            </article>

            <article class="feature-card feature-tech">
                <div>
                    <span>03</span>
                    <h3>Tech finds</h3>
                </div>
                <p>Phones, speakers, accessories and useful gadgets.</p>
            </article>
        </section>

        <!-- PRODUCT LISTINGS -->
        <section class="listings">
            <div class="section-heading">
                <div>
                    <p class="section-label">Fresh listings</p>
                    <h2>Things people are selling now.</h2>
                </div>

                <a href="browse.php" class="view-all">View all</a>
            </div>

            <div class="listing-grid">
                <article class="listing-card">
                    <div class="listing-image listing-one"></div>
                    <div class="listing-info">
                        <p>Soweto</p>
                        <h3>Vintage denim jacket</h3>
                        <div>
                            <strong>R350</strong>
                            <span>Verified seller</span>
                        </div>
                    </div>
                </article>

                <article class="listing-card">
                    <div class="listing-image listing-two"></div>
                    <div class="listing-info">
                        <p>Midrand</p>
                        <h3>Bluetooth speaker</h3>
                        <div>
                            <strong>R400</strong>
                            <span>Available</span>
                        </div>
                    </div>
                </article>

                <article class="listing-card">
                    <div class="listing-image listing-three"></div>
                    <div class="listing-info">
                        <p>Pretoria</p>
                        <h3>Study desk</h3>
                        <div>
                            <strong>R650</strong>
                            <span>Good condition</span>
                        </div>
                    </div>
                </article>

                <article class="listing-card">
                    <div class="listing-image listing-four"></div>
                    <div class="listing-info">
                        <p>Tembisa</p>
                        <h3>Beaded tote bag</h3>
                        <div>
                            <strong>R220</strong>
                            <span>Handmade</span>
                        </div>
                    </div>
                </article>
            </div>
        </section>

        <!-- COMMUNITY STORY -->
        <section class="community-story">
            <div class="story-image"></div>

            <div class="story-text">
                <p class="section-label">For the people</p>
                <h2>Made for the way Mzansi already moves.</h2>

                <p>
                    The platform is not trying to replace the local way of selling. It is trying to organise it.
                    Sellers can list products properly, buyers can browse with more confidence, and admins can manage
                    users, products, categories and roles from a separate admin website.
                </p>

                <div class="story-points">
                    <div>
                        <strong>01</strong>
                        <span>Buyer and seller accounts</span>
                    </div>

                    <div>
                        <strong>02</strong>
                        <span>Product listings with location and price</span>
                    </div>

                    <div>
                        <strong>03</strong>
                        <span>Admin website with RBAC controls</span>
                    </div>
                </div>
            </div>
        </section>

        <!-- ADMIN PREVIEW -->
        <section class="admin-preview">
            <div class="admin-text">
                <p class="section-label">Admin website</p>
                <h2>Control without making things complicated.</h2>

                <p>
                    The admin side supports role-based access control, allowing different user types to access the
                    functions linked to their role. This helps the platform manage buyers, sellers, listings and orders
                    in a more organised way.
                </p>
            </div>

            <div class="admin-ui">
                <div class="admin-topbar">
                    <span>TradeNest Admin</span>
                    <small>RBAC enabled</small>
                </div>

                <div class="admin-content">
                    <div class="admin-sidebar">
                        <span>Dashboard</span>
                        <span>Users</span>
                        <span>Roles</span>
                        <span>Products</span>
                        <span>Orders</span>
                    </div>

                    <div class="admin-main">
                        <div class="admin-metric">
                            <p>Total users</p>
                            <h3>248</h3>
                        </div>

                        <div class="admin-metric">
                            <p>Active listings</p>
                            <h3>96</h3>
                        </div>

                        <div class="admin-table">
                            <div>
                                <span>Buyer</span>
                                <small>View listings, place orders</small>
                            </div>

                            <div>
                                <span>Seller</span>
                                <small>Create and manage products</small>
                            </div>

                            <div>
                                <span>Admin</span>
                                <small>Manage users, roles and products</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- FINAL CTA -->
        <section class="cta">
            <p>TradeNest</p>
            <h2>Buy local. Sell safely. Grow Mzansi.</h2>
           <a href="register.php" class="primary-btn">Create your account</a>
        </section>

    </main>

    <footer class="footer">
        <p>TradeNest</p>
       <p>Buy local. Sell safely. Grow Mzansi.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>