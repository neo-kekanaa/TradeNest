<?php
session_start();
include "db_connect.php";

$adminRoles = ["Super Admin", "Product Moderator", "Support Staff"];

if (!isset($_SESSION["user_id"])) {
    header("Location: admin-login.php");
    exit();
}

if (!in_array($_SESSION["role_name"], $adminRoles)) {
    header("Location: dashboard.php");
    exit();
}

$admin_id = $_SESSION["user_id"];
$admin_name = $_SESSION["first_name"] . " " . $_SESSION["last_name"];
$admin_role = $_SESSION["role_name"];
$admin_initial = strtoupper(substr($_SESSION["first_name"], 0, 1));

$totalUsersResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM users");
$totalUsers = mysqli_fetch_assoc($totalUsersResult)["total"];

$activeListingsResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM products WHERE listing_status = 'Approved'");
$activeListings = mysqli_fetch_assoc($activeListingsResult)["total"];

$pendingApprovalsResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM products WHERE listing_status = 'Pending review'");
$pendingApprovals = mysqli_fetch_assoc($pendingApprovalsResult)["total"];

$openReportsResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM reports WHERE report_status = 'Open'");
$openReports = mysqli_fetch_assoc($openReportsResult)["total"];

$totalOrdersResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM orders");
$totalOrders = mysqli_fetch_assoc($totalOrdersResult)["total"];

$totalPaymentsResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM payments");
$totalPayments = mysqli_fetch_assoc($totalPaymentsResult)["total"];

$recentUsersSql = "SELECT 
                    users.first_name,
                    users.last_name,
                    users.account_status,
                    roles.role_name
                   FROM users
                   INNER JOIN roles ON users.role_id = roles.role_id
                   ORDER BY users.created_at DESC
                   LIMIT 3";

$recentUsersResult = mysqli_query($conn, $recentUsersSql);

$pendingProductsSql = "SELECT 
                        products.product_id,
                        products.product_name,
                        products.location,
                        products.listing_status,
                        products.product_description,
                        products.image_url,
                        categories.category_name
                       FROM products
                       INNER JOIN categories ON products.category_id = categories.category_id
                       WHERE products.listing_status IN ('Pending review', 'Flagged')
                       ORDER BY products.created_at DESC
                       LIMIT 2";

$pendingProductsResult = mysqli_query($conn, $pendingProductsSql);

$recentOrdersSql = "SELECT 
                        orders.order_id,
                        orders.order_status,
                        orders.total_amount,
                        orders.order_date,
                        products.product_name,
                        buyer.first_name AS buyer_first_name,
                        buyer.last_name AS buyer_last_name
                    FROM orders
                    INNER JOIN products ON orders.product_id = products.product_id
                    INNER JOIN users AS buyer ON orders.buyer_id = buyer.user_id
                    ORDER BY orders.order_date DESC
                    LIMIT 3";

$recentOrdersResult = mysqli_query($conn, $recentOrdersSql);

$recentReportsSql = "SELECT 
                        reports.report_id,
                        reports.report_reason,
                        reports.report_status,
                        reports.report_date,
                        products.product_id,
                        products.product_name
                     FROM reports
                     INNER JOIN products ON reports.product_id = products.product_id
                     ORDER BY reports.report_date DESC
                     LIMIT 2";

$recentReportsResult = mysqli_query($conn, $recentReportsSql);

function getStatusClass($status) {
    $status = strtolower($status);

    if ($status === "active" || $status === "approved" || $status === "paid" || $status === "completed" || $status === "resolved") {
        return "approved";
    }

    if ($status === "flagged" || $status === "open") {
        return "flagged";
    }

    return "";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .admin-dashboard-actions {
            display: flex;
            gap: 14px;
            flex-wrap: wrap;
            margin-top: 24px;
        }

        .admin-dashboard-actions a {
            text-decoration: none;
        }

        .dashboard-mini-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 18px;
            margin-top: 18px;
        }

        .dashboard-mini-card {
            padding: 24px;
            border-radius: 28px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
        }

        .dashboard-mini-card span {
            display: block;
            color: var(--clay);
            font-size: 0.72rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            margin-bottom: 10px;
        }

        .dashboard-mini-card h3 {
            color: var(--espresso);
            font-size: 1.2rem;
            margin-bottom: 10px;
        }

        .dashboard-mini-card p {
            color: var(--muted);
            line-height: 1.7;
            font-weight: 700;
            font-size: 0.95rem;
        }

        .dashboard-report-card {
            padding: 20px;
            border-radius: 26px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
            margin-bottom: 14px;
        }

        .dashboard-report-card p {
            color: var(--muted);
            line-height: 1.7;
            font-weight: 700;
            margin-top: 6px;
        }

        .dashboard-report-card h3 {
            color: var(--espresso);
            margin-top: 8px;
            letter-spacing: -0.5px;
        }

        .dashboard-report-card span {
            display: inline-flex;
            margin-top: 12px;
            padding: 7px 12px;
            border-radius: 999px;
            background: rgba(198, 90, 44, 0.14);
            color: #a6532e;
            font-weight: 900;
            font-size: 0.78rem;
        }

        .dashboard-order-row {
            display: grid;
            grid-template-columns: 0.7fr 1.4fr 1fr 0.8fr;
            gap: 16px;
            align-items: center;
            padding: 18px 0;
            border-bottom: 1px solid rgba(38, 24, 20, 0.08);
        }

        .dashboard-order-row:last-child {
            border-bottom: none;
        }

        .dashboard-order-row span,
        .dashboard-order-row strong {
            font-weight: 800;
            color: var(--espresso);
        }

        .dashboard-order-row small {
            display: block;
            color: var(--muted);
            font-weight: 700;
            margin-top: 5px;
        }

        .admin-empty-state {
            padding: 24px;
            border-radius: 28px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
            color: var(--muted);
            font-weight: 800;
            line-height: 1.7;
        }

        @media (max-width: 1050px) {
            .dashboard-mini-grid {
                grid-template-columns: 1fr;
            }

            .dashboard-order-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

    <header class="site-header admin-site-header">
        <a href="admin-dashboard.php" class="brand">TradeNest Admin</a>

        <nav class="desktop-nav">
            <a href="admin-dashboard.php">Dashboard</a>
            <a href="admin-users.php">Users</a>
            <a href="roles.php">Roles</a>
            <a href="admin-products.php">Products</a>
            <a href="admin-orders.php">Orders</a>
            <a href="admin-reports.php">Reports</a>
        </nav>

        <div class="header-actions">
            <a href="index.php" class="login-link">View site</a>
            <a href="logout.php" class="join-btn">Logout</a>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="admin-dashboard.php">Dashboard</a>
        <a href="admin-users.php">Users</a>
        <a href="roles.php">Roles</a>
        <a href="admin-products.php">Products</a>
        <a href="admin-orders.php">Orders</a>
        <a href="admin-reports.php">Reports</a>
        <a href="index.php">View site</a>
        <a href="logout.php">Logout</a>
    </nav>

    <main>

        <!-- ADMIN HERO -->
        <section class="admin-dashboard-hero">
            <div>
                <p class="section-label">Admin dashboard</p>
                <h1>Control the market without losing the people.</h1>
                <p>
                    Monitor TradeNest users, product listings, orders, role permissions, reports and platform activity from one central admin space.
                </p>

                <div class="admin-dashboard-actions">
                    <a href="admin-products.php" class="join-btn">Review products</a>
                    <a href="admin-orders.php" class="login-link">Manage orders</a>
                    <a href="admin-reports.php" class="login-link">Open reports</a>
                </div>
            </div>

            <div class="admin-hero-card">
                <span>Access level</span>
                <h3><?php echo htmlspecialchars($admin_role); ?></h3>
                <p>
                    Logged in as <?php echo htmlspecialchars($admin_name); ?>. This account can access marketplace management tools based on its assigned role.
                </p>
            </div>
        </section>

        <!-- ADMIN LAYOUT -->
        <section class="admin-dashboard-layout">

            <aside class="admin-sidebar-panel">
                <div class="admin-profile-card">
                    <div class="admin-avatar"><?php echo htmlspecialchars($admin_initial); ?></div>
                    <h3><?php echo htmlspecialchars($admin_name); ?></h3>
                    <p><?php echo htmlspecialchars($admin_role); ?></p>
                    <span>RBAC Active</span>
                </div>

                <nav class="admin-side-menu">
                    <a href="admin-dashboard.php" class="active">Overview</a>
                    <a href="admin-users.php">Manage users</a>
                    <a href="roles.php">Manage roles</a>
                    <a href="admin-products.php">Manage products</a>
                    <a href="admin-orders.php">Orders</a>
                    <a href="admin-reports.php">Reports</a>
                </nav>
            </aside>

            <div class="admin-dashboard-main">

                <!-- METRICS -->
                <div class="admin-metrics-grid">
                    <article class="admin-stat">
                        <p>Total users</p>
                        <h3><?php echo $totalUsers; ?></h3>
                        <span>Buyers, sellers and admins</span>
                    </article>

                    <article class="admin-stat">
                        <p>Active listings</p>
                        <h3><?php echo $activeListings; ?></h3>
                        <span>Approved marketplace products</span>
                    </article>

                    <article class="admin-stat">
                        <p>Pending approvals</p>
                        <h3><?php echo $pendingApprovals; ?></h3>
                        <span>Listings needing review</span>
                    </article>

                    <article class="admin-stat">
                        <p>Open reports</p>
                        <h3><?php echo $openReports; ?></h3>
                        <span>User or product reports</span>
                    </article>
                </div>

                <!-- RBAC SUMMARY -->
                <div class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Role-based access control</p>
                            <h2>Who can access what?</h2>
                        </div>

                        <a href="roles.php">Manage roles</a>
                    </div>

                    <div class="rbac-grid">
                        <article class="rbac-card">
                            <span>01</span>
                            <h3>Super Admin</h3>
                            <p>Can manage users, roles, products, orders, reports and platform records.</p>
                        </article>

                        <article class="rbac-card">
                            <span>02</span>
                            <h3>Product Moderator</h3>
                            <p>Can review, approve, flag or remove product listings and investigate product reports.</p>
                        </article>

                        <article class="rbac-card">
                            <span>03</span>
                            <h3>Support Staff</h3>
                            <p>Can review users, orders and reports to support marketplace activity without managing system roles.</p>
                        </article>
                    </div>
                </div>

                <!-- MARKETPLACE SUMMARY -->
                <div class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Marketplace activity</p>
                            <h2>System overview</h2>
                        </div>

                        <a href="admin-orders.php">View orders</a>
                    </div>

                    <div class="dashboard-mini-grid">
                        <article class="dashboard-mini-card">
                            <span>Orders</span>
                            <h3><?php echo $totalOrders; ?> total orders</h3>
                            <p>
                                Orders connect buyers, sellers and product records so admin users can track marketplace transactions.
                            </p>
                        </article>

                        <article class="dashboard-mini-card">
                            <span>Payments</span>
                            <h3><?php echo $totalPayments; ?> payment records</h3>
                            <p>
                                Payment records support checkout confirmation, transaction references and order payment status.
                            </p>
                        </article>

                        <article class="dashboard-mini-card">
                            <span>Reports</span>
                            <h3><?php echo $openReports; ?> open reports</h3>
                            <p>
                                Reports help identify suspicious products, misleading listings, duplicate posts or unsafe activity.
                            </p>
                        </article>
                    </div>
                </div>

                <!-- RECENT USERS AND APPROVALS -->
                <div class="admin-two-column">

                    <div class="admin-section">
                        <div class="admin-section-heading compact">
                            <div>
                                <p class="section-label">Recent users</p>
                                <h2>New accounts</h2>
                            </div>
                        </div>

                        <div class="admin-table-list">
                            <div class="admin-list-row table-top">
                                <span>Name</span>
                                <span>Role</span>
                                <span>Status</span>
                            </div>

                            <?php if (mysqli_num_rows($recentUsersResult) > 0) { ?>
                                <?php while ($user = mysqli_fetch_assoc($recentUsersResult)) { ?>
                                    <div class="admin-list-row">
                                        <span><?php echo htmlspecialchars($user["first_name"] . " " . $user["last_name"]); ?></span>
                                        <span><?php echo htmlspecialchars($user["role_name"]); ?></span>
                                        <span class="admin-pill <?php echo getStatusClass($user["account_status"]); ?>">
                                            <?php echo htmlspecialchars($user["account_status"]); ?>
                                        </span>
                                    </div>
                                <?php } ?>
                            <?php } else { ?>
                                <div class="admin-list-row">
                                    <span>No users found</span>
                                    <span>-</span>
                                    <span class="admin-pill">Empty</span>
                                </div>
                            <?php } ?>
                        </div>

                        <div style="margin-top: 24px;">
                            <a href="admin-users.php" class="join-btn">Manage users</a>
                        </div>
                    </div>

                    <div class="admin-section">
                        <div class="admin-section-heading compact">
                            <div>
                                <p class="section-label">Product moderation</p>
                                <h2>Needs review</h2>
                            </div>
                        </div>

                        <div class="approval-list">

                            <?php if (mysqli_num_rows($pendingProductsResult) > 0) { ?>
                                <?php while ($product = mysqli_fetch_assoc($pendingProductsResult)) { ?>
                                    <article class="approval-card">
                                        <?php
    if (!empty($product["image_url"])) {
        $productImage = $product["image_url"];
    } else {
        $productImage = "assets/images/hero-community.png";
    }
?>

<div 
    class="approval-img" 
    style="background-image: url('<?php echo htmlspecialchars($productImage); ?>'); background-size: cover; background-position: center;">
</div>

                                        <div>
                                            <p>
                                                <?php echo htmlspecialchars($product["category_name"]); ?> · 
                                                <?php echo htmlspecialchars($product["location"]); ?>
                                            </p>

                                            <h3><?php echo htmlspecialchars($product["product_name"]); ?></h3>

                                            <span><?php echo htmlspecialchars($product["listing_status"]); ?></span>
                                        </div>
                                    </article>
                                <?php } ?>
                            <?php } else { ?>
                                <article class="approval-card">
                                    <div class="approval-img approval-two"></div>

                                    <div>
                                        <p>Moderation queue</p>
                                        <h3>No pending listings</h3>
                                        <span>All products reviewed</span>
                                    </div>
                                </article>
                            <?php } ?>

                        </div>

                        <div style="margin-top: 24px;">
                            <a href="admin-products.php" class="join-btn">Manage product approvals</a>
                        </div>
                    </div>

                </div>

                <!-- RECENT ORDERS -->
                <div class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Recent orders</p>
                            <h2>Latest marketplace transactions</h2>
                        </div>

                        <a href="admin-orders.php">Manage orders</a>
                    </div>

                    <?php if (mysqli_num_rows($recentOrdersResult) > 0) { ?>
                        <?php while ($order = mysqli_fetch_assoc($recentOrdersResult)) { ?>
                            <div class="dashboard-order-row">
                                <span>#<?php echo htmlspecialchars($order["order_id"]); ?></span>

                                <div>
                                    <strong><?php echo htmlspecialchars($order["product_name"]); ?></strong>
                                    <small>
                                        Buyer: <?php echo htmlspecialchars($order["buyer_first_name"] . " " . $order["buyer_last_name"]); ?>
                                    </small>
                                </div>

                                <div>
                                    <strong>R<?php echo htmlspecialchars(number_format($order["total_amount"], 2)); ?></strong>
                                    <small><?php echo htmlspecialchars($order["order_date"]); ?></small>
                                </div>

                                <span class="admin-pill <?php echo getStatusClass($order["order_status"]); ?>">
                                    <?php echo htmlspecialchars($order["order_status"]); ?>
                                </span>
                            </div>
                        <?php } ?>
                    <?php } else { ?>
                        <div class="admin-empty-state">
                            No orders have been placed yet. Once buyers complete checkout, order records will appear here.
                        </div>
                    <?php } ?>
                </div>

                <!-- RECENT REPORTS -->
                <div class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Safety reports</p>
                            <h2>Reported products</h2>
                        </div>

                        <a href="admin-reports.php">View all reports</a>
                    </div>

                    <?php if (mysqli_num_rows($recentReportsResult) > 0) { ?>
                        <?php while ($report = mysqli_fetch_assoc($recentReportsResult)) { ?>
                            <article class="dashboard-report-card">
                                <p>
                                    Report #<?php echo htmlspecialchars($report["report_id"]); ?> · 
                                    <?php echo htmlspecialchars($report["report_date"]); ?>
                                </p>

                                <h3><?php echo htmlspecialchars($report["product_name"]); ?></h3>

                                <p><?php echo htmlspecialchars($report["report_reason"]); ?></p>

                                <span><?php echo htmlspecialchars($report["report_status"]); ?></span>
                            </article>
                        <?php } ?>

                        <a href="admin-reports.php" class="join-btn">Review reports</a>
                    <?php } else { ?>
                        <article class="dashboard-report-card">
                            <p>Reports queue</p>
                            <h3>No reports submitted</h3>
                            <p>
                                Reported scam, duplicate or unsafe products will appear here once users submit them from the product page.
                            </p>
                            <span>Clear</span>
                        </article>
                    <?php } ?>
                </div>

            </div>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest Admin</p>
        <p>Admin dashboard prototype for RBAC, product moderation, orders and reports.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>

<?php
mysqli_close($conn);
?>