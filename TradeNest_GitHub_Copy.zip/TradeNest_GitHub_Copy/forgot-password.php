<?php
include "db_connect.php";

$message = "";
$error_message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"]);

    if (empty($email)) {
        $error_message = "Please enter your email address.";
    } else {
        $sql = "SELECT user_id, first_name, email FROM users WHERE email = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        /*
            For security, we show a general message whether the email exists or not.
            This prevents people from checking which emails are registered.
        */
        $message = "If an account exists for this email address, password reset instructions will be sent.";

        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .forgot-page {
            min-height: 78vh;
            padding: 120px 6vw 80px;
            display: grid;
            grid-template-columns: 1fr 0.85fr;
            gap: 44px;
            align-items: stretch;
            background:
                radial-gradient(circle at 10% 10%, rgba(212, 154, 101, 0.18), transparent 32%),
                radial-gradient(circle at 90% 20%, rgba(75, 54, 40, 0.12), transparent 30%),
                #f8efe4;
        }

        .forgot-visual,
        .forgot-panel {
            border-radius: 34px;
            border: 1px solid rgba(45, 35, 25, 0.12);
            box-shadow: 0 24px 70px rgba(45, 35, 25, 0.12);
        }

        .forgot-visual {
            padding: 48px;
            min-height: 520px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            background:
                linear-gradient(180deg, rgba(20, 16, 14, 0.22), rgba(20, 16, 14, 0.75)),
                url("https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=80");
            background-size: cover;
            background-position: center;
            color: #fffaf4;
            overflow: hidden;
        }

        .forgot-visual h1 {
            font-family: "Instrument Serif", serif;
            font-size: clamp(3rem, 6vw, 5.8rem);
            line-height: 0.9;
            letter-spacing: -0.05em;
            margin: 18px 0;
            max-width: 720px;
        }

        .forgot-visual p {
            max-width: 620px;
            font-weight: 600;
            line-height: 1.7;
            color: rgba(255, 250, 244, 0.84);
        }

        .forgot-card {
            max-width: 440px;
            padding: 24px;
            border-radius: 26px;
            background: rgba(255, 250, 244, 0.14);
            backdrop-filter: blur(18px);
            border: 1px solid rgba(255, 250, 244, 0.2);
        }

        .forgot-card span {
            display: inline-flex;
            margin-bottom: 10px;
            font-size: 0.72rem;
            text-transform: uppercase;
            letter-spacing: 0.12em;
            font-weight: 900;
            color: #fffaf4;
        }

        .forgot-card h3 {
            font-size: 1.4rem;
            margin-bottom: 8px;
        }

        .forgot-panel {
            padding: 44px;
            background: #fffaf4;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .forgot-panel h2 {
            font-family: "Instrument Serif", serif;
            font-size: clamp(2.4rem, 4vw, 4rem);
            line-height: 0.95;
            letter-spacing: -0.04em;
            margin: 10px 0;
            color: #2b241f;
        }

        .forgot-panel p {
            color: rgba(40, 30, 20, 0.68);
            line-height: 1.7;
            font-weight: 700;
        }

        .forgot-form {
            margin-top: 28px;
            display: grid;
            gap: 18px;
        }

        .forgot-form label {
            font-weight: 900;
            color: #2b241f;
        }

        .forgot-form input {
            width: 100%;
            padding: 16px 18px;
            border-radius: 18px;
            border: 1px solid rgba(40, 30, 20, 0.16);
            background: #fff;
            font: inherit;
            font-weight: 700;
            color: #2b241f;
            outline: none;
        }

        .forgot-form button {
            border: none;
            border-radius: 999px;
            padding: 16px 22px;
            background: #2b241f;
            color: #fffaf4;
            font-weight: 900;
            cursor: pointer;
            font: inherit;
        }

        .forgot-actions {
            margin-top: 22px;
            display: flex;
            gap: 14px;
            flex-wrap: wrap;
        }

        .forgot-actions a {
            font-weight: 900;
            color: #2b241f;
            text-decoration: none;
        }

        .forgot-message-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(66, 122, 77, 0.14);
            color: #2f6b3c;
            font-weight: 900;
            line-height: 1.5;
            margin-top: 20px;
        }

        .forgot-error-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(198, 90, 44, 0.14);
            color: #a6532e;
            font-weight: 900;
            line-height: 1.5;
            margin-top: 20px;
        }

        @media (max-width: 900px) {
            .forgot-page {
                grid-template-columns: 1fr;
                padding-top: 100px;
            }

            .forgot-visual {
                min-height: 420px;
            }
        }
    </style>
</head>
<body>

    <header class="site-header">
        <a href="index.php" class="brand">TradeNest</a>

        <nav class="desktop-nav">
            <a href="browse.php">Browse</a>
            <a href="sell.php">Sell</a>
            <a href="faq.php">Help</a>
            <a href="admin-login.php">Admin</a>
        </nav>

        <div class="header-actions">
            <a href="login.php" class="login-link">Login</a>
            <a href="register.php" class="join-btn">Join now</a>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="browse.php">Browse</a>
        <a href="sell.php">Sell</a>
        <a href="faq.php">Help</a>
        <a href="admin-login.php">Admin</a>
        <a href="login.php">Login</a>
        <a href="register.php">Join now</a>
    </nav>

    <main>
        <section class="forgot-page">

            <div class="forgot-visual">
                <div>
                    <p class="section-label">Account recovery</p>
                    <h1>Get back into your account safely.</h1>
                    <p>
                        TradeNest helps buyers, sellers and admin users request access recovery without exposing account details publicly.
                    </p>
                </div>

                <div class="forgot-card">
                    <span>Security note</span>
                    <h3>Private by design.</h3>
                    <p>
                        The system does not reveal whether an email address is registered. This protects user account privacy.
                    </p>
                </div>
            </div>

            <div class="forgot-panel">
                <p class="section-label">Forgot password</p>
                <h2>Reset your password</h2>
                <p>
                    Enter your account email address below. If the email is linked to a TradeNest account, reset instructions will be sent.
                </p>

                <?php if (!empty($message)) { ?>
                    <div class="forgot-message-box">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php } ?>

                <?php if (!empty($error_message)) { ?>
                    <div class="forgot-error-box">
                        <?php echo htmlspecialchars($error_message); ?>
                    </div>
                <?php } ?>

                <form class="forgot-form" method="POST" action="forgot-password.php">
                    <div>
                        <label for="email">Email address</label>
                        <input 
                            type="email" 
                            id="email" 
                            name="email" 
                            placeholder="Enter your account email"
                            required
                        >
                    </div>

                    <button type="submit">Request reset instructions</button>
                </form>

                <div class="forgot-actions">
                    <a href="login.php">Back to user login</a>
                    <a href="admin-login.php">Admin login</a>
                </div>
            </div>

        </section>
    </main>

    <footer class="footer">
        <p>TradeNest</p>
        <p>Secure account recovery for marketplace users.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>

<?php
mysqli_close($conn);
?>