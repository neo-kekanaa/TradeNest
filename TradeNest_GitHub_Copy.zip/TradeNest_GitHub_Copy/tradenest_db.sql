-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jun 30, 2026 at 01:02 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mzansimarket_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `category_description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `category_description`) VALUES
(1, 'Fashion', 'Pre-loved clothing, shoes, bags and local style items.'),
(2, 'Electronics', 'Phones, speakers, laptops and everyday tech products.'),
(3, 'Handmade', 'Beaded goods, crafts and locally made items.'),
(4, 'Furniture', 'Desks, chairs, room items and household furniture.'),
(5, 'Books', 'Textbooks, novels and study material.'),
(6, 'Beauty', 'Self-care products, beauty items and grooming goods.');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `order_date` datetime DEFAULT current_timestamp(),
  `order_status` varchar(50) DEFAULT 'Pending',
  `total_amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `buyer_id`, `seller_id`, `product_id`, `order_date`, `order_status`, `total_amount`) VALUES
(1, 1, 3, 4, '2026-06-06 19:53:30', 'Awaiting pickup', 650.00),
(2, 1, 2, 5, '2026-06-06 19:53:30', 'Completed', 300.00),
(3, 1, 3, 6, '2026-06-06 19:53:30', 'Processing', 180.00),
(4, 1, 2, 1, '2026-06-24 15:13:01', 'Pending Payment', 350.00),
(5, 1, 2, 1, '2026-06-24 15:21:37', 'Pending Payment', 350.00),
(6, 1, 2, 1, '2026-06-24 15:22:01', 'Paid', 350.00),
(7, 9, 8, 8, '2026-06-24 22:44:21', 'Paid', 16000.00),
(8, 10, 2, 3, '2026-06-29 14:01:41', 'Paid', 220.00),
(9, 12, 11, 9, '2026-06-29 22:05:06', 'Paid', 3000.00),
(10, 12, 11, 9, '2026-06-29 22:15:17', 'Pending Payment', 3000.00),
(11, 12, 2, 1, '2026-06-29 22:29:40', 'Paid', 350.00);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_status` varchar(50) DEFAULT 'Pending',
  `payment_amount` decimal(10,2) NOT NULL,
  `payment_date` datetime DEFAULT current_timestamp(),
  `transaction_reference` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `order_id`, `payment_method`, `payment_status`, `payment_amount`, `payment_date`, `transaction_reference`) VALUES
(1, 1, 'Card', 'Successful', 650.00, '2026-06-06 19:53:30', 'MMTXN001'),
(2, 2, 'EFT', 'Successful', 300.00, '2026-06-06 19:53:30', 'MMTXN002'),
(3, 3, 'Card', 'Pending', 180.00, '2026-06-06 19:53:30', 'MMTXN003'),
(4, 6, 'Card', 'Successful', 350.00, '2026-06-24 15:23:40', 'MMTXN00006'),
(5, 6, 'EFT', 'Successful', 350.00, '2026-06-24 15:23:57', 'MMTXN00006'),
(6, 7, 'Card', 'Successful', 16000.00, '2026-06-24 22:44:37', 'MMTXN00007'),
(7, 8, 'Card', 'Successful', 220.00, '2026-06-29 14:02:04', 'MMTXN00008'),
(8, 9, 'Card', 'Successful', 3000.00, '2026-06-29 22:05:48', 'MMTXN00009'),
(9, 11, 'Wallet', 'Successful', 350.00, '2026-06-29 22:29:49', 'MMTXN00011');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `permission_id` int(11) NOT NULL,
  `permission_name` varchar(100) NOT NULL,
  `permission_description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`permission_id`, `permission_name`, `permission_description`) VALUES
(1, 'view_products', 'Allows a user to view product listings.'),
(2, 'create_product', 'Allows a seller to create a product listing.'),
(3, 'update_product', 'Allows a seller or admin to update product details.'),
(4, 'delete_product', 'Allows a seller or admin to remove a product listing.'),
(5, 'place_order', 'Allows a buyer to place an order.'),
(6, 'manage_users', 'Allows an admin user to create, view, update or delete user accounts.'),
(7, 'manage_roles', 'Allows an admin user to manage roles and permissions.'),
(8, 'approve_products', 'Allows a moderator or admin to approve product listings.'),
(9, 'view_reports', 'Allows an admin user to view user or product reports.');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `product_name` varchar(150) NOT NULL,
  `product_description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `product_condition` varchar(50) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `listing_status` varchar(50) DEFAULT 'Pending review',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `seller_id`, `category_id`, `product_name`, `product_description`, `price`, `product_condition`, `location`, `image_url`, `listing_status`, `created_at`) VALUES
(1, 2, 1, 'Vintage denim jacket', 'A pre-loved denim jacket in good condition. Suitable for casual everyday wear.', 350.00, 'Good condition', 'Soweto', 'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=700&q=80', 'Sold', '2026-06-06 19:53:30'),
(2, 3, 2, 'Bluetooth speaker', 'Portable Bluetooth speaker with good sound quality and minor signs of use.', 400.00, 'Used', 'Midrand', 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=900&q=80', 'Approved', '2026-06-06 19:53:30'),
(3, 2, 3, 'Beaded tote bag', 'Handmade beaded tote bag made by a local seller.', 220.00, 'New', 'Tembisa', 'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=900&q=80', 'Approved', '2026-06-06 19:53:30'),
(4, 3, 4, 'Minimal study desk', 'Simple study desk suitable for students or home office use.', 650.00, 'Good condition', 'Pretoria', 'https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?auto=format&fit=crop&w=900&q=80', 'Approved', '2026-06-06 19:53:30'),
(5, 2, 5, 'First-year IT textbooks', 'A bundle of used first-year IT textbooks and study notes.', 300.00, 'Used', 'Johannesburg', 'https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&w=900&q=80', 'Approved', '2026-06-06 19:53:30'),
(6, 3, 6, 'Self-care bundle', 'Small self-care bundle with basic beauty and grooming items.', 180.00, 'New', 'Alexandra', 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=900&q=80', 'Pending review', '2026-06-06 19:53:30'),
(7, 2, 1, 'Nike Sneakers', 'Pre-loved Nike sneakers in good condition, suitable for everyday wear.', 650.00, 'Good', 'Midrand', 'https://cdn-web.poizon.com/web-app-static/app/2024/other/1293738058_modelV2344Amodel_byte70990byte_bd37fdfd57324065b2d4359dc3ad0463_du_android_w1080_h1080.jpeg?x-oss-process=image/format,webp', 'Approved', '2026-06-24 15:33:45'),
(8, 8, 2, 'Used iPhone 16 Pro Max', 'Previously used iPhone 16 Pro Max in great condition 128 G.', 16000.00, 'Good', 'Waterfall, Midrand', 'https://amateurphotographer.com/wp-content/uploads/sites/7/2024/10/iPhone16Pro_Max__AmyDavies_06.jpg', 'Approved', '2026-06-24 22:33:25'),
(9, 11, 2, 'Dell Laptop', 'Dell laptop in fairly good condition, comes with laptop charger and box.', 3000.00, 'Good', 'Centurion', 'assets/uploads/product_11_1782746571.jpg', 'Approved', '2026-06-29 17:22:51');

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `report_id` int(11) NOT NULL,
  `reporter_id` int(11) NOT NULL,
  `reported_user_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `report_reason` text NOT NULL,
  `report_status` varchar(50) DEFAULT 'Pending',
  `report_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`report_id`, `reporter_id`, `reported_user_id`, `product_id`, `report_reason`, `report_status`, `report_date`) VALUES
(1, 1, 3, 4, 'The product condition may not match the listing description.', 'Pending', '2026-06-06 19:53:30'),
(2, 2, NULL, 2, 'Product image is unclear and needs review.', 'Pending', '2026-06-06 19:53:30'),
(3, 6, 2, 5, 'Possible scam or suspicious listing — looks suspicious', 'Open', '2026-06-29 15:41:48');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `review_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `reviewer_id` int(11) NOT NULL,
  `reviewed_user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `rating` int(11) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `review_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`review_id`, `order_id`, `reviewer_id`, `reviewed_user_id`, `product_id`, `rating`, `comment`, `review_date`) VALUES
(1, 2, 1, 2, 5, 5, 'The textbooks were in good condition and the seller responded quickly.', '2026-06-06 19:53:30');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(50) NOT NULL,
  `role_description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `role_name`, `role_description`) VALUES
(1, 'Buyer', 'A customer who can browse products, place orders, make payments and leave reviews.'),
(2, 'Seller', 'A user who can create product listings, manage their own products and respond to orders.'),
(3, 'Support Staff', 'An admin support user who can view users, orders and reports.'),
(4, 'Product Moderator', 'An admin user who can review, approve, reject or remove product listings.'),
(5, 'Super Admin', 'A full admin user who can manage users, roles, permissions, products and reports.');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

CREATE TABLE `role_permissions` (
  `role_permission_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` (`role_permission_id`, `role_id`, `permission_id`) VALUES
(1, 1, 1),
(2, 1, 5),
(3, 2, 1),
(4, 2, 2),
(5, 2, 3),
(6, 2, 4),
(7, 3, 1),
(8, 3, 9),
(9, 4, 1),
(10, 4, 3),
(11, 4, 4),
(12, 4, 8),
(13, 4, 9),
(14, 5, 1),
(15, 5, 2),
(16, 5, 3),
(17, 5, 4),
(18, 5, 5),
(19, 5, 6),
(20, 5, 7),
(21, 5, 8),
(22, 5, 9);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `account_status` varchar(50) DEFAULT 'Active',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `role_id`, `first_name`, `last_name`, `email`, `password`, `phone_number`, `location`, `account_status`, `created_at`) VALUES
(1, 1, 'Karabo', 'Sithole', 'karabo@email.com', 'hashed_password_123', '0712345678', 'Johannesburg', 'Active', '2026-06-06 19:53:30'),
(2, 2, 'Thando', 'Mokoena', 'thando@email.com', 'hashed_password_123', '0723456789', 'Soweto', 'Verified', '2026-06-06 19:53:30'),
(3, 2, 'Lebo', 'Radebe', 'lebo@email.com', 'hashed_password_123', '0734567890', 'Midrand', 'Active', '2026-06-06 19:53:30'),
(4, 3, 'Precious', 'Dlamini', 'precious@email.com', 'hashed_password_123', '0745678901', 'Pretoria', 'Active', '2026-06-06 19:53:30'),
(5, 4, 'Naledi', 'Maseko', 'naledi@email.com', 'hashed_password_123', '0756789012', 'Tembisa', 'Active', '2026-06-06 19:53:30'),
(6, 5, 'Admin', 'User', 'admin@mzansimarket.co.za', 'admin123', '0767890123', 'Johannesburg', 'Active', '2026-06-06 19:53:30'),
(7, 1, 'Aphiwe', 'Mthembu', 'aphiwe@example.com', 'password123', '0712345678', 'Durban', 'Active', '2026-06-24 16:18:04'),
(8, 2, 'Neo', 'Kekana', 'neo.kekana12@gmail.com', '$2y$10$nkvcocoJPOC.V7ZIUFofFuCPZZ/Gw61b0C8T1b.mKd6etFXPYm6yG', '0712345567', 'Waterfall, Midrand', 'Active', '2026-06-24 20:41:26'),
(9, 1, 'Keenan', 'Otou', 'keenan@otou.com', '$2y$10$I0xX1FWorMToQuD97QchQuc8VgABZM0z/VXAR4CnShq1y/re8RAHu', '0660122262', 'Sandton', 'Active', '2026-06-24 22:42:53'),
(10, 1, 'Demo', 'Buyer', 'buyer@mzansimarket.co.za', '$2y$10$Tv74csLihURRbNrXM3czu.ur7p11yUDNgCRjsfWlG5uKZObn9qxuq', '0836857979', 'Sandton', 'Active', '2026-06-29 13:49:49'),
(11, 2, 'Demo', 'Seller', 'seller@mzansimarket.co.za', '$2y$10$lvsdYj9PJXo092JG31knD.DfXJkv/i6VtD1.aM4sT7GCt.wjdR4Qu', '0660122262', 'Centurion', 'Active', '2026-06-29 13:50:59'),
(12, 1, 'Kamo', 'Kekana', 'kamokekana@gmail.com', '$2y$10$k0gwYYdo.pbQlO43gf.SY.QhfkO46UP1IJI1ZU3SP/HeohGOgGTrW', '0723456789', 'Midrand', 'Active', '2026-06-29 22:03:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `buyer_id` (`buyer_id`),
  ADD KEY `seller_id` (`seller_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`permission_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `seller_id` (`seller_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `reporter_id` (`reporter_id`),
  ADD KEY `reported_user_id` (`reported_user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `reviewer_id` (`reviewer_id`),
  ADD KEY `reviewed_user_id` (`reviewed_user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`role_permission_id`),
  ADD KEY `role_id` (`role_id`),
  ADD KEY `permission_id` (`permission_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `role_id` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `permission_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `role_permissions`
--
ALTER TABLE `role_permissions`
  MODIFY `role_permission_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`seller_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`);

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`reporter_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `reports_ibfk_2` FOREIGN KEY (`reported_user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `reports_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `reviews_ibfk_3` FOREIGN KEY (`reviewed_user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `reviews_ibfk_4` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`),
  ADD CONSTRAINT `role_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`permission_id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
