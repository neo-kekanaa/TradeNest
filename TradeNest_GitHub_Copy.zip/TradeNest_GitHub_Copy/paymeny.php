<?php
include "db_connect.php";

$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;

if ($order_id <= 0) {
    die("Invalid payment request.");
}

$sql = "SELECT 
            orders.order_id,
            orders.order_status,
            orders.total_amount,
            orders.order_date,
            products.product_name,
            products.product_description,
            products.location,
            categories.category_name,
            buyer.first_name AS buyer_first_name,
            buyer.last_name AS buyer_last_name,
            seller.first_name AS seller_first_name,
            seller.last_name AS seller_last_name
        FROM orders
        INNER JOIN products ON orders.product_id = products.product_id
        INNER JOIN categories ON products.category_id = categories.category_id
        INNER JOIN users AS buyer ON orders.buyer_id = buyer.user_id
        INNER JOIN users AS seller ON orders.seller_id = seller.user_id
        WHERE orders.order_id = ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $order_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) === 0) {
    die("Order not found.");
}

$order = mysqli_fetch_assoc($result);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $payment_method = $_POST['payment_method'];
    $payment_amount = floatval($order['total_amount']);
    $transaction_reference = "MMTXN" . str_pad($order_id, 5, "0", STR_PAD_LEFT);

    $paymentSql = "INSERT INTO payments 
                    (order_id, payment_method, payment_status, payment_amount, transaction_reference)
                   VALUES 
                    (?, ?, 'Successful', ?, ?)";

    $paymentStmt = mysqli_prepare($conn, $paymentSql);
    mysqli_stmt_bind_param($paymentStmt, "isds", $order_id, $payment_method, $payment_amount, $transaction_reference);

    if (mysqli_stmt_execute($paymentStmt)) {
        $updateOrderSql = "UPDATE orders SET order_status = 'Paid' WHERE order_id = ?";
        $updateStmt = mysqli_prepare($conn, $updateOrderSql);
        mysqli_stmt_bind_param($updateStmt, "i", $order_id);
        mysqli_stmt_execute($updateStmt);

        header("Location: payment-success.php?order_id=" . $order_id);
        exit();
    } else {
        $error_message = "Payment could not be processed. Please try again.";
    }

    mysqli_stmt_close($paymentStmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .payment-page {
            width: calc(100% - 48px);
            max-width: 1340px;
            margin: 34px auto 120px;
        }

        .payment-hero {
            min-height: 420px;
            padding: 70px;
            border-radius: 46px;
            color: var(--paper);
            background:
                linear-gradient(90deg, rgba(9, 8, 7, 0.92), rgba(9, 8, 7, 0.28)),
                url("assets/images/tech-community.png");
            background-size: cover;
            background-position: center;
            box-shadow: var(--shadow);
            margin-bottom: 34px;
        }

        .payment-hero h1 {
            font-size: clamp(3.8rem, 7vw, 7.5rem);
            line-height: 0.88;
            letter-spacing: -6px;
            max-width: 850px;
        }

        .payment-hero p:not(.section-label) {
            max-width: 620px;
            margin-top: 24px;
            color: rgba(255, 248, 239, 0.74);
            line-height: 1.85;
        }

        .payment-layout {
            display: grid;
            grid-template-columns: 1fr 0.85fr;
            gap: 28px;
            align-items: start;
        }

        .payment-card,
        .payment-summary {
            padding: 38px;
            border-radius: 42px;
            background: rgba(255, 248, 239, 0.66);
            border: 1px solid rgba(38, 24, 20, 0.08);
            box-shadow: var(--soft-shadow);
        }

        .payment-card h2,
        .payment-summary h2 {
            font-size: clamp(2.6rem, 4vw, 4.8rem);
            line-height: 0.92;
            letter-spacing: -4px;
            margin-bottom: 24px;
        }

        .payment-methods {
            display: grid;
            gap: 16px;
            margin-top: 24px;
        }

        .payment-option {
            padding: 22px;
            border-radius: 28px;
            background: rgba(255, 248, 239, 0.72);
            border: 1px solid rgba(38, 24, 20, 0.10);
            display: flex;
            align-items: flex-start;
            gap: 14px;
            cursor: pointer;
        }

        .payment-option input {
            margin-top: 5px;
            accent-color: var(--espresso);
        }

        .payment-option strong {
            display: block;
            font-size: 1.1rem;
            margin-bottom: 6px;
        }

        .payment-option span {
            color: var(--muted);
            line-height: 1.6;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            gap: 18px;
            padding: 18px 0;
            border-bottom: 1px solid rgba(38, 24, 20, 0.10);
            color: var(--muted);
        }

        .summary-row strong {
            color: var(--espresso);
        }

        .summary-total {
            font-size: 1.7rem;
            font-weight: 900;
            color: var(--espresso);
        }

        .payment-warning {
            margin-top: 24px;
            padding: 22px;
            border-radius: 28px;
            background: var(--soft-black);
            color: var(--paper);
        }

        .payment-warning h3 {
            font-size: 1.3rem;
            letter-spacing: -0.5px;
        }

        .payment-warning p {
            margin-top: 10px;
            color: rgba(255, 248, 239, 0.70);
            line-height: 1.7;
        }

        .payment-actions {
            margin-top: 28px;
            display: grid;
            gap: 14px;
        }

        .pay-btn,
        .cancel-payment-btn {
            border: none;
            min-height: 54px;
            border-radius: 999px;
            padding: 16px 24px;
            font-weight: 900;
            cursor: pointer;
            text-align: center;
            transition: 0.3s ease;
        }

        .pay-btn {
            background: var(--espresso);
            color: var(--paper);
        }

        .cancel-payment-btn {
            background: rgba(38, 24, 20, 0.08);
            color: var(--espresso);
        }

        .pay-btn:hover,
        .cancel-payment-btn:hover {
            transform: translateY(-4px);
            box-shadow: var(--soft-shadow);
        }

        .error-message {
            margin-bottom: 20px;
            padding: 16px 18px;
            border-radius: 18px;
            background: rgba(198, 90, 44, 0.14);
            color: var(--clay);
            font-weight: 900;
        }

        @media (max-width: 1050px) {
            .payment-layout {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 680px) {
            .payment-page {
                width: calc(100% - 28px);
                margin-top: 20px;
            }

            .payment-hero {
                padding: 34px;
                border-radius: 34px;
                min-height: 520px;
            }

            .payment-hero h1 {
                font-size: 3.6rem;
                letter-spacing: -3.5px;
            }

            .payment-card,
            .payment-summary {
                padding: 24px;
                border-radius: 32px;
            }
        }
    </style>
</head>
<body>

    <header class="site-header">
        <a href="index.php" class="brand">TradeNest</a>

        <nav class="desktop-nav">
            <a href="browse.php">Browse</a>
            <a href="sell.php">Sell</a>
            <a href="#">Community</a>
            <a href="logout.php">Admin</a>
        </nav>

        <div class="header-actions">
            <a href="login.php" class="login-link">Login</a>
            <a href="register.php" class="join-btn">Join now</a>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="browse.php">Browse</a>
        <a href="sell.php">Sell</a>
        <a href="#">Community</a>
        <a href="logout.php">Admin</a>
        <a href="login.php">Login</a>
        <a href="register.php">Join now</a>
    </nav>

    <main class="payment-page">

        <section class="payment-hero">
            <p class="section-label">Payment</p>
            <h1>Complete your payment.</h1>
            <p>
                Choose a payment method to complete the demo order. This payment step creates a payment record in the database.
            </p>
        </section>

        <section class="payment-layout">

            <form method="POST" action="payment.php?order_id=<?php echo $order_id; ?>" class="payment-card">
                <p class="section-label">Demo payment gateway</p>
                <h2>Select payment method</h2>

                <?php if (isset($error_message)) { ?>
                    <div class="error-message">
                        <?php echo htmlspecialchars($error_message); ?>
                    </div>
                <?php } ?>

                <div class="payment-methods">
                    <label class="payment-option">
                        <input type="radio" name="payment_method" value="Card" checked>
                        <div>
                            <strong>Card payment</strong>
                            <span>Simulates a debit or credit card payment for the order.</span>
                        </div>
                    </label>

                    <label class="payment-option">
                        <input type="radio" name="payment_method" value="EFT">
                        <div>
                            <strong>EFT</strong>
                            <span>Simulates an electronic funds transfer payment.</span>
                        </div>
                    </label>

                    <label class="payment-option">
                        <input type="radio" name="payment_method" value="Wallet">
                        <div>
                            <strong>Wallet</strong>
                            <span>Simulates payment through a digital wallet.</span>
                        </div>
                    </label>
                </div>

                <div class="payment-actions">
                    <button type="submit" class="pay-btn">
                        Pay R<?php echo htmlspecialchars(number_format($order['total_amount'], 2)); ?>
                    </button>

                    <a href="browse.php" class="cancel-payment-btn">
                        Cancel payment
                    </a>
                </div>
            </form>

            <aside class="payment-summary">
                <p class="section-label">Order summary</p>
                <h2>Order #<?php echo htmlspecialchars($order['order_id']); ?></h2>

                <div class="summary-row">
                    <span>Product</span>
                    <strong><?php echo htmlspecialchars($order['product_name']); ?></strong>
                </div>

                <div class="summary-row">
                    <span>Category</span>
                    <strong><?php echo htmlspecialchars($order['category_name']); ?></strong>
                </div>

                <div class="summary-row">
                    <span>Buyer</span>
                    <strong><?php echo htmlspecialchars($order['buyer_first_name'] . " " . $order['buyer_last_name']); ?></strong>
                </div>

                <div class="summary-row">
                    <span>Seller</span>
                    <strong><?php echo htmlspecialchars($order['seller_first_name'] . " " . $order['seller_last_name']); ?></strong>
                </div>

                <div class="summary-row">
                    <span>Status</span>
                    <strong><?php echo htmlspecialchars($order['order_status']); ?></strong>
                </div>

                <div class="summary-row">
                    <span>Total</span>
                    <strong class="summary-total">R<?php echo htmlspecialchars(number_format($order['total_amount'], 2)); ?></strong>
                </div>

                <div class="payment-warning">
                    <h3>Presentation note</h3>
                    <p>
                        This is a safe demo payment flow. It proves the order and payment process without using real banking details.
                    </p>
                </div>
            </aside>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest</p>
        <p>Demo payment page connected to MySQL payments.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>

<?php
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>