<?php
include "db_connect.php";

echo "TradeNest database connected successfully.";
?>