<?php
include "db_connect.php";

$sql = "SELECT 
            products.product_id,
            products.product_name,
            products.product_description,
            products.price,
            products.product_condition,
            products.location,
            products.listing_status,
            categories.category_name,
            users.first_name,
            users.last_name
        FROM products
        INNER JOIN categories ON products.category_id = categories.category_id
        INNER JOIN users ON products.seller_id = users.user_id
        ORDER BY products.created_at DESC";

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Products | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .dynamic-products-page {
            width: calc(100% - 48px);
            max-width: 1340px;
            margin: 34px auto 120px;
        }

        .dynamic-hero {
            padding: 70px;
            border-radius: 46px;
            color: var(--paper);
            background:
                linear-gradient(90deg, rgba(9, 8, 7, 0.92), rgba(9, 8, 7, 0.28)),
                url("assets/images/hero-community.png");
            background-size: cover;
            background-position: center;
            box-shadow: var(--shadow);
            margin-bottom: 40px;
        }

        .dynamic-hero h1 {
            font-size: clamp(3.8rem, 7vw, 8rem);
            line-height: 0.88;
            letter-spacing: -6px;
            max-width: 850px;
        }

        .dynamic-hero p {
            max-width: 640px;
            margin-top: 24px;
            color: rgba(255, 248, 239, 0.74);
            line-height: 1.85;
        }

        .dynamic-table-wrap {
            padding: 34px;
            border-radius: 42px;
            background: rgba(255, 248, 239, 0.62);
            border: 1px solid rgba(38, 24, 20, 0.08);
            box-shadow: var(--soft-shadow);
            overflow-x: auto;
        }

        .dynamic-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 900px;
        }

        .dynamic-table th,
        .dynamic-table td {
            padding: 18px;
            text-align: left;
            border-bottom: 1px solid rgba(38, 24, 20, 0.10);
        }

        .dynamic-table th {
            background: var(--espresso);
            color: var(--paper);
            font-size: 0.82rem;
            text-transform: uppercase;
            letter-spacing: 1.2px;
        }

        .dynamic-table td {
            color: var(--espresso);
        }

        .status-badge {
            display: inline-block;
            padding: 7px 10px;
            border-radius: 999px;
            background: rgba(38, 24, 20, 0.08);
            font-size: 0.78rem;
            font-weight: 900;
        }

        .price {
            font-weight: 900;
        }

        @media (max-width: 680px) {
            .dynamic-products-page {
                width: calc(100% - 28px);
                margin-top: 20px;
            }

            .dynamic-hero {
                padding: 34px;
                border-radius: 34px;
            }

            .dynamic-hero h1 {
                font-size: 3.7rem;
                letter-spacing: -3.5px;
            }

            .dynamic-table-wrap {
                padding: 20px;
                border-radius: 32px;
            }
        }
    </style>
</head>
<body>

    <header class="site-header">
        <a href="index.php" class="brand">TradeNest</a>

        <nav class="desktop-nav">
            <a href="browse.php">Browse</a>
            <a href="sell.php">Sell</a>
            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Admin</a>
        </nav>

        <div class="header-actions">
            <a href="login.php" class="login-link">Login</a>
            <a href="register.php" class="join-btn">Join now</a>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="browse.php">Browse</a>
        <a href="sell.php">Sell</a>
        <a href="dashboard.php">Dashboard</a>
        <a href="logout.php">Admin</a>
        <a href="login.php">Login</a>
        <a href="register.php">Join now</a>
    </nav>

    <main class="dynamic-products-page">

        <section class="dynamic-hero">
            <p class="section-label">Dynamic PHP page</p>
            <h1>Products loaded from MySQL.</h1>
            <p>
                This page retrieves product records directly from the TradeNest MySQL database using PHP.
                It proves that the website is connected to the database and can display stored product information.
            </p>
        </section>

        <section class="dynamic-table-wrap">
            <table class="dynamic-table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Category</th>
                        <th>Seller</th>
                        <th>Location</th>
                        <th>Condition</th>
                        <th>Price</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['product_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['category_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['first_name'] . " " . $row['last_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['location']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['product_condition']) . "</td>";
                            echo "<td class='price'>R" . htmlspecialchars($row['price']) . "</td>";
                            echo "<td><span class='status-badge'>" . htmlspecialchars($row['listing_status']) . "</span></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='7'>No products found in the database.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </section>

    </main>

    <footer class="footer">
        <p>TradeNest</p>
        <p>Dynamic PHP product page connected to MySQL.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>

<?php
mysqli_close($conn);
?>