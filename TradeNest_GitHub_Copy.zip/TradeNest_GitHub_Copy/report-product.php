<?php
session_start();
include "db_connect.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$isLoggedIn = isset($_SESSION["user_id"]);
$firstName = $_SESSION["first_name"];
$lastName = $_SESSION["last_name"];
$roleName = $_SESSION["role_name"];
$reporter_id = $_SESSION["user_id"];

$product_id = isset($_GET["id"]) ? intval($_GET["id"]) : 0;

$message = "";
$error_message = "";

if ($product_id <= 0) {
    header("Location: browse.php");
    exit();
}

$productSql = "SELECT 
                    products.product_id,
                    products.product_name,
                    products.product_description,
                    products.price,
                    products.product_condition,
                    products.location,
                    products.image_url,
                    products.listing_status,
                    categories.category_name,
                    seller.user_id AS seller_id,
                    seller.first_name AS seller_first_name,
                    seller.last_name AS seller_last_name,
                    seller.email AS seller_email
               FROM products
               INNER JOIN categories ON products.category_id = categories.category_id
               INNER JOIN users AS seller ON products.seller_id = seller.user_id
               WHERE products.product_id = ?";

$productStmt = mysqli_prepare($conn, $productSql);
mysqli_stmt_bind_param($productStmt, "i", $product_id);
mysqli_stmt_execute($productStmt);
$productResult = mysqli_stmt_get_result($productStmt);

if (mysqli_num_rows($productResult) !== 1) {
    header("Location: browse.php");
    exit();
}

$product = mysqli_fetch_assoc($productResult);

function getProductImage($imageUrl, $categoryName) {
    if (!empty($imageUrl)) {
        return $imageUrl;
    }

    $images = [
        "Fashion" => "https://images.unsplash.com/photo-1523398002811-999ca8dec234?auto=format&fit=crop&w=900&q=80",
        "Electronics" => "https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=900&q=80",
        "Furniture" => "https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?auto=format&fit=crop&w=900&q=80",
        "Books" => "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&w=900&q=80",
        "Beauty" => "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=900&q=80",
        "Handmade" => "assets/images/handmade-community.png"
    ];

    return $images[$categoryName] ?? "assets/images/hero-community.png";
}

$productImage = getProductImage($product["image_url"], $product["category_name"]);
$isOwnProduct = intval($reporter_id) === intval($product["seller_id"]);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $report_reason = trim($_POST["report_reason"]);
    $extra_details = trim($_POST["extra_details"]);

    if (empty($report_reason)) {
        $error_message = "Please select a reason for reporting this product.";
    } elseif ($isOwnProduct) {
        $error_message = "You cannot report your own product listing.";
    } else {
        $full_reason = $report_reason;

        if (!empty($extra_details)) {
            $full_reason .= " — " . $extra_details;
        }

        $reported_user_id = $product["seller_id"];
        $report_status = "Open";

        $insertSql = "INSERT INTO reports 
                        (reporter_id, reported_user_id, product_id, report_reason, report_status)
                      VALUES (?, ?, ?, ?, ?)";

        $insertStmt = mysqli_prepare($conn, $insertSql);
        mysqli_stmt_bind_param(
            $insertStmt,
            "iiiss",
            $reporter_id,
            $reported_user_id,
            $product_id,
            $full_reason,
            $report_status
        );

        if (mysqli_stmt_execute($insertStmt)) {
            $message = "Your report has been submitted. An authorised admin user will review this listing.";
        } else {
            $error_message = "Could not submit the report. Please try again.";
        }

        mysqli_stmt_close($insertStmt);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Product | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .report-page-layout {
            width: calc(100% - 48px);
            max-width: 1340px;
            margin: 0 auto 120px;
            display: grid;
            grid-template-columns: 0.34fr 0.66fr;
            gap: 28px;
            align-items: flex-start;
        }

        .report-main {
            display: grid;
            gap: 28px;
        }

        .report-message-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(66, 122, 77, 0.14);
            color: #2f6b3c;
            font-weight: 900;
            line-height: 1.5;
            margin-bottom: 22px;
        }

        .report-error-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(198, 90, 44, 0.14);
            color: #a6532e;
            font-weight: 900;
            line-height: 1.5;
            margin-bottom: 22px;
        }

        .reported-product-card {
            display: grid;
            grid-template-columns: 0.42fr 0.58fr;
            gap: 24px;
            align-items: stretch;
        }

        .reported-product-image {
            min-height: 300px;
            border-radius: 32px;
            background-size: cover;
            background-position: center;
            box-shadow: var(--soft-shadow);
        }

        .reported-product-info {
            padding: 28px;
            border-radius: 32px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
        }

        .reported-product-info span {
            display: block;
            color: var(--clay);
            font-size: 0.72rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            margin-bottom: 10px;
        }

        .reported-product-info h3 {
            color: var(--espresso);
            font-size: clamp(1.8rem, 3vw, 2.8rem);
            line-height: 0.95;
            letter-spacing: -1.5px;
            margin-bottom: 14px;
        }

        .reported-product-info p {
            color: var(--muted);
            line-height: 1.7;
            font-weight: 700;
            margin-bottom: 12px;
        }

        .reported-price {
            display: inline-flex;
            margin-top: 8px;
            padding: 10px 14px;
            border-radius: 999px;
            background: rgba(38, 24, 20, 0.08);
            color: var(--espresso);
            font-weight: 900;
        }

        .report-form {
            margin-top: 4px;
        }

        .report-info-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 18px;
        }

        .report-info-card {
            padding: 24px;
            border-radius: 28px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
        }

        .report-info-card span {
            display: block;
            color: var(--clay);
            font-size: 0.72rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            margin-bottom: 10px;
        }

        .report-info-card h3 {
            color: var(--espresso);
            font-size: 1.15rem;
            margin-bottom: 10px;
        }

        .report-info-card p {
            color: var(--muted);
            line-height: 1.7;
            font-weight: 700;
            font-size: 0.95rem;
        }

        .report-submit-btn {
            border: none;
            cursor: pointer;
        }

        @media (max-width: 1050px) {
            .report-page-layout {
                grid-template-columns: 1fr;
            }

            .reported-product-card {
                grid-template-columns: 1fr;
            }

            .report-info-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 680px) {
            .report-page-layout {
                width: calc(100% - 28px);
            }

            .reported-product-image,
            .reported-product-info {
                border-radius: 26px;
            }
        }
    </style>
</head>
<body>

    <header class="site-header">
        <a href="index.php" class="brand">TradeNest</a>

        <nav class="desktop-nav">
            <a href="browse.php">Browse</a>
            <a href="sell.php">Sell</a>
            <a href="faq.php">Help</a>
            <a href="admin-login.php">Admin</a>
        </nav>

        <div class="header-actions">
            <a href="dashboard.php" class="login-link">
                Hi, <?php echo htmlspecialchars($firstName); ?>
            </a>
            <a href="logout.php" class="join-btn">Logout</a>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="browse.php">Browse</a>
        <a href="sell.php">Sell</a>
        <a href="faq.php">Help</a>
        <a href="admin-login.php">Admin</a>
        <a href="dashboard.php">Dashboard</a>
        <a href="logout.php">Logout</a>
    </nav>

    <main>

        <section class="admin-page-hero">
            <div>
                <p class="section-label">Report product</p>
                <h1>Help keep TradeNest safe.</h1>
                <p>
                    If a listing looks suspicious, misleading, duplicated or unsafe, users can submit a report.
                    Reports are saved for admin review and support the product moderation process.
                </p>
            </div>

            <div class="admin-hero-card">
                <span>Trust and safety</span>
                <h3>Reports do not remove products automatically.</h3>
                <p>
                    They create a review record so authorised admin users can investigate and take appropriate action.
                </p>
            </div>
        </section>

        <section class="report-page-layout">

            <aside class="admin-sidebar-panel">
                <div class="admin-profile-card">
                    <div class="admin-avatar">!</div>
                    <h3>Safety Report</h3>
                    <p>Product concern</p>
                    <span>Admin review</span>
                </div>

                <nav class="admin-side-menu">
                    <a href="product.php?id=<?php echo $product_id; ?>">Back to product</a>
                    <a href="browse.php">Browse products</a>
                    <a href="faq.php">Help Centre</a>
                    <a href="contact.php">Contact support</a>
                    <a href="terms.php">Terms and conditions</a>
                    <a href="dashboard.php">Dashboard</a>
                </nav>
            </aside>

            <div class="report-main">

                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Reported listing</p>
                            <h2>Product under review</h2>
                        </div>

                        <a href="product.php?id=<?php echo $product_id; ?>">View product</a>
                    </div>

                    <div class="reported-product-card">
                        <div 
                            class="reported-product-image" 
                            style="background-image: url('<?php echo htmlspecialchars($productImage); ?>');"
                        ></div>

                        <div class="reported-product-info">
                            <span><?php echo htmlspecialchars($product["category_name"]); ?> · <?php echo htmlspecialchars($product["location"]); ?></span>

                            <h3><?php echo htmlspecialchars($product["product_name"]); ?></h3>

                            <p>
                                <?php echo htmlspecialchars($product["product_description"]); ?>
                            </p>

                            <p>
                                <strong>Condition:</strong> <?php echo htmlspecialchars($product["product_condition"]); ?><br>
                                <strong>Status:</strong> <?php echo htmlspecialchars($product["listing_status"]); ?><br>
                                <strong>Seller:</strong> <?php echo htmlspecialchars($product["seller_first_name"] . " " . $product["seller_last_name"]); ?>
                            </p>

                            <div class="reported-price">
                                R<?php echo htmlspecialchars(number_format($product["price"], 2)); ?>
                            </div>
                        </div>
                    </div>
                </section>

                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Submit report</p>
                            <h2>Tell us what seems wrong</h2>
                        </div>
                    </div>

                    <?php if (!empty($message)) { ?>
                        <div class="report-message-box">
                            <?php echo htmlspecialchars($message); ?>
                        </div>
                    <?php } ?>

                    <?php if (!empty($error_message)) { ?>
                        <div class="report-error-box">
                            <?php echo htmlspecialchars($error_message); ?>
                        </div>
                    <?php } ?>

                    <?php if ($isOwnProduct) { ?>
                        <div class="report-error-box">
                            You are viewing your own listing, so the report form is disabled for this product.
                        </div>
                    <?php } else { ?>
                        <form class="admin-product-form report-form" method="POST" action="report-product.php?id=<?php echo $product_id; ?>">
                            <div class="form-grid">

                                <div class="form-group full-width">
                                    <label for="report_reason">Reason for report</label>
                                    <select id="report_reason" name="report_reason" required>
                                        <option value="">Select a reason</option>
                                        <option value="Possible scam or suspicious listing">Possible scam or suspicious listing</option>
                                        <option value="Misleading product description">Misleading product description</option>
                                        <option value="Fake or stolen product image">Fake or stolen product image</option>
                                        <option value="Duplicate listing">Duplicate listing</option>
                                        <option value="Inappropriate or unsafe item">Inappropriate or unsafe item</option>
                                        <option value="Wrong price or product information">Wrong price or product information</option>
                                        <option value="Other concern">Other concern</option>
                                    </select>
                                </div>

                                <div class="form-group full-width">
                                    <label for="extra_details">Additional details</label>
                                    <textarea 
                                        id="extra_details" 
                                        name="extra_details" 
                                        placeholder="Briefly explain what seems wrong with this listing..."
                                    ></textarea>
                                </div>

                            </div>

                            <div class="form-actions">
                                <a href="product.php?id=<?php echo $product_id; ?>" class="secondary-form-btn">Cancel</a>
                                <button type="submit" class="primary-form-btn report-submit-btn">Submit report</button>
                            </div>
                        </form>
                    <?php } ?>
                </section>

                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">How reports help</p>
                            <h2>Trust and safety workflow</h2>
                        </div>
                    </div>

                    <div class="report-info-grid">
                        <article class="report-info-card">
                            <span>01</span>
                            <h3>User submits report</h3>
                            <p>
                                A logged-in user reports a product that appears suspicious, misleading or unsafe.
                            </p>
                        </article>

                        <article class="report-info-card">
                            <span>02</span>
                            <h3>Admin reviews it</h3>
                            <p>
                                The report appears on the admin reports page where authorised users can investigate it.
                            </p>
                        </article>

                        <article class="report-info-card">
                            <span>03</span>
                            <h3>Action is taken</h3>
                            <p>
                                Admin users can update the report status and moderate the product if needed.
                            </p>
                        </article>
                    </div>
                </section>

            </div>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest</p>
        <p>Product reporting for safer local buying and selling.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>

<?php
mysqli_stmt_close($productStmt);
mysqli_close($conn);
?>