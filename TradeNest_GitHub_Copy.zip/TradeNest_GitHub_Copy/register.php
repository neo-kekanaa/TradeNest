<?php
session_start();
include "db_connect.php";

$message = "";
$error_message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $role_name = trim($_POST["userRole"]);
    $first_name = trim($_POST["firstName"]);
    $last_name = trim($_POST["lastName"]);
    $email = trim($_POST["email"]);
    $phone_number = trim($_POST["phone"]);
    $password = trim($_POST["password"]);
    $confirm_password = trim($_POST["confirmPassword"]);
    $selected_location = trim($_POST["location"]);
    $custom_location = trim($_POST["customLocation"]);
    $agreed_terms = isset($_POST["termsAgree"]);

    if ($selected_location === "Other") {
        $location = $custom_location;
    } else {
        $location = $selected_location;
    }

    if (
        empty($role_name) ||
        empty($first_name) ||
        empty($last_name) ||
        empty($email) ||
        empty($phone_number) ||
        empty($password) ||
        empty($confirm_password) ||
        empty($location)
    ) {
        $error_message = "Please complete all required fields.";
    } elseif ($password !== $confirm_password) {
        $error_message = "Passwords do not match.";
    } elseif (!$agreed_terms) {
        $error_message = "Please agree to the TradeNest terms before creating your account.";
    } else {
        $checkSql = "SELECT user_id FROM users WHERE email = ?";
        $checkStmt = mysqli_prepare($conn, $checkSql);
        mysqli_stmt_bind_param($checkStmt, "s", $email);
        mysqli_stmt_execute($checkStmt);
        $checkResult = mysqli_stmt_get_result($checkStmt);

        if (mysqli_num_rows($checkResult) > 0) {
            $error_message = "An account with this email address already exists.";
        } else {
            $roleSql = "SELECT role_id FROM roles WHERE role_name = ?";
            $roleStmt = mysqli_prepare($conn, $roleSql);
            mysqli_stmt_bind_param($roleStmt, "s", $role_name);
            mysqli_stmt_execute($roleStmt);
            $roleResult = mysqli_stmt_get_result($roleStmt);

            if (mysqli_num_rows($roleResult) === 1) {
                $role = mysqli_fetch_assoc($roleResult);
                $role_id = $role["role_id"];

                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                $insertSql = "INSERT INTO users 
                    (role_id, first_name, last_name, email, password, phone_number, location, account_status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'Active')";

                $insertStmt = mysqli_prepare($conn, $insertSql);
                mysqli_stmt_bind_param(
                    $insertStmt,
                    "issssss",
                    $role_id,
                    $first_name,
                    $last_name,
                    $email,
                    $hashed_password,
                    $phone_number,
                    $location
                );

                if (mysqli_stmt_execute($insertStmt)) {
                    $message = "Account created successfully. You can now log in.";
                } else {
                    $error_message = "Could not create your account. Please try again.";
                }

                mysqli_stmt_close($insertStmt);
            } else {
                $error_message = "Invalid account role selected.";
            }

            mysqli_stmt_close($roleStmt);
        }

        mysqli_stmt_close($checkStmt);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .auth-message-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(66, 122, 77, 0.14);
            color: #2f6b3c;
            font-weight: 900;
            line-height: 1.5;
            margin-bottom: 18px;
        }

        .auth-error-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(198, 90, 44, 0.14);
            color: #a6532e;
            font-weight: 900;
            line-height: 1.5;
            margin-bottom: 18px;
        }

        .auth-submit {
            border: none;
            cursor: pointer;
            font: inherit;
        }

        .location-helper {
            display: flex;
            gap: 12px;
            align-items: center;
            flex-wrap: wrap;
            margin-top: 12px;
        }

        .location-helper button {
            border: none;
            border-radius: 999px;
            padding: 12px 16px;
            background: #2b241f;
            color: #fffaf4;
            font-weight: 900;
            cursor: pointer;
            font: inherit;
        }

        .location-helper small {
            color: rgba(40, 30, 20, 0.62);
            font-weight: 700;
            line-height: 1.5;
        }

        #customLocationWrap {
            display: none;
        }
    </style>
</head>
<body>

    <header class="site-header">
        <a href="index.php" class="brand">TradeNest</a>

        <nav class="desktop-nav">
            <a href="browse.php">Browse</a>
            <a href="sell.php">Sell</a>
            <a href="faq.php">Help</a>
            <a href="admin-login.php">Admin</a>
        </nav>

        <div class="header-actions">
            <a href="login.php" class="login-link">Login</a>
            <a href="register.php" class="join-btn">Join now</a>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="browse.php">Browse</a>
        <a href="sell.php">Sell</a>
        <a href="faq.php">Help</a>
        <a href="admin-login.php">Admin</a>
        <a href="login.php">Login</a>
        <a href="register.php">Join now</a>
    </nav>

    <main>

        <section class="auth-page">

            <div class="auth-visual register-visual">
                <div class="auth-visual-content">
                    <p class="section-label">Join the market</p>
                    <h1>Create your local trading profile.</h1>
                    <p>
                        Register as a buyer or seller and become part of a cleaner, safer way to trade within South African communities.
                    </p>
                </div>

                <div class="auth-floating-card">
                    <span>TradeNest</span>
                    <h3>Buyer + Seller accounts</h3>
                    <p>Built for browsing, listing and managing local products.</p>
                </div>
            </div>

            <div class="auth-panel">
                <div class="auth-heading">
                    <p class="section-label">Create account</p>
                    <h2>Start trading</h2>
                    <p>
                        Fill in your details to create a TradeNest account. You can register as a buyer or seller.
                    </p>
                </div>

                <?php if (!empty($message)) { ?>
                    <div class="auth-message-box">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php } ?>

                <?php if (!empty($error_message)) { ?>
                    <div class="auth-error-box">
                        <?php echo htmlspecialchars($error_message); ?>
                    </div>
                <?php } ?>

                <form class="auth-form" method="POST" action="register.php">

                    <div class="role-selector">
                        <label class="role-card">
                            <input type="radio" name="userRole" value="Buyer" checked>
                            <span>Buyer</span>
                            <small>Browse products and place orders.</small>
                        </label>

                        <label class="role-card">
                            <input type="radio" name="userRole" value="Seller">
                            <span>Seller</span>
                            <small>List products and manage sales.</small>
                        </label>
                    </div>

                    <div class="form-grid">
                        <div class="form-group">
                            <label for="firstName">First name</label>
                            <input 
                                type="text" 
                                id="firstName" 
                                name="firstName"
                                placeholder="e.g. Neo"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="lastName">Last name</label>
                            <input 
                                type="text" 
                                id="lastName" 
                                name="lastName"
                                placeholder="e.g. Kekana"
                                required
                            >
                        </div>

                        <div class="form-group full-width">
                            <label for="email">Email address</label>
                            <input 
                                type="email" 
                                id="email" 
                                name="email"
                                placeholder="e.g. name@email.com"
                                required
                            >
                        </div>

                        <div class="form-group full-width">
                            <label for="phone">Phone number</label>
                            <input 
                                type="tel" 
                                id="phone" 
                                name="phone"
                                placeholder="e.g. 071 234 5678"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="password">Password</label>
                            <input 
                                type="password" 
                                id="password" 
                                name="password"
                                placeholder="Create a password"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="confirmPassword">Confirm password</label>
                            <input 
                                type="password" 
                                id="confirmPassword" 
                                name="confirmPassword"
                                placeholder="Confirm password"
                                required
                            >
                        </div>

                        <div class="form-group full-width">
                            <label for="location">Main location</label>
                            <select id="location" name="location" required>
                                <option value="">Select your area</option>
                                <option value="Johannesburg">Johannesburg</option>
                                <option value="Soweto">Soweto</option>
                                <option value="Tembisa">Tembisa</option>
                                <option value="Midrand">Midrand</option>
                                <option value="Pretoria">Pretoria</option>
                                <option value="Alexandra">Alexandra</option>
                                <option value="Sandton">Sandton</option>
                                <option value="Randburg">Randburg</option>
                                <option value="Roodepoort">Roodepoort</option>
                                <option value="Centurion">Centurion</option>
                                <option value="Kempton Park">Kempton Park</option>
                                <option value="Boksburg">Boksburg</option>
                                <option value="Benoni">Benoni</option>
                                <option value="Germiston">Germiston</option>
                                <option value="Fourways">Fourways</option>
                                <option value="Other">Other / enter my own location</option>
                            </select>

                            <div class="location-helper">
                                <button type="button" id="useCurrentLocation">Use my current location</button>
                                <small id="locationStatus">
                                    You can also choose “Other” and type your location manually.
                                </small>
                            </div>
                        </div>

                        <div class="form-group full-width" id="customLocationWrap">
                            <label for="customLocation">Your location</label>
                            <input 
                                type="text" 
                                id="customLocation" 
                                name="customLocation"
                                placeholder="e.g. Braamfontein, Hatfield, Rosebank, Durban, Cape Town"
                            >
                        </div>
                    </div>

                    <label class="terms-row">
					<input type="checkbox" name="termsAgree" value="1">
					<span>
							I agree to the 
						<a href="terms.php" target="_blank" style="font-weight: 900; text-decoration: underline;">
							TradeNest Terms and Conditions
						</a>
							and understand that my account may be reviewed for safety.
					</span>
</label>

                    <button type="submit" class="auth-submit">Create account</button>

                    <p class="auth-switch">
                        Already have an account?
                        <a href="login.php">Login here</a>
                    </p>

                </form>
            </div>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest</p>
        <p>Buyer and seller account creation for Local buying and selling, made simple.place users.</p>
    </footer>

    <script src="assets/js/app.js"></script>

    <script>
        const locationSelect = document.getElementById("location");
        const customLocationWrap = document.getElementById("customLocationWrap");
        const customLocationInput = document.getElementById("customLocation");
        const useCurrentLocationBtn = document.getElementById("useCurrentLocation");
        const locationStatus = document.getElementById("locationStatus");

        locationSelect.addEventListener("change", function () {
            if (locationSelect.value === "Other") {
                customLocationWrap.style.display = "block";
                customLocationInput.required = true;
            } else {
                customLocationWrap.style.display = "none";
                customLocationInput.required = false;
                customLocationInput.value = "";
            }
        });

        useCurrentLocationBtn.addEventListener("click", function () {
            if (!navigator.geolocation) {
                locationStatus.textContent = "Your browser does not support current location selection.";
                return;
            }

            locationStatus.textContent = "Requesting your current location...";

            navigator.geolocation.getCurrentPosition(
                function (position) {
                    const latitude = position.coords.latitude.toFixed(5);
                    const longitude = position.coords.longitude.toFixed(5);

                    locationSelect.value = "Other";
                    customLocationWrap.style.display = "block";
                    customLocationInput.required = true;
                    customLocationInput.value = "Current location: " + latitude + ", " + longitude;

                    locationStatus.textContent = "Current location added successfully.";
                },
                function () {
                    locationStatus.textContent = "Location permission was not granted. You can type your location manually.";
                }
            );
        });
    </script>
</body>
</html>

<?php
mysqli_close($conn);
?>