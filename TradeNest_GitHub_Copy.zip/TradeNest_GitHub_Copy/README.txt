# TradeNest

TradeNest is a customer-to-customer e-commerce platform developed for an academic e-commerce project. The system allows users to buy and sell products locally, while admins manage users, roles, products, reports and orders.

## Features

- User registration and login
- Buyer and seller dashboard
- Product browsing and filtering
- Product details page
- Product image upload
- Checkout and payment flow
- Product marked as Sold after payment
- Product reporting
- Admin dashboard
- Product moderation
- Report management
- Order management
- User and role management
- Help Centre, Contact Support and Terms pages

## Technical Stack

- HTML
- CSS
- JavaScript
- PHP
- MySQL
- XAMPP / phpMyAdmin for local development

## Database

The database export file is included as:

`tradenest_database.sql`

To run the project locally:

1. Start XAMPP.
2. Run Apache and MySQL.
3. Create/import the database in phpMyAdmin.
4. Update `db_connect.php` with your own database credentials.
5. Place the project folder inside `htdocs`.
6. Open the project in a browser.

## Live Website

https://dash.infinityfree.com/accounts/if0_42300699/domains/tradenest.infinityfreeapp.com


## Demo Login Details

Admin:

- Email: admin@mzansimarket.co.za
- Password: admin123

Seller:

- Email: seller@mzansimarket.co.za
- Password: seller123

Buyer:

- Email: buyer@mzansimarket.co.za
- Password: buyer123

## Notes

This project was originally developed locally using XAMPP and later deployed to a free PHP/MySQL hosting environment. Some browsers may display a warning due to free-hosting subdomain reputation.

## Author

Neo Kekana