<?php
session_start();
include "db_connect.php";

$isLoggedIn = isset($_SESSION["user_id"]);
$firstName = $isLoggedIn ? $_SESSION["first_name"] : "";
$roleName = $isLoggedIn ? $_SESSION["role_name"] : "";

$search = isset($_GET["search"]) ? trim($_GET["search"]) : "";
$category = isset($_GET["category"]) ? trim($_GET["category"]) : "";
$location = isset($_GET["location"]) ? trim($_GET["location"]) : "";
$price = isset($_GET["price"]) ? trim($_GET["price"]) : "";

$sql = "SELECT 
            products.product_id,
            products.product_name,
            products.product_description,
            products.price,
            products.product_condition,
            products.location,
            products.image_url,
            products.listing_status,
            categories.category_name,
            users.first_name,
            users.last_name
        FROM products
        INNER JOIN categories ON products.category_id = categories.category_id
        INNER JOIN users ON products.seller_id = users.user_id
        WHERE products.listing_status = 'Approved'";

$params = [];
$types = "";

if (!empty($search)) {
    $sql .= " AND (
                products.product_name LIKE ? 
                OR products.product_description LIKE ?
                OR products.location LIKE ?
                OR categories.category_name LIKE ?
            )";

    $searchTerm = "%" . $search . "%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $types .= "ssss";
}

if (!empty($category) && $category !== "All") {
    $sql .= " AND categories.category_name = ?";
    $params[] = $category;
    $types .= "s";
}

if (!empty($location) && $location !== "All") {
    $sql .= " AND products.location LIKE ?";
    $locationTerm = "%" . $location . "%";
    $params[] = $locationTerm;
    $types .= "s";
}

if (!empty($price) && $price !== "All") {
    if ($price === "under200") {
        $sql .= " AND products.price < 200";
    } elseif ($price === "200to500") {
        $sql .= " AND products.price BETWEEN 200 AND 500";
    } elseif ($price === "500to1000") {
        $sql .= " AND products.price BETWEEN 500 AND 1000";
    } elseif ($price === "above1000") {
        $sql .= " AND products.price > 1000";
    }
}

$sql .= " ORDER BY products.created_at DESC";

$stmt = mysqli_prepare($conn, $sql);

if (!empty($params)) {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}

mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$categoriesSql = "SELECT category_name FROM categories ORDER BY category_name ASC";
$categoriesResult = mysqli_query($conn, $categoriesSql);

function getProductImage($categoryName) {
    $images = [
        "Fashion" => "https://images.unsplash.com/photo-1523398002811-999ca8dec234?auto=format&fit=crop&w=900&q=80",
        "Electronics" => "https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=700&q=80",
        "Furniture" => "https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?auto=format&fit=crop&w=700&q=80",
        "Books" => "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&w=700&q=80",
        "Beauty" => "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=700&q=80",
        "Handmade" => "assets/images/handmade-community.png"
    ];

    return $images[$categoryName] ?? "assets/images/hero-community.png";
}

function chooseProductImage($imageUrl, $categoryName) {
    if (!empty($imageUrl)) {
        return $imageUrl;
    }

    return getProductImage($categoryName);
}

function buildFilterLink($category, $location, $price) {
    $query = [];

    if (!empty($category)) {
        $query["category"] = $category;
    }

    if (!empty($location)) {
        $query["location"] = $location;
    }

    if (!empty($price)) {
        $query["price"] = $price;
    }

    return "browse.php" . (!empty($query) ? "?" . http_build_query($query) : "");
}

function getPriceLabel($price) {
    if ($price === "under200") {
        return "Under R200";
    } elseif ($price === "200to500") {
        return "R200 - R500";
    } elseif ($price === "500to1000") {
        return "R500 - R1 000";
    } elseif ($price === "above1000") {
        return "Above R1 000";
    }

    return "";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browse Products | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .filter-panel .filter-btn {
            display: block;
            width: 100%;
            box-sizing: border-box;
            margin-bottom: 10px;
            padding: 12px 16px;
            border-radius: 999px;
            text-decoration: none;
            font-size: 0.95rem;
            font-weight: 800;
            line-height: 1.2;
            color: #2b241f;
            background: rgba(255, 255, 255, 0.55);
            border: 1px solid rgba(40, 30, 20, 0.12);
            white-space: normal;
        }

        .filter-panel .filter-btn.active {
            background: #2b241f;
            color: #fffaf4;
            border-color: #2b241f;
        }

        .filter-panel .filter-block {
            overflow: hidden;
        }

        .active-filter-note {
            margin-top: 14px;
            color: rgba(38, 24, 20, 0.62);
            font-weight: 700;
            line-height: 1.6;
        }

        .clear-filters-link {
            display: inline-flex;
            margin-top: 12px;
            font-weight: 900;
            color: #2b241f;
            text-decoration: underline;
        }

        .trust-safety-box {
            padding: 18px;
            border-radius: 24px;
            background: rgba(255, 255, 255, 0.55);
            border: 1px solid rgba(40, 30, 20, 0.10);
        }

        .trust-safety-box p {
            color: rgba(38, 24, 20, 0.66);
            font-weight: 700;
            line-height: 1.7;
            margin-bottom: 12px;
        }

        .filter-summary {
            margin-top: 16px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .filter-summary span {
            display: inline-flex;
            padding: 9px 13px;
            border-radius: 999px;
            background: rgba(43, 36, 31, 0.08);
            color: #2b241f;
            font-weight: 900;
            font-size: 0.82rem;
        }
    </style>
</head>
<body>

    <header class="site-header">
        <a href="index.php" class="brand">TradeNest</a>

        <nav class="desktop-nav">
            <a href="browse.php">Browse</a>
            <a href="sell.php">Sell</a>
            <a href="faq.php">Help</a>
            <a href="admin-login.php">Admin</a>
        </nav>

        <div class="header-actions">
            <?php if ($isLoggedIn) { ?>
                <a href="dashboard.php" class="login-link">
                    Hi, <?php echo htmlspecialchars($firstName); ?>
                </a>
                <a href="logout.php" class="join-btn">Logout</a>
            <?php } else { ?>
                <a href="login.php" class="login-link">Login</a>
                <a href="register.php" class="join-btn">Join now</a>
            <?php } ?>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="browse.php">Browse</a>
        <a href="sell.php">Sell</a>
        <a href="faq.php">Help</a>
        <a href="admin-login.php">Admin</a>

        <?php if ($isLoggedIn) { ?>
            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        <?php } else { ?>
            <a href="login.php">Login</a>
            <a href="register.php">Join now</a>
        <?php } ?>
    </nav>

    <main>

        <section class="browse-hero">
            <div class="browse-hero-text">
                <p class="section-label">Browse TradeNest</p>
                <h1>Find what people around you are selling.</h1>
                <p>
                    Explore local listings from students, side-hustlers, township traders and everyday sellers.
                    Search by category, location or product name to find items that suit you.
                </p>

                <?php if (!empty($category) || !empty($location) || !empty($price) || !empty($search)) { ?>
                    <div class="filter-summary">
                        <?php if (!empty($search)) { ?>
                            <span>Search: <?php echo htmlspecialchars($search); ?></span>
                        <?php } ?>

                        <?php if (!empty($category) && $category !== "All") { ?>
                            <span>Category: <?php echo htmlspecialchars($category); ?></span>
                        <?php } ?>

                        <?php if (!empty($location) && $location !== "All") { ?>
                            <span>Location: <?php echo htmlspecialchars($location); ?></span>
                        <?php } ?>

                        <?php if (!empty($price) && $price !== "All") { ?>
                            <span>Price: <?php echo htmlspecialchars(getPriceLabel($price)); ?></span>
                        <?php } ?>
                    </div>
                <?php } ?>
            </div>

            <div class="browse-hero-card">
                <span>Live database</span>
                <h3>Products from MySQL</h3>
                <p>This page loads approved product listings directly from the database.</p>
            </div>
        </section>

        <section class="browse-tools">
            <form class="browse-search" method="GET" action="browse.php">
                <input 
                    type="text" 
                    name="search" 
                    placeholder="Search for denim jackets, speakers, desks..."
                    value="<?php echo htmlspecialchars($search); ?>"
                >

                <?php if (!empty($category)) { ?>
                    <input type="hidden" name="category" value="<?php echo htmlspecialchars($category); ?>">
                <?php } ?>

                <?php if (!empty($location)) { ?>
                    <input type="hidden" name="location" value="<?php echo htmlspecialchars($location); ?>">
                <?php } ?>

                <?php if (!empty($price)) { ?>
                    <input type="hidden" name="price" value="<?php echo htmlspecialchars($price); ?>">
                <?php } ?>

                <button type="submit">Search</button>
            </form>

            <div class="filter-row">
                <a 
                    class="filter-btn <?php echo empty($category) || $category === 'All' ? 'active' : ''; ?>" 
                    href="<?php echo buildFilterLink('All', $location, $price); ?>"
                >
                    All
                </a>

                <?php while ($cat = mysqli_fetch_assoc($categoriesResult)) { ?>
                    <a 
                        class="filter-btn <?php echo $category === $cat['category_name'] ? 'active' : ''; ?>" 
                        href="<?php echo buildFilterLink($cat['category_name'], $location, $price); ?>"
                    >
                        <?php echo htmlspecialchars($cat['category_name']); ?>
                    </a>
                <?php } ?>
            </div>
        </section>

        <section class="browse-layout">

            <aside class="filter-panel">
                <div class="filter-block">
                    <h3>Location</h3>

                    <a 
                        class="filter-btn <?php echo empty($location) || $location === 'All' ? 'active' : ''; ?>" 
                        href="<?php echo buildFilterLink($category, 'All', $price); ?>"
                    >
                        All locations
                    </a>

                    <a 
                        class="filter-btn <?php echo $location === 'Johannesburg' ? 'active' : ''; ?>" 
                        href="<?php echo buildFilterLink($category, 'Johannesburg', $price); ?>"
                    >
                        Johannesburg
                    </a>

                    <a 
                        class="filter-btn <?php echo $location === 'Soweto' ? 'active' : ''; ?>" 
                        href="<?php echo buildFilterLink($category, 'Soweto', $price); ?>"
                    >
                        Soweto
                    </a>

                    <a 
                        class="filter-btn <?php echo $location === 'Tembisa' ? 'active' : ''; ?>" 
                        href="<?php echo buildFilterLink($category, 'Tembisa', $price); ?>"
                    >
                        Tembisa
                    </a>

                    <a 
                        class="filter-btn <?php echo $location === 'Midrand' ? 'active' : ''; ?>" 
                        href="<?php echo buildFilterLink($category, 'Midrand', $price); ?>"
                    >
                        Midrand
                    </a>

                    <a 
                        class="filter-btn <?php echo $location === 'Pretoria' ? 'active' : ''; ?>" 
                        href="<?php echo buildFilterLink($category, 'Pretoria', $price); ?>"
                    >
                        Pretoria
                    </a>

                    <a 
                        class="filter-btn <?php echo $location === 'Sandton' ? 'active' : ''; ?>" 
                        href="<?php echo buildFilterLink($category, 'Sandton', $price); ?>"
                    >
                        Sandton
                    </a>

                    <a 
                        class="filter-btn <?php echo $location === 'Randburg' ? 'active' : ''; ?>" 
                        href="<?php echo buildFilterLink($category, 'Randburg', $price); ?>"
                    >
                        Randburg
                    </a>

                    <a 
                        class="filter-btn <?php echo $location === 'Centurion' ? 'active' : ''; ?>" 
                        href="<?php echo buildFilterLink($category, 'Centurion', $price); ?>"
                    >
                        Centurion
                    </a>

                    <?php if (!empty($location) && $location !== "All") { ?>
                        <p class="active-filter-note">
                            Showing listings that match <?php echo htmlspecialchars($location); ?>.
                        </p>
                    <?php } ?>
                </div>

                <div class="filter-block">
                    <h3>Price range</h3>

                    <a 
                        class="filter-btn <?php echo empty($price) || $price === 'All' ? 'active' : ''; ?>" 
                        href="<?php echo buildFilterLink($category, $location, 'All'); ?>"
                    >
                        All prices
                    </a>

                    <a 
                        class="filter-btn <?php echo $price === 'under200' ? 'active' : ''; ?>" 
                        href="<?php echo buildFilterLink($category, $location, 'under200'); ?>"
                    >
                        Under R200
                    </a>

                    <a 
                        class="filter-btn <?php echo $price === '200to500' ? 'active' : ''; ?>" 
                        href="<?php echo buildFilterLink($category, $location, '200to500'); ?>"
                    >
                        R200 - R500
                    </a>

                    <a 
                        class="filter-btn <?php echo $price === '500to1000' ? 'active' : ''; ?>" 
                        href="<?php echo buildFilterLink($category, $location, '500to1000'); ?>"
                    >
                        R500 - R1 000
                    </a>

                    <a 
                        class="filter-btn <?php echo $price === 'above1000' ? 'active' : ''; ?>" 
                        href="<?php echo buildFilterLink($category, $location, 'above1000'); ?>"
                    >
                        Above R1 000
                    </a>

                    <?php if (!empty($price) && $price !== "All") { ?>
                        <p class="active-filter-note">
                            Showing products priced <?php echo htmlspecialchars(getPriceLabel($price)); ?>.
                        </p>
                    <?php } ?>
                </div>

                <div class="filter-block">
                    <h3>Trust & safety</h3>

                    <div class="trust-safety-box">
                        <p>
                            Listings are reviewed through admin moderation. Suspicious products can be flagged, updated or removed by authorised admin users.
                        </p>

                        <p>
                            Buyers should check product details, seller information and order records before completing a purchase.
                        </p>

                        <a href="faq.php" class="clear-filters-link">How safety works</a>
                    </div>
                </div>

                <a href="browse.php" class="clear-filters-link">Clear all filters</a>
            </aside>

            <div class="browse-products">

                <div class="browse-result-header">
                    <div>
                        <p class="section-label">Fresh listings</p>
                        <h2>
                            <?php if (!empty($location) && $location !== "All") { ?>
                                Available in <?php echo htmlspecialchars($location); ?>
                            <?php } else { ?>
                                Available near you
                            <?php } ?>
                        </h2>
                    </div>

                    <select>
                        <option>Sort by newest</option>
                        <option>Price: low to high</option>
                        <option>Price: high to low</option>
                        <option>Most popular</option>
                    </select>
                </div>

                <div class="browse-grid">

                    <?php if (mysqli_num_rows($result) > 0) { ?>

                        <?php while ($row = mysqli_fetch_assoc($result)) { 
                            $productImage = chooseProductImage($row["image_url"], $row["category_name"]);
                        ?>

                            <article class="market-card">
                                <a href="product.php?id=<?php echo $row["product_id"]; ?>">
                                    <div 
                                        class="market-img" 
                                        style="background-image: url('<?php echo htmlspecialchars($productImage); ?>');">
                                    </div>
                                </a>

                                <div class="market-info">
                                    <p>
                                        <?php echo htmlspecialchars($row["location"]); ?> · 
                                        <?php echo htmlspecialchars($row["category_name"]); ?>
                                    </p>

                                    <h3>
                                        <?php echo htmlspecialchars($row["product_name"]); ?>
                                    </h3>

                                    <div class="market-meta">
                                        <strong>R<?php echo htmlspecialchars(number_format($row["price"], 2)); ?></strong>
                                        <span><?php echo htmlspecialchars($row["product_condition"]); ?></span>
                                    </div>

                                    <p style="margin-top: 12px; text-transform: none; letter-spacing: 0; font-weight: 600; color: rgba(38, 24, 20, 0.60);">
                                        Seller: <?php echo htmlspecialchars($row["first_name"] . " " . $row["last_name"]); ?>
                                    </p>
                                </div>
                            </article>

                        <?php } ?>

                    <?php } else { ?>

                        <div class="admin-section" style="grid-column: 1 / -1;">
                            <p class="section-label">No results</p>
                            <h2>No products found</h2>
                            <p style="margin-top: 18px; color: var(--muted); line-height: 1.7;">
                                Try searching for a different product, location, price range or category.
                            </p>

                            <a href="browse.php" class="primary-btn" style="margin-top: 20px;">Clear filters</a>
                        </div>

                    <?php } ?>

                </div>
            </div>
        </section>

    </main>

    <footer class="footer">
        <p>TradeNest</p>
        <p>Browse approved Local buying and selling, made simple.place listings connected to MySQL.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>

<?php
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>