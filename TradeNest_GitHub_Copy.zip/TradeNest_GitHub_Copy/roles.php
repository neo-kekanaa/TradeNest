<?php
session_start();
include "db_connect.php";

$adminRoles = ["Super Admin", "Product Moderator", "Support Staff"];

if (!isset($_SESSION["user_id"])) {
    header("Location: admin-login.php");
    exit();
}

if (!in_array($_SESSION["role_name"], $adminRoles)) {
    header("Location: dashboard.php");
    exit();
}

$message = "";
$error_message = "";

$admin_name = $_SESSION["first_name"] . " " . $_SESSION["last_name"];
$admin_role = $_SESSION["role_name"];
$admin_initial = strtoupper(substr($_SESSION["first_name"], 0, 1));

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["update_role"])) {

    if ($_SESSION["role_name"] !== "Super Admin") {
        $error_message = "Access denied. Only Super Admin users can update user roles.";
    } else {
        $user_id = intval($_POST["user_id"]);
        $role_id = intval($_POST["role_id"]);

        if ($user_id === intval($_SESSION["user_id"])) {
            $error_message = "You cannot change your own admin role while logged in.";
        } else {
            $updateSql = "UPDATE users SET role_id = ? WHERE user_id = ?";
            $updateStmt = mysqli_prepare($conn, $updateSql);
            mysqli_stmt_bind_param($updateStmt, "ii", $role_id, $user_id);

            if (mysqli_stmt_execute($updateStmt)) {
                $message = "User role updated successfully.";
            } else {
                $error_message = "Could not update user role.";
            }

            mysqli_stmt_close($updateStmt);
        }
    }
}

$rolesSql = "SELECT role_id, role_name, role_description FROM roles ORDER BY role_id ASC";
$rolesResult = mysqli_query($conn, $rolesSql);

$rolesForDropdownSql = "SELECT role_id, role_name FROM roles ORDER BY role_id ASC";
$rolesForDropdownResult = mysqli_query($conn, $rolesForDropdownSql);

$usersSql = "SELECT 
                users.user_id,
                users.first_name,
                users.last_name,
                users.email,
                users.account_status,
                roles.role_name
             FROM users
             INNER JOIN roles ON users.role_id = roles.role_id
             ORDER BY users.first_name ASC";

$usersResult = mysqli_query($conn, $usersSql);

$usersForDropdownSql = "SELECT 
                            users.user_id,
                            users.first_name,
                            users.last_name,
                            users.email,
                            roles.role_name
                        FROM users
                        INNER JOIN roles ON users.role_id = roles.role_id
                        ORDER BY users.first_name ASC";

$usersForDropdownResult = mysqli_query($conn, $usersForDropdownSql);

function getRoleDescription($roleName, $databaseDescription) {
    if (!empty($databaseDescription)) {
        return $databaseDescription;
    }

    $descriptions = [
        "Super Admin" => "Has full access to users, roles, products, orders, reports and system records.",
        "Product Moderator" => "Reviews product listings, approves items, flags suspicious listings and manages product moderation.",
        "Support Staff" => "Views user issues, order records and reports to support marketplace activity.",
        "Seller" => "Can create and manage their own product listings, view orders and update their own profile.",
        "Buyer" => "Can browse products, place orders and manage their own profile information."
    ];

    return $descriptions[$roleName] ?? "System role used to control access within the marketplace.";
}

function getRoleTags($roleName) {
    $tags = [
        "Super Admin" => ["Create", "Read", "Update", "Delete"],
        "Product Moderator" => ["Read", "Update", "Approve"],
        "Support Staff" => ["Read", "Support", "Resolve"],
        "Seller" => ["Create listing", "Edit own", "View orders"],
        "Buyer" => ["Browse", "Order", "Profile"]
    ];

    return $tags[$roleName] ?? ["Access controlled"];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Roles | TradeNest Admin</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .admin-message-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(66, 122, 77, 0.14);
            color: #2f6b3c;
            font-weight: 900;
            margin-bottom: 18px;
        }

        .admin-error-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(198, 90, 44, 0.14);
            color: #a6532e;
            font-weight: 900;
            margin-bottom: 18px;
        }

        .matrix-save-btn {
            border: none;
            cursor: default;
        }

        .role-note-box {
            margin-top: 22px;
            padding: 20px;
            border-radius: 22px;
            background: rgba(40, 30, 20, 0.06);
            font-weight: 800;
            line-height: 1.6;
            color: rgba(40, 30, 20, 0.75);
        }

        .role-note-box strong {
            color: #2b241f;
        }
    </style>
</head>
<body>

    <header class="site-header admin-site-header">
        <a href="admin-dashboard.php" class="brand">TradeNest Admin</a>

        <nav class="desktop-nav">
            <a href="admin-dashboard.php">Dashboard</a>
            <a href="admin-users.php">Users</a>
            <a href="roles.php">Roles</a>
            <a href="admin-products.php">Products</a>
            <a href="admin-orders.php">Orders</a>
        </nav>

        <div class="header-actions">
            <a href="index.php" class="login-link">View site</a>
            <a href="logout.php" class="join-btn">Logout</a>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="admin-dashboard.php">Dashboard</a>
        <a href="admin-users.php">Users</a>
        <a href="roles.php">Roles</a>
        <a href="admin-products.php">Products</a>
        <a href="admin-orders.php">Orders</a>
        <a href="index.php">View site</a>
        <a href="logout.php">Logout</a>
    </nav>

    <main>

        <section class="admin-page-hero roles-hero">
            <div>
                <p class="section-label">Manage roles</p>
                <h1>Give the right access to the right people.</h1>
                <p>
                    Role-Based Access Control helps TradeNest limit what each user type can view, create,
                    update or delete inside the system.
                </p>

                <p>
                    Logged in as <?php echo htmlspecialchars($admin_name); ?> 
                    · Role: <?php echo htmlspecialchars($admin_role); ?>
                </p>
            </div>

            <div class="admin-hero-card">
                <span>RBAC purpose</span>
                <h3>Access is controlled by role.</h3>
                <p>Only Super Admin users can update role assignments.</p>
            </div>
        </section>

        <section class="roles-admin-layout">

            <aside class="admin-sidebar-panel">
                <div class="admin-profile-card">
                    <div class="admin-avatar"><?php echo htmlspecialchars($admin_initial); ?></div>
                    <h3><?php echo htmlspecialchars($admin_name); ?></h3>
                    <p><?php echo htmlspecialchars($admin_role); ?></p>
                    <span>RBAC Active</span>
                </div>

                <nav class="admin-side-menu">
                    <a href="admin-dashboard.php">Overview</a>
                    <a href="admin-users.php">Manage users</a>
                    <a href="roles.php" class="active">Manage roles</a>
                    <a href="admin-products.php">Manage products</a>
                    <a href="admin-orders.php">Orders</a>
                    <a href="admin-reports.php">Reports</a>
                </nav>
            </aside>

            <div class="roles-admin-main">

                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Access roles</p>
                            <h2>System roles</h2>
                        </div>
                    </div>

                    <?php if (!empty($message)) { ?>
                        <div class="admin-message-box">
                            <?php echo htmlspecialchars($message); ?>
                        </div>
                    <?php } ?>

                    <?php if (!empty($error_message)) { ?>
                        <div class="admin-error-box">
                            <?php echo htmlspecialchars($error_message); ?>
                        </div>
                    <?php } ?>

                    <div class="role-management-grid">

                        <?php 
                        $counter = 1;
                        while ($role = mysqli_fetch_assoc($rolesResult)) { 
                            $roleName = $role["role_name"];
                            $roleDescription = getRoleDescription($roleName, $role["role_description"]);
                            $roleTags = getRoleTags($roleName);
                        ?>
                            <article class="role-management-card">
                                <span><?php echo str_pad($counter, 2, "0", STR_PAD_LEFT); ?></span>
                                <h3><?php echo htmlspecialchars($roleName); ?></h3>
                                <p><?php echo htmlspecialchars($roleDescription); ?></p>

                                <div class="role-tags">
                                    <?php foreach ($roleTags as $tag) { ?>
                                        <small><?php echo htmlspecialchars($tag); ?></small>
                                    <?php } ?>
                                </div>
                            </article>
                        <?php 
                            $counter++;
                        } 
                        ?>

                    </div>
                </section>

                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Permission matrix</p>
                            <h2>Role access overview</h2>
                        </div>

                        <button class="matrix-save-btn">RBAC active</button>
                    </div>

                    <div class="permission-table">
                        <div class="permission-row permission-head">
                            <span>Permission</span>
                            <span>Super Admin</span>
                            <span>Moderator</span>
                            <span>Support</span>
                            <span>Seller</span>
                            <span>Buyer</span>
                        </div>

                        <div class="permission-row">
                            <span>View users</span>
                            <span>✓</span>
                            <span>—</span>
                            <span>✓</span>
                            <span>—</span>
                            <span>—</span>
                        </div>

                        <div class="permission-row">
                            <span>Create users</span>
                            <span>✓</span>
                            <span>—</span>
                            <span>—</span>
                            <span>—</span>
                            <span>—</span>
                        </div>

                        <div class="permission-row">
                            <span>Manage roles</span>
                            <span>✓</span>
                            <span>—</span>
                            <span>—</span>
                            <span>—</span>
                            <span>—</span>
                        </div>

                        <div class="permission-row">
                            <span>Approve products</span>
                            <span>✓</span>
                            <span>✓</span>
                            <span>—</span>
                            <span>—</span>
                            <span>—</span>
                        </div>

                        <div class="permission-row">
                            <span>Update orders</span>
                            <span>✓</span>
                            <span>—</span>
                            <span>✓</span>
                            <span>—</span>
                            <span>—</span>
                        </div>

                        <div class="permission-row">
                            <span>Create own listing</span>
                            <span>—</span>
                            <span>—</span>
                            <span>—</span>
                            <span>✓</span>
                            <span>—</span>
                        </div>

                        <div class="permission-row">
                            <span>Place orders</span>
                            <span>—</span>
                            <span>—</span>
                            <span>—</span>
                            <span>✓</span>
                            <span>✓</span>
                        </div>
                    </div>

                    <div class="role-note-box">
                        <strong>Note:</strong> The permission matrix shows how access is separated across user roles.
                        Super Admin users control roles and users, Product Moderators control product moderation,
                        Support Staff support order-related activity, Sellers manage their own listings, and Buyers place orders.
                    </div>
                </section>

                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Assign role</p>
                            <h2>Update user access</h2>
                        </div>
                    </div>

                    <?php if ($admin_role === "Super Admin") { ?>
                        <form class="assign-role-form" method="POST" action="roles.php">
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="selectUser">Select user</label>
                                    <select id="selectUser" name="user_id" required>
                                        <option value="">Choose a user</option>

                                        <?php while ($userOption = mysqli_fetch_assoc($usersForDropdownResult)) { ?>
                                            <option value="<?php echo $userOption["user_id"]; ?>">
                                                <?php echo htmlspecialchars($userOption["first_name"] . " " . $userOption["last_name"] . " — " . $userOption["role_name"]); ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="selectRole">Assign role</label>
                                    <select id="selectRole" name="role_id" required>
                                        <option value="">Choose a role</option>

                                        <?php while ($roleOption = mysqli_fetch_assoc($rolesForDropdownResult)) { ?>
                                            <option value="<?php echo $roleOption["role_id"]; ?>">
                                                <?php echo htmlspecialchars($roleOption["role_name"]); ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-actions">
                                <button type="reset" class="secondary-form-btn">Cancel</button>
                                <button type="submit" name="update_role" class="primary-form-btn">Update role</button>
                            </div>
                        </form>
                    <?php } else { ?>
                        <div class="role-note-box">
                            This section is view-only for your role. Only Super Admin users can update user access levels.
                        </div>
                    <?php } ?>
                </section>

                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Current users</p>
                            <h2>User role overview</h2>
                        </div>
                    </div>

                    <div class="admin-table-list">
                        <div class="admin-list-row table-top">
                            <span>Name</span>
                            <span>Role</span>
                            <span>Status</span>
                        </div>

                        <?php if (mysqli_num_rows($usersResult) > 0) { ?>
                            <?php while ($user = mysqli_fetch_assoc($usersResult)) { ?>
                                <div class="admin-list-row">
                                    <span>
                                        <?php echo htmlspecialchars($user["first_name"] . " " . $user["last_name"]); ?>
                                    </span>

                                    <span>
                                        <?php echo htmlspecialchars($user["role_name"]); ?>
                                    </span>

                                    <?php if ($user["account_status"] === "Active") { ?>
                                        <span class="admin-pill approved">Active</span>
                                    <?php } else { ?>
                                        <span class="admin-pill">
                                            <?php echo htmlspecialchars($user["account_status"]); ?>
                                        </span>
                                    <?php } ?>
                                </div>
                            <?php } ?>
                        <?php } else { ?>
                            <div class="admin-list-row">
                                <span>No users found</span>
                                <span>-</span>
                                <span class="admin-pill">Empty</span>
                            </div>
                        <?php } ?>
                    </div>
                </section>

            </div>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest Admin</p>
        <p>Role-based access control for marketplace management.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>

<?php
mysqli_close($conn);
?>