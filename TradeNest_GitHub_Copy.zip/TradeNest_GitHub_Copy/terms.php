<?php
session_start();

$isLoggedIn = isset($_SESSION["user_id"]);
$firstName = $isLoggedIn ? $_SESSION["first_name"] : "";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms and Conditions | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .terms-page-layout {
            width: calc(100% - 48px);
            max-width: 1340px;
            margin: 0 auto 120px;
            display: grid;
            grid-template-columns: 0.34fr 0.66fr;
            gap: 28px;
            align-items: flex-start;
        }

        .terms-main {
            display: grid;
            gap: 28px;
        }

        .terms-grid {
            display: grid;
            gap: 18px;
        }

        .terms-card {
            padding: 28px;
            border-radius: 30px;
            background: rgba(38, 24, 20, 0.06);
            border: 1px solid rgba(38, 24, 20, 0.08);
        }

        .terms-card span {
            display: block;
            color: var(--clay);
            font-size: 0.72rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            margin-bottom: 10px;
        }

        .terms-card h3 {
            color: var(--espresso);
            font-size: 1.35rem;
            margin-bottom: 12px;
            letter-spacing: -0.5px;
        }

        .terms-card p {
            color: var(--muted);
            line-height: 1.75;
            font-weight: 700;
            font-size: 0.96rem;
        }

        .terms-card ul {
            margin-top: 14px;
            padding-left: 20px;
            color: var(--muted);
            line-height: 1.75;
            font-weight: 700;
        }

        .terms-card li {
            margin-bottom: 8px;
        }

        .terms-highlight-card {
            padding: 30px;
            border-radius: 32px;
            background: var(--soft-black);
            color: var(--paper);
            box-shadow: var(--shadow);
        }

        .terms-highlight-card span {
            display: block;
            color: var(--sand);
            font-size: 0.72rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            margin-bottom: 10px;
        }

        .terms-highlight-card h3 {
            font-size: 1.7rem;
            margin-bottom: 10px;
            letter-spacing: -1px;
        }

        .terms-highlight-card p {
            color: rgba(255, 248, 239, 0.72);
            line-height: 1.7;
            font-weight: 700;
        }

        .terms-action-row {
            display: flex;
            gap: 14px;
            flex-wrap: wrap;
            margin-top: 24px;
        }

        .terms-action-row a {
            text-decoration: none;
        }

        @media (max-width: 1050px) {
            .terms-page-layout {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 680px) {
            .terms-page-layout {
                width: calc(100% - 28px);
            }
        }
    </style>
</head>
<body>

    <header class="site-header">
        <a href="index.php" class="brand">TradeNest</a>

        <nav class="desktop-nav">
            <a href="browse.php">Browse</a>
            <a href="sell.php">Sell</a>
            <a href="faq.php">Help</a>
            <a href="admin-login.php">Admin</a>
        </nav>

        <div class="header-actions">
            <?php if ($isLoggedIn) { ?>
                <a href="dashboard.php" class="login-link">
                    Hi, <?php echo htmlspecialchars($firstName); ?>
                </a>
                <a href="logout.php" class="join-btn">Logout</a>
            <?php } else { ?>
                <a href="login.php" class="login-link">Login</a>
                <a href="register.php" class="join-btn">Join now</a>
            <?php } ?>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="browse.php">Browse</a>
        <a href="sell.php">Sell</a>
        <a href="faq.php">Help</a>
        <a href="admin-login.php">Admin</a>

        <?php if ($isLoggedIn) { ?>
            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        <?php } else { ?>
            <a href="login.php">Login</a>
            <a href="register.php">Join now</a>
        <?php } ?>
    </nav>

    <main>

        <section class="admin-page-hero">
            <div>
                <p class="section-label">Terms and Conditions</p>
                <h1>Clear rules for safer local trading.</h1>
                <p>
                    These terms outline how buyers, sellers and admin users should use TradeNest responsibly.
                    They help protect users, product listings, orders and marketplace activity.
                </p>
            </div>

            <div class="admin-hero-card">
                <span>Marketplace rules</span>
                <h3>Trust starts with clear expectations.</h3>
                <p>
                    Users agree to provide accurate information, use the platform honestly and respect moderation decisions.
                </p>
            </div>
        </section>

        <section class="terms-page-layout">

            <aside class="admin-sidebar-panel">
                <div class="admin-profile-card">
                    <div class="admin-avatar">T</div>
                    <h3>Platform Terms</h3>
                    <p>Rules and conditions</p>
                    <span>User agreement</span>
                </div>

                <nav class="admin-side-menu">
                    <a href="faq.php">Help Centre</a>
                    <a href="contact.php">Contact support</a>
                    <a href="terms.php" class="active">Terms and conditions</a>
                    <a href="browse.php">Browse products</a>
                    <a href="sell.php">Start selling</a>
                    <a href="register.php">Create account</a>
                    <a href="login.php">User login</a>
                </nav>
            </aside>

            <div class="terms-main">

                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">User agreement</p>
                            <h2>Using TradeNest</h2>
                        </div>

                        <a href="contact.php">Need help?</a>
                    </div>

                    <div class="terms-grid">

                        <article class="terms-card">
                            <span>01</span>
                            <h3>Account registration</h3>
                            <p>
                                Users must provide accurate account information when registering. Buyers, sellers and admin users
                                are assigned roles that control which parts of the platform they can access.
                            </p>
                            <ul>
                                <li>Users must not create false or misleading accounts.</li>
                                <li>Login details should be kept private and secure.</li>
                                <li>Accounts may be reviewed if suspicious activity is detected.</li>
                            </ul>
                        </article>

                        <article class="terms-card">
                            <span>02</span>
                            <h3>Buyer responsibilities</h3>
                            <p>
                                Buyers are responsible for checking product details, seller information, price, location and condition
                                before continuing with checkout.
                            </p>
                            <ul>
                                <li>Buyers should report suspicious or misleading listings.</li>
                                <li>Buyers should use accurate contact and order information.</li>
                                <li>Buyers should not abuse the reporting or support system.</li>
                            </ul>
                        </article>

                        <article class="terms-card">
                            <span>03</span>
                            <h3>Seller responsibilities</h3>
                            <p>
                                Sellers must upload honest and accurate product information. Listings should reflect the real product,
                                its condition, price, location and availability.
                            </p>
                            <ul>
                                <li>Sellers should not post fake, unsafe or prohibited items.</li>
                                <li>Sellers should avoid duplicate or misleading listings.</li>
                                <li>Sellers understand that listings may require approval before appearing publicly.</li>
                            </ul>
                        </article>

                        <article class="terms-card">
                            <span>04</span>
                            <h3>Product moderation</h3>
                            <p>
                                TradeNest uses product moderation to keep the marketplace clean, useful and safe.
                                Admin users may approve, flag, reject or remove listings where needed.
                            </p>
                            <ul>
                                <li>Pending products may be reviewed before being shown publicly.</li>
                                <li>Flagged products may be investigated by authorised admin users.</li>
                                <li>Products that appear unsafe, misleading or suspicious may be removed.</li>
                            </ul>
                        </article>

                        <article class="terms-card">
                            <span>05</span>
                            <h3>Orders and payments</h3>
                            <p>
                                Orders and payment records are stored to support the e-commerce flow. This includes buyer, seller,
                                product, payment status and transaction reference information.
                            </p>
                            <ul>
                                <li>Users should review checkout details before confirming payment.</li>
                                <li>Payment records are linked to order records.</li>
                                <li>Admin users may update order statuses where required.</li>
                            </ul>
                        </article>

                        <article class="terms-card">
                            <span>06</span>
                            <h3>Reports and safety concerns</h3>
                            <p>
                                Logged-in users can report suspicious, misleading, duplicated or unsafe product listings.
                                Reports are saved for admin review.
                            </p>
                            <ul>
                                <li>Reports should be submitted honestly and with clear reasons.</li>
                                <li>Reports do not automatically remove products.</li>
                                <li>Authorised admin users may investigate and take moderation action.</li>
                            </ul>
                        </article>

                    </div>
                </section>

                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Access control</p>
                            <h2>Admin roles and permissions</h2>
                        </div>

                        <a href="admin-login.php">Admin login</a>
                    </div>

                    <div class="terms-grid">
                        <article class="terms-card">
                            <span>RBAC</span>
                            <h3>Role-based access control</h3>
                            <p>
                                TradeNest separates access using roles such as Buyer, Seller, Support Staff,
                                Product Moderator and Super Admin. This prevents ordinary users from accessing admin-only
                                pages and ensures platform actions are handled by authorised users.
                            </p>
                        </article>

                        <article class="terms-card">
                            <span>Support</span>
                            <h3>Support and assistance</h3>
                            <p>
                                Users can request help through the Help Centre and Contact Support page. In a full deployment,
                                support requests would be reviewed by authorised Support Staff.
                            </p>
                        </article>
                    </div>
                </section>

                <section class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Important note</p>
                            <h2>Prototype disclaimer</h2>
                        </div>
                    </div>

                    <div class="terms-highlight-card">
                        <span>Academic project</span>
                        <h3>TradeNest is a student-built e-commerce prototype.</h3>
                        <p>
                            This platform has been developed for academic demonstration purposes. Some features, such as payment processing,
                            support handling and live marketplace moderation, are simulated to show the intended system design and database flow.
                        </p>

                        <div class="terms-action-row">
                            <a href="register.php" class="join-btn">Create account</a>
                            <a href="faq.php" class="login-link">Read FAQs</a>
                            <a href="contact.php" class="login-link">Contact support</a>
                        </div>
                    </div>
                </section>

            </div>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest</p>
        <p>Terms and conditions for responsible marketplace use.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>