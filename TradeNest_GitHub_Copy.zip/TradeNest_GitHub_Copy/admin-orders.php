<?php
session_start();
include "db_connect.php";

$adminRoles = ["Super Admin", "Product Moderator", "Support Staff"];
$actionRoles = ["Super Admin", "Support Staff"];

if (!isset($_SESSION["user_id"])) {
    header("Location: admin-login.php");
    exit();
}

if (!in_array($_SESSION["role_name"], $adminRoles)) {
    header("Location: dashboard.php");
    exit();
}

$message = "";
$error_message = "";

if (isset($_GET["message"])) {
    $message = $_GET["message"];
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["update_order"])) {

    if (!in_array($_SESSION["role_name"], $actionRoles)) {
        $error_message = "Access denied. Your role can view orders but cannot update order statuses.";
    } else {
        $order_id = intval($_POST["order_id"]);
        $order_status = trim($_POST["order_status"]);

        $allowedStatuses = ["Pending", "Paid", "Processing", "Completed", "Cancelled"];

        if (!in_array($order_status, $allowedStatuses)) {
            $error_message = "Invalid order status selected.";
        } else {
            $sql = "UPDATE orders SET order_status = ? WHERE order_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "si", $order_status, $order_id);

            if (mysqli_stmt_execute($stmt)) {
                $message = "Order status updated successfully.";
            } else {
                $error_message = "Could not update order status.";
            }

            mysqli_stmt_close($stmt);
        }
    }
}

$totalOrdersResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM orders");
$totalOrders = mysqli_fetch_assoc($totalOrdersResult)["total"];

$paidOrdersResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM orders WHERE order_status = 'Paid'");
$paidOrders = mysqli_fetch_assoc($paidOrdersResult)["total"];

$completedOrdersResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM orders WHERE order_status = 'Completed'");
$completedOrders = mysqli_fetch_assoc($completedOrdersResult)["total"];

$cancelledOrdersResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM orders WHERE order_status = 'Cancelled'");
$cancelledOrders = mysqli_fetch_assoc($cancelledOrdersResult)["total"];

$ordersSql = "SELECT 
                orders.order_id,
                orders.order_date,
                orders.order_status,
                orders.total_amount,
                products.product_name,
                products.location AS product_location,
                buyer.first_name AS buyer_first_name,
                buyer.last_name AS buyer_last_name,
                buyer.email AS buyer_email,
                seller.first_name AS seller_first_name,
                seller.last_name AS seller_last_name,
                seller.email AS seller_email
              FROM orders
              INNER JOIN products ON orders.product_id = products.product_id
              INNER JOIN users AS buyer ON orders.buyer_id = buyer.user_id
              INNER JOIN users AS seller ON orders.seller_id = seller.user_id
              ORDER BY orders.order_date DESC";

$ordersResult = mysqli_query($conn, $ordersSql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Orders | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .admin-message-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(66, 122, 77, 0.14);
            color: #2f6b3c;
            font-weight: 900;
            margin-bottom: 18px;
        }

        .admin-error-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(198, 90, 44, 0.14);
            color: #a6532e;
            font-weight: 900;
            margin-bottom: 18px;
        }

        .orders-table-wrap {
            overflow-x: auto;
        }

        .orders-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 980px;
        }

        .orders-table th,
        .orders-table td {
            padding: 16px;
            text-align: left;
            border-bottom: 1px solid rgba(40, 30, 20, 0.12);
            vertical-align: top;
        }

        .orders-table th {
            font-size: 0.78rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: rgba(40, 30, 20, 0.58);
        }

        .orders-table td {
            font-weight: 700;
            color: #2b241f;
        }

        .orders-table small {
            display: block;
            margin-top: 4px;
            color: rgba(40, 30, 20, 0.58);
            font-weight: 700;
        }

        .order-status-form {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .order-status-form select {
            border: 1px solid rgba(40, 30, 20, 0.15);
            border-radius: 999px;
            padding: 10px 12px;
            font-weight: 800;
            background: #fffaf4;
            color: #2b241f;
        }

        .order-status-form button {
            border: none;
            border-radius: 999px;
            padding: 10px 14px;
            font-weight: 900;
            cursor: pointer;
            background: #2b241f;
            color: #fffaf4;
        }

        .order-pill {
            display: inline-flex;
            padding: 7px 12px;
            border-radius: 999px;
            background: rgba(40, 30, 20, 0.08);
            font-size: 0.78rem;
            font-weight: 900;
        }

        .order-pill.paid,
        .order-pill.completed {
            background: rgba(66, 122, 77, 0.16);
            color: #2f6b3c;
        }

        .order-pill.cancelled {
            background: rgba(198, 90, 44, 0.16);
            color: #a6532e;
        }
    </style>
</head>
<body>

    <header class="site-header admin-site-header">
        <a href="admin-dashboard.php" class="brand">TradeNest Admin</a>

        <nav class="desktop-nav">
            <a href="admin-dashboard.php">Dashboard</a>
            <a href="admin-users.php">Users</a>
            <a href="roles.php">Roles</a>
            <a href="admin-products.php">Products</a>
            <a href="admin-orders.php">Orders</a>
        </nav>

        <div class="header-actions">
            <a href="index.php" class="login-link">View site</a>
            <a href="logout.php" class="join-btn">Logout</a>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="admin-dashboard.php">Dashboard</a>
        <a href="admin-users.php">Users</a>
        <a href="roles.php">Roles</a>
        <a href="admin-products.php">Products</a>
        <a href="admin-orders.php">Orders</a>
        <a href="index.php">View site</a>
        <a href="logout.php">Logout</a>
    </nav>

    <main>

        <section class="admin-dashboard-hero">
            <div>
                <p class="section-label">Order management</p>
                <h1>Track orders from checkout to completion.</h1>
                <p>
                    View marketplace orders, confirm payment progress, monitor buyer and seller activity, and update order statuses from the admin side.
                </p>

                <p>
                    Logged in as <?php echo htmlspecialchars($_SESSION["first_name"] . " " . $_SESSION["last_name"]); ?> 
                    · Role: <?php echo htmlspecialchars($_SESSION["role_name"]); ?>
                </p>
            </div>

            <div class="admin-hero-card">
                <span>Order controls</span>
                <h3><?php echo htmlspecialchars($_SESSION["role_name"]); ?></h3>
                <p>
                    Super Admin and Support Staff can update order statuses. Product Moderators can view orders but focus on listing moderation.
                </p>
            </div>
        </section>

        <section class="admin-dashboard-layout">

            <aside class="admin-sidebar-panel">
                <div class="admin-profile-card">
                    <div class="admin-avatar"><?php echo htmlspecialchars(strtoupper(substr($_SESSION["first_name"], 0, 1))); ?></div>
                    <h3><?php echo htmlspecialchars($_SESSION["first_name"] . " " . $_SESSION["last_name"]); ?></h3>
                    <p><?php echo htmlspecialchars($_SESSION["role_name"]); ?></p>
                    <span>RBAC Active</span>
                </div>

                <nav class="admin-side-menu">
                    <a href="admin-dashboard.php">Overview</a>
                    <a href="admin-users.php">Manage users</a>
                    <a href="roles.php">Manage roles</a>
                    <a href="admin-products.php">Manage products</a>
                    <a href="admin-orders.php" class="active">Orders</a>
                    <a href="admin-reports.php">Reports</a>
                </nav>
            </aside>

            <div class="admin-dashboard-main">

                <div class="admin-metrics-grid">
                    <article class="admin-stat">
                        <p>Total orders</p>
                        <h3><?php echo $totalOrders; ?></h3>
                        <span>All marketplace orders</span>
                    </article>

                    <article class="admin-stat">
                        <p>Paid orders</p>
                        <h3><?php echo $paidOrders; ?></h3>
                        <span>Payment recorded</span>
                    </article>

                    <article class="admin-stat">
                        <p>Completed</p>
                        <h3><?php echo $completedOrders; ?></h3>
                        <span>Successfully completed</span>
                    </article>

                    <article class="admin-stat">
                        <p>Cancelled</p>
                        <h3><?php echo $cancelledOrders; ?></h3>
                        <span>Cancelled orders</span>
                    </article>
                </div>

                <div class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Orders</p>
                            <h2>Marketplace order records</h2>
                        </div>

                        <a href="admin-dashboard.php">Back to dashboard</a>
                    </div>

                    <?php if (!empty($message)) { ?>
                        <div class="admin-message-box">
                            <?php echo htmlspecialchars($message); ?>
                        </div>
                    <?php } ?>

                    <?php if (!empty($error_message)) { ?>
                        <div class="admin-error-box">
                            <?php echo htmlspecialchars($error_message); ?>
                        </div>
                    <?php } ?>

                    <div class="orders-table-wrap">
                        <table class="orders-table">
                            <thead>
                                <tr>
                                    <th>Order</th>
                                    <th>Product</th>
                                    <th>Buyer</th>
                                    <th>Seller</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Update</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php if (mysqli_num_rows($ordersResult) > 0) { ?>
                                    <?php while ($order = mysqli_fetch_assoc($ordersResult)) { ?>
                                        <?php
                                            $statusClass = strtolower($order["order_status"]);
                                        ?>

                                        <tr>
                                            <td>
                                                #<?php echo htmlspecialchars($order["order_id"]); ?>
                                                <small><?php echo htmlspecialchars($order["order_date"]); ?></small>
                                            </td>

                                            <td>
                                                <?php echo htmlspecialchars($order["product_name"]); ?>
                                                <small><?php echo htmlspecialchars($order["product_location"]); ?></small>
                                            </td>

                                            <td>
                                                <?php echo htmlspecialchars($order["buyer_first_name"] . " " . $order["buyer_last_name"]); ?>
                                                <small><?php echo htmlspecialchars($order["buyer_email"]); ?></small>
                                            </td>

                                            <td>
                                                <?php echo htmlspecialchars($order["seller_first_name"] . " " . $order["seller_last_name"]); ?>
                                                <small><?php echo htmlspecialchars($order["seller_email"]); ?></small>
                                            </td>

                                            <td>
                                                R<?php echo number_format($order["total_amount"], 2); ?>
                                            </td>

                                            <td>
                                                <span class="order-pill <?php echo htmlspecialchars($statusClass); ?>">
                                                    <?php echo htmlspecialchars($order["order_status"]); ?>
                                                </span>
                                            </td>

                                            <td>
                                                <?php if (in_array($_SESSION["role_name"], $actionRoles)) { ?>
                                                    <form class="order-status-form" method="POST" action="admin-orders.php">
                                                        <input type="hidden" name="order_id" value="<?php echo $order["order_id"]; ?>">

                                                        <select name="order_status">
                                                            <option value="Pending" <?php if ($order["order_status"] === "Pending") echo "selected"; ?>>Pending</option>
                                                            <option value="Paid" <?php if ($order["order_status"] === "Paid") echo "selected"; ?>>Paid</option>
                                                            <option value="Processing" <?php if ($order["order_status"] === "Processing") echo "selected"; ?>>Processing</option>
                                                            <option value="Completed" <?php if ($order["order_status"] === "Completed") echo "selected"; ?>>Completed</option>
                                                            <option value="Cancelled" <?php if ($order["order_status"] === "Cancelled") echo "selected"; ?>>Cancelled</option>
                                                        </select>

                                                        <button type="submit" name="update_order">Save</button>
                                                    </form>
                                                <?php } else { ?>
                                                    <span class="order-pill">View only</span>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } else { ?>
                                    <tr>
                                        <td colspan="7">
                                            No orders found yet. Orders will appear here after a buyer completes checkout.
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>

                </div>

            </div>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest Admin</p>
        <p>Order management for marketplace transactions.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>

<?php
mysqli_close($conn);
?>