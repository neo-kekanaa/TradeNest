<?php
session_start();
include "db_connect.php";

$error_message = "";

if (isset($_SESSION["user_id"])) {
    if (
        $_SESSION["role_name"] === "Super Admin" ||
        $_SESSION["role_name"] === "Product Moderator" ||
        $_SESSION["role_name"] === "Support Staff"
    ) {
        header("Location: admin-dashboard.php");
        exit();
    } else {
        header("Location: dashboard.php");
        exit();
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    if (empty($email) || empty($password)) {
        $error_message = "Please enter both your email address and password.";
    } else {
        $sql = "SELECT 
                    users.user_id,
                    users.first_name,
                    users.last_name,
                    users.email,
                    users.password,
                    users.account_status,
                    roles.role_name
                FROM users
                INNER JOIN roles ON users.role_id = roles.role_id
                WHERE users.email = ?";

        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) === 1) {
            $user = mysqli_fetch_assoc($result);

            if ($user["account_status"] !== "Active") {
                $error_message = "This account is not active. Please contact support.";
            } elseif (password_verify($password, $user["password"]) || $password === $user["password"]) {
                $_SESSION["user_id"] = $user["user_id"];
                $_SESSION["first_name"] = $user["first_name"];
                $_SESSION["last_name"] = $user["last_name"];
                $_SESSION["email"] = $user["email"];
                $_SESSION["role_name"] = $user["role_name"];

                if (
                    $user["role_name"] === "Super Admin" ||
                    $user["role_name"] === "Product Moderator" ||
                    $user["role_name"] === "Support Staff"
                ) {
                    header("Location: admin-dashboard.php");
                    exit();
                } else {
                    header("Location: dashboard.php");
                    exit();
                }
            } else {
                $error_message = "Incorrect password. Please try again.";
            }
        } else {
            $error_message = "No account found with that email address.";
        }

        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .auth-error-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(198, 90, 44, 0.14);
            color: #a6532e;
            font-weight: 900;
            line-height: 1.5;
            margin-bottom: 18px;
        }

        .auth-submit {
            border: none;
            cursor: pointer;
            font: inherit;
        }

        .admin-login-link {
            text-align: center;
        }
    </style>
</head>
<body>

    <header class="site-header">
        <a href="index.php" class="brand">TradeNest</a>

        <nav class="desktop-nav">
            <a href="browse.php">Browse</a>
            <a href="sell.php">Sell</a>
            <a href="faq.php">Help</a>
            <a href="admin-login.php">Admin</a>
        </nav>

        <div class="header-actions">
            <a href="login.php" class="login-link">Login</a>
            <a href="register.php" class="join-btn">Join now</a>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="browse.php">Browse</a>
        <a href="sell.php">Sell</a>
        <a href="faq.php">Help</a>
        <a href="admin-login.php">Admin</a>
        <a href="login.php">Login</a>
        <a href="register.php">Join now</a>
    </nav>

    <main>

        <section class="auth-page login-page">

            <div class="auth-visual login-visual">
                <div class="auth-visual-content">
                    <p class="section-label">Welcome back</p>
                    <h1>Pick up where your local trade left off.</h1>
                    <p>
                        Login to manage your profile, view your orders, continue selling your products, or keep browsing TradeNest.
                    </p>
                </div>

                <div class="auth-floating-card">
                    <span>Secure access</span>
                    <h3>One account for buying and selling.</h3>
                    <p>Users can access marketplace features based on their account type.</p>
                </div>
            </div>

            <div class="auth-panel login-panel">
                <div class="auth-heading">
                    <p class="section-label">Login</p>
                    <h2>Access your account</h2>
                    <p>
                        Enter your details to continue to your TradeNest profile.
                    </p>
                </div>

                <?php if (!empty($error_message)) { ?>
                    <div class="auth-error-box">
                        <?php echo htmlspecialchars($error_message); ?>
                    </div>
                <?php } ?>

                <form class="auth-form" method="POST" action="login.php">

                    <div class="form-group full-width">
                        <label for="email">Email address</label>
                        <input 
                            type="email" 
                            id="email" 
                            name="email"
                            placeholder="e.g. name@email.com"
                            required
                        >
                    </div>

                    <div class="form-group full-width">
                        <label for="password">Password</label>
                        <input 
                            type="password" 
                            id="password" 
                            name="password"
                            placeholder="Enter your password"
                            required
                        >
                    </div>

                    <div class="login-options">
                        <label>
                            <input type="checkbox" name="remember_me">
                            Remember me
                        </label>

                        <a href="forgot-password.php">Forgot password?</a>
                    </div>

                    <button type="submit" class="auth-submit">Login</button>

                    <div class="login-divider">
                        <span></span>
                        <p>or</p>
                        <span></span>
                    </div>

                    <a href="admin-login.php" class="admin-login-link">
                        Login as admin user
                    </a>

                    <p class="auth-switch">
                        Don’t have an account?
                        <a href="register.php">Create one here</a>
                    </p>

                </form>
            </div>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest</p>
        <p>Secure access for buyers, sellers and marketplace users.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>

<?php
mysqli_close($conn);
?>