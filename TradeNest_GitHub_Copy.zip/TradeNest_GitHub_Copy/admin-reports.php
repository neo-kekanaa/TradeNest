<?php
session_start();
include "db_connect.php";

$adminRoles = ["Super Admin", "Product Moderator", "Support Staff"];
$actionRoles = ["Super Admin", "Product Moderator", "Support Staff"];

if (!isset($_SESSION["user_id"])) {
    header("Location: admin-login.php");
    exit();
}

if (!in_array($_SESSION["role_name"], $adminRoles)) {
    header("Location: dashboard.php");
    exit();
}

$message = "";
$error_message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["update_report"])) {
    if (!in_array($_SESSION["role_name"], $actionRoles)) {
        $error_message = "Access denied. Your role cannot update reports.";
    } else {
        $report_id = intval($_POST["report_id"]);
        $report_status = trim($_POST["report_status"]);

        $allowedStatuses = ["Open", "Reviewing", "Resolved"];

        if (!in_array($report_status, $allowedStatuses)) {
            $error_message = "Invalid report status selected.";
        } else {
            $updateSql = "UPDATE reports SET report_status = ? WHERE report_id = ?";
            $stmt = mysqli_prepare($conn, $updateSql);
            mysqli_stmt_bind_param($stmt, "si", $report_status, $report_id);

            if (mysqli_stmt_execute($stmt)) {
                $message = "Report status updated successfully.";
            } else {
                $error_message = "Could not update report status.";
            }

            mysqli_stmt_close($stmt);
        }
    }
}

$totalReportsResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM reports");
$totalReports = mysqli_fetch_assoc($totalReportsResult)["total"];

$openReportsResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM reports WHERE report_status = 'Open'");
$openReports = mysqli_fetch_assoc($openReportsResult)["total"];

$reviewingReportsResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM reports WHERE report_status = 'Reviewing'");
$reviewingReports = mysqli_fetch_assoc($reviewingReportsResult)["total"];

$resolvedReportsResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM reports WHERE report_status = 'Resolved'");
$resolvedReports = mysqli_fetch_assoc($resolvedReportsResult)["total"];

$reportsSql = "SELECT 
                    reports.report_id,
                    reports.report_reason,
                    reports.report_status,
                    reports.report_date,
                    products.product_id,
                    products.product_name,
                    products.price,
                    products.location AS product_location,
                    products.listing_status,
                    reporter.first_name AS reporter_first_name,
                    reporter.last_name AS reporter_last_name,
                    reporter.email AS reporter_email,
                    seller.first_name AS seller_first_name,
                    seller.last_name AS seller_last_name,
                    seller.email AS seller_email
               FROM reports
               INNER JOIN products ON reports.product_id = products.product_id
               INNER JOIN users AS reporter ON reports.reporter_id = reporter.user_id
               INNER JOIN users AS seller ON reports.reported_user_id = seller.user_id
               ORDER BY reports.report_date DESC";

$reportsResult = mysqli_query($conn, $reportsSql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Reports | TradeNest</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .admin-message-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(66, 122, 77, 0.14);
            color: #2f6b3c;
            font-weight: 900;
            margin-bottom: 18px;
        }

        .admin-error-box {
            padding: 15px 18px;
            border-radius: 18px;
            background: rgba(198, 90, 44, 0.14);
            color: #a6532e;
            font-weight: 900;
            margin-bottom: 18px;
        }

        .reports-table-wrap {
            overflow-x: auto;
        }

        .reports-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1100px;
        }

        .reports-table th,
        .reports-table td {
            padding: 16px;
            text-align: left;
            border-bottom: 1px solid rgba(40, 30, 20, 0.12);
            vertical-align: top;
        }

        .reports-table th {
            font-size: 0.78rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: rgba(40, 30, 20, 0.58);
        }

        .reports-table td {
            font-weight: 700;
            color: #2b241f;
        }

        .reports-table small {
            display: block;
            margin-top: 4px;
            color: rgba(40, 30, 20, 0.58);
            font-weight: 700;
            line-height: 1.5;
        }

        .report-reason {
            max-width: 320px;
            line-height: 1.6;
            color: rgba(40, 30, 20, 0.72);
        }

        .report-status-form {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .report-status-form select {
            border: 1px solid rgba(40, 30, 20, 0.15);
            border-radius: 999px;
            padding: 10px 12px;
            font-weight: 800;
            background: #fffaf4;
            color: #2b241f;
        }

        .report-status-form button {
            border: none;
            border-radius: 999px;
            padding: 10px 14px;
            font-weight: 900;
            cursor: pointer;
            background: #2b241f;
            color: #fffaf4;
        }

        .report-pill {
            display: inline-flex;
            padding: 7px 12px;
            border-radius: 999px;
            background: rgba(40, 30, 20, 0.08);
            font-size: 0.78rem;
            font-weight: 900;
        }

        .report-pill.open {
            background: rgba(198, 90, 44, 0.16);
            color: #a6532e;
        }

        .report-pill.reviewing {
            background: rgba(212, 154, 101, 0.22);
            color: #8a5a2b;
        }

        .report-pill.resolved {
            background: rgba(66, 122, 77, 0.16);
            color: #2f6b3c;
        }

        .product-link {
            color: #2b241f;
            font-weight: 900;
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <header class="site-header admin-site-header">
        <a href="admin-dashboard.php" class="brand">TradeNest Admin</a>

        <nav class="desktop-nav">
            <a href="admin-dashboard.php">Dashboard</a>
            <a href="admin-users.php">Users</a>
            <a href="roles.php">Roles</a>
            <a href="admin-products.php">Products</a>
            <a href="admin-orders.php">Orders</a>
            <a href="admin-reports.php">Reports</a>
        </nav>

        <div class="header-actions">
            <a href="index.php" class="login-link">View site</a>
            <a href="logout.php" class="join-btn">Logout</a>
        </div>

        <button class="menu-btn" id="menuBtn">Menu</button>
    </header>

    <nav class="mobile-nav" id="mobileNav">
        <a href="admin-dashboard.php">Dashboard</a>
        <a href="admin-users.php">Users</a>
        <a href="roles.php">Roles</a>
        <a href="admin-products.php">Products</a>
        <a href="admin-orders.php">Orders</a>
        <a href="admin-reports.php">Reports</a>
        <a href="index.php">View site</a>
        <a href="logout.php">Logout</a>
    </nav>

    <main>

        <section class="admin-dashboard-hero">
            <div>
                <p class="section-label">Reports</p>
                <h1>Review suspicious marketplace activity.</h1>
                <p>
                    Reported products are listed here so authorised admin users can investigate scam concerns,
                    misleading listings, duplicate posts or unsafe items.
                </p>

                <p>
                    Logged in as <?php echo htmlspecialchars($_SESSION["first_name"] . " " . $_SESSION["last_name"]); ?> 
                    · Role: <?php echo htmlspecialchars($_SESSION["role_name"]); ?>
                </p>
            </div>

            <div class="admin-hero-card">
                <span>Safety workflow</span>
                <h3>Open → Reviewing → Resolved</h3>
                <p>
                    Admins can track report progress and take action through product moderation when necessary.
                </p>
            </div>
        </section>

        <section class="admin-dashboard-layout">

            <aside class="admin-sidebar-panel">
                <div class="admin-profile-card">
                    <div class="admin-avatar"><?php echo htmlspecialchars(strtoupper(substr($_SESSION["first_name"], 0, 1))); ?></div>
                    <h3><?php echo htmlspecialchars($_SESSION["first_name"] . " " . $_SESSION["last_name"]); ?></h3>
                    <p><?php echo htmlspecialchars($_SESSION["role_name"]); ?></p>
                    <span>RBAC Active</span>
                </div>

                <nav class="admin-side-menu">
                    <a href="admin-dashboard.php">Overview</a>
                    <a href="admin-users.php">Manage users</a>
                    <a href="roles.php">Manage roles</a>
                    <a href="admin-products.php">Manage products</a>
                    <a href="admin-orders.php">Orders</a>
                    <a href="admin-reports.php" class="active">Reports</a>
                </nav>
            </aside>

            <div class="admin-dashboard-main">

                <div class="admin-metrics-grid">
                    <article class="admin-stat">
                        <p>Total reports</p>
                        <h3><?php echo $totalReports; ?></h3>
                        <span>All submitted reports</span>
                    </article>

                    <article class="admin-stat">
                        <p>Open</p>
                        <h3><?php echo $openReports; ?></h3>
                        <span>Waiting for review</span>
                    </article>

                    <article class="admin-stat">
                        <p>Reviewing</p>
                        <h3><?php echo $reviewingReports; ?></h3>
                        <span>Being investigated</span>
                    </article>

                    <article class="admin-stat">
                        <p>Resolved</p>
                        <h3><?php echo $resolvedReports; ?></h3>
                        <span>Closed reports</span>
                    </article>
                </div>

                <div class="admin-section">
                    <div class="admin-section-heading">
                        <div>
                            <p class="section-label">Reported listings</p>
                            <h2>Product report records</h2>
                        </div>

                        <a href="admin-products.php">Go to product moderation</a>
                    </div>

                    <?php if (!empty($message)) { ?>
                        <div class="admin-message-box">
                            <?php echo htmlspecialchars($message); ?>
                        </div>
                    <?php } ?>

                    <?php if (!empty($error_message)) { ?>
                        <div class="admin-error-box">
                            <?php echo htmlspecialchars($error_message); ?>
                        </div>
                    <?php } ?>

                    <div class="reports-table-wrap">
                        <table class="reports-table">
                            <thead>
                                <tr>
                                    <th>Report</th>
                                    <th>Product</th>
                                    <th>Reporter</th>
                                    <th>Seller reported</th>
                                    <th>Reason</th>
                                    <th>Status</th>
                                    <th>Update</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php if (mysqli_num_rows($reportsResult) > 0) { ?>
                                    <?php while ($report = mysqli_fetch_assoc($reportsResult)) { ?>
                                        <?php
                                            $statusClass = strtolower($report["report_status"]);
                                        ?>

                                        <tr>
                                            <td>
                                                #<?php echo htmlspecialchars($report["report_id"]); ?>
                                                <small><?php echo htmlspecialchars($report["report_date"]); ?></small>
                                            </td>

                                            <td>
                                                <a 
                                                    href="product.php?id=<?php echo $report["product_id"]; ?>" 
                                                    class="product-link"
                                                >
                                                    <?php echo htmlspecialchars($report["product_name"]); ?>
                                                </a>

                                                <small>
                                                    R<?php echo htmlspecialchars(number_format($report["price"], 2)); ?> ·
                                                    <?php echo htmlspecialchars($report["product_location"]); ?>
                                                </small>

                                                <small>
                                                    Listing status: <?php echo htmlspecialchars($report["listing_status"]); ?>
                                                </small>
                                            </td>

                                            <td>
                                                <?php echo htmlspecialchars($report["reporter_first_name"] . " " . $report["reporter_last_name"]); ?>
                                                <small><?php echo htmlspecialchars($report["reporter_email"]); ?></small>
                                            </td>

                                            <td>
                                                <?php echo htmlspecialchars($report["seller_first_name"] . " " . $report["seller_last_name"]); ?>
                                                <small><?php echo htmlspecialchars($report["seller_email"]); ?></small>
                                            </td>

                                            <td>
                                                <div class="report-reason">
                                                    <?php echo htmlspecialchars($report["report_reason"]); ?>
                                                </div>
                                            </td>

                                            <td>
                                                <span class="report-pill <?php echo htmlspecialchars($statusClass); ?>">
                                                    <?php echo htmlspecialchars($report["report_status"]); ?>
                                                </span>
                                            </td>

                                            <td>
                                                <form class="report-status-form" method="POST" action="admin-reports.php">
                                                    <input type="hidden" name="report_id" value="<?php echo $report["report_id"]; ?>">

                                                    <select name="report_status">
                                                        <option value="Open" <?php if ($report["report_status"] === "Open") echo "selected"; ?>>Open</option>
                                                        <option value="Reviewing" <?php if ($report["report_status"] === "Reviewing") echo "selected"; ?>>Reviewing</option>
                                                        <option value="Resolved" <?php if ($report["report_status"] === "Resolved") echo "selected"; ?>>Resolved</option>
                                                    </select>

                                                    <button type="submit" name="update_report">Save</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } else { ?>
                                    <tr>
                                        <td colspan="7">
                                            No reports have been submitted yet. Reports will appear here after users report suspicious products.
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>

                </div>

            </div>

        </section>

    </main>

    <footer class="footer">
        <p>TradeNest Admin</p>
        <p>Reports dashboard for scam prevention, product safety and moderation support.</p>
    </footer>

    <script src="assets/js/app.js"></script>
</body>
</html>

<?php
mysqli_close($conn);
?>